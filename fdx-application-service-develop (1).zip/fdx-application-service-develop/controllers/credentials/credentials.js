import objPath from 'object-path'
import { _extend as extend } from 'util'
// Services
import { removeProviderProfile, removeCredentialSet, addCredentialSet, } from '../../services/profile'
import { addCredentials,
  updateCredentials,
  getCredentialSetDetail,
  getAllCredentials,
  deleteCredentialSet,
  deleteAllProviderCredentials,
  getPrivateKeyByUserId } from '../../services/credential'
// Models
import CredentialsModel from '../../models/credentials/credentials-model'
import Error from '../../models/Error'


function getCredentialsCtrl( req, res ) {

  let credSetId = req.params.id
  if ( credSetId ) {
    getCredentialSetDetail( req, credSetId ).then(({ status, body })=>{
      let credentialsModel = new CredentialsModel( body )
      res.status( status ).send( credentialsModel.credentials || {} )
    })
    .catch((error)=>{
      if (error.stack) error = new Error( 'stack', error, req.headers )
      res.status( error.statusCode || 500 ).send( error )
    })
  } else {
    getAllCredentials( req ).then(({ status, body })=>{
      let credentialsModel = new CredentialsModel( body )
      res.status( status ).send( credentialsModel.credentials || {} )
    })
    .catch((error)=>{
      if (error.stack) error = new Error( 'stack', error, req.headers )
      res.status( error.statusCode || 500 ).send( error )
    })
  }

}

function getPrivateKeyCtrl( req, res ) {

  getPrivateKeyByUserId( req ).then(({ status, body })=>{
    res.status( status ).send( body || {} )
  })
  .catch((error)=>{
    if (error.stack) error = new Error( 'stack', error, req.headers )
    res.status( error.statusCode || 500 ).send( error )
  })
}

function addCrededentialsCtrl( req, res ) {
  let reqObj = objPath( req )
  let credentialsBody = extend( {}, req.body )

  // Need to strip out some batch related attributes for the req to Cresential Service
  objPath.del( credentialsBody, 'folderId' )
  objPath.del( credentialsBody, 'batchFolderId' )
  objPath.del( credentialsBody, 'offeringPreferences' )

  addCredentials( req, credentialsBody ).then(({ status, body })=>{

    let credSetId = body ? body.credentialSetId : ''
    let batchFolderId =   reqObj.get( 'body.batchFolderId' ) ? reqObj.get( 'body.batchFolderId' ) : reqObj.get( 'body.folderId' )

    //Add credentialSetId to Profile Service if it returns
    let payload = {
      providerId: reqObj.get( 'body.providerId' ),
      credSetId: credSetId,
      offeringPreferences: reqObj.get( 'body.offeringPreferences' ),
      folderId: batchFolderId,
      batchEligible: reqObj.get( 'body.batchEligible', true )
    }

    addCredentialSet( req, payload ).then(({ })=>{
      res.status( status ).send( body )
    })
    .catch((error)=>{
      if (error.stack) new Error( 'stack', error, req.headers )
      res.status( status ).send( body )
    })
  })
  .catch((error)=>{
    if (error.stack) error = new Error( 'stack', error, req.headers )
    res.status( error.statusCode || 500 ).send( error )
  })
}

function updateCredentialsCtrl( req, res ) {
  let reqObj = objPath( req )
  let credentialsBody = extend( {}, req.body )
    // Need to strip out some batch related attributes for the req to Cresential Service
  objPath.del( credentialsBody, 'folderId' )
  objPath.del( credentialsBody, 'batchFolderId' )
  objPath.del( credentialsBody, 'offeringPreferences' )
  let paramId = req.params.id
  updateCredentials( req, paramId, credentialsBody ).then(({ status, body })=>{
    let payload = {
      providerId: reqObj.get( 'body.providerId' ),
      credSetId: paramId,
      offeringPreferences: reqObj.get( 'body.offeringPreferences' ),
      folderId: reqObj.get( 'body.batchFolderId' ) ? reqObj.get( 'body.batchFolderId' ) : reqObj.get( 'body.folderId' ),
      batchEligible: reqObj.get( 'body.batchEligible', true )
    }
    addCredentialSet( req, payload ).then(({ })=>{
      res.status( status ).send( body )
    })
    .catch((error)=>{
      if (error.stack) new Error( 'stack', error, req.headers )
      res.status( status ).send( body )
    })
  })
  .catch((error)=>{
    if (error.stack) error = new Error( 'stack', error, req.headers )
    res.status( error.statusCode || 500 ).send( error )
  })
}

function deleteProviderCredentialsCtrl( req, res ) {
  let providerId = req.params.id
  Promise.all( [ credentialsPromise(), profilePromise() ] )
    .then( verifyResponse )
    .then( ( result ) => {
      res.status( 204 ).send( result )
    } )
    .catch( ( error ) => {
      if (error.stack) error = new Error( 'stack', error, req.headers )
      res.status( error.statusCode || 500 ).send( error )
    } )

  function profilePromise() {
    return new Promise( ( resolve ) => {
      removeProviderProfile( req, providerId ).then(({ status })=>{
        resolve( status )
      })
      .catch(()=>{
        resolve( null )
      })
    } )
  }

  function credentialsPromise() {
    return new Promise( ( resolve ) => {
      deleteAllProviderCredentials( req, providerId ).then(({ status })=>{
        resolve( status )
      })
      .catch(()=>{
        resolve( null )
      })
    } )
  }

  function verifyResponse( responses ) {
    //TODO: respond if one fails
    let bothDeleted = ( responses[ 0 ] !== null) && (responses[ 1 ] !== null )
    if( bothDeleted ) return bothDeleted
    else throw 'credentials did not delete properly'
  }

}

function deleteCredentialSetCtrl( req, res ) {
  let credsetId = req.params.id
  let providerId = req.body.providerId

  Promise.all( [ credentialsPromise(), profilePromise() ] )
    .then( verifyResponse )
    .then( ( result ) => {
      res.status( 204 ).send( result )
    } )
    .catch( ( error ) => {
      if (error.stack) error = new Error( 'stack', error, req.headers )
      res.status( error.statusCode || 500 ).send( error )
    } )

  function profilePromise() {
    return new Promise( ( resolve ) => {
      removeCredentialSet( req, providerId, credsetId ).then(({ status })=>{
        resolve( status )
      })
      .catch(()=>{
        resolve( null )
      })
    } )
  }

  function credentialsPromise() {
    return new Promise( ( resolve ) => {
      deleteCredentialSet( req, credsetId ).then(({ status })=>{
        resolve( status )
      })
      .catch(()=>{
        resolve( null )
      })
    } )
  }

  function verifyResponse( responses ) {
    //TODO: respond if one fails
    let bothDeleted = ( responses[ 0 ] !== null) && (responses[ 1 ] !== null )
    if( bothDeleted ) return bothDeleted
    else throw 'credentials did not delete properly'
  }
}

exports.getCredentialsCtrl = getCredentialsCtrl
exports.addCrededentialsCtrl = addCrededentialsCtrl
exports.updateCredentialsCtrl = updateCredentialsCtrl
exports.deleteProviderCredentialsCtrl = deleteProviderCredentialsCtrl
exports.deleteCredentialSetCtrl = deleteCredentialSetCtrl
exports.getPrivateKeyCtrl = getPrivateKeyCtrl
