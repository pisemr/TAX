// Services:
import { getProfile, removeProviderProfile, removeCredentialSet, addCredentialSet, } from '../../services/profile'
import { addCredentials, updateCredentials, getCredentialSetDetail, getAllCredentials, deleteCredentialSet, deleteAllProviderCredentials, } from '../../services/credential'

// Models:
import ConnectionsModel from '../../models/connections/connections-model'
import CredentialsModel from '../../models/credentials/credentials-model'
import Error from '../../models/Error'

function getConnectionsCtrl( req, res ) {

  let providersList = []

  Promise.all( [ credentialsPromise(), profilePromise() ] )
    .then( mergeResponses )
    .then( getCredentialDetail )
    .then( buildResponse )
    .then( ( result ) => {
      res.status( 200 ).send( result )
    } )
    .catch( ( error ) => {
      if (error.stack) error = new Error( 'stack', error, req.headers )
      res.status( 500 ).send( error )
    } )

  function profilePromise() {
    return new Promise( ( resolve ) => {
      getProfile( req ).then(({ body })=>{
        resolve( body )
      })
      .catch(()=>{
        resolve( null )
      })
    } )
  }

  function credentialsPromise() {
    return new Promise( ( resolve ) => {
      getAllCredentials( req ).then(({ body })=>{
        resolve( body )
      })
      .catch(()=>{
        resolve( null )
      })
    } )
  }

  function mergeResponses( responses ) {
    let credentialsResponse = responses[ 0 ]
    let profileResponse = responses[ 1 ]
    let bothSucces = ( credentialsResponse !== null) || ( profileResponse !== null )
    let connectionsModel = new ConnectionsModel()

    if( bothSucces ) {
      connectionsModel.mergedResponse = { credentialsResponse, profileResponse }
      return connectionsModel.mergedResponse
    }
    else {
      throw new Error ( 'VALUT_SERVER_ERROR', 'connections did not merge properly', req )
    }

  }

  function getCredentialDetail( providers ) {
    let credentialSetIds = []
    providers.forEach( ( provider ) => {
      providersList.push( {
        providerId: provider.providerId,
        credentialSets: []
      } )
      provider.credentialSetIds.forEach( ( credentialSetId ) => {
        credentialSetIds.push( {
          credentialSetId: credentialSetId,
          providerId: provider.providerId
        } )
      } )
    } )

    return Promise.all( credentialSetIds.map( ( credentialSet ) => {
      return new Promise( ( resolve ) => {
        getCredentialSetDetail( req, credentialSet.credentialSetId ).then(({ body })=>{
          resolve( body )
        })
        .catch(( error )=>{
          resolve( {
            providerId: credentialSet.providerId,
            error: error
          } )
        })
      } )
    } ) )
  }

  function buildResponse( details ) {
    let response = providersList.map( ( provider ) => {
      details.forEach( ( credentilSet ) => {
        if ( credentilSet.providerId && credentilSet.providerId === provider.providerId ) {
          if ( !credentilSet.error ) {
            provider.credentialSets.push( credentilSet )
          }
        }
      } )
      return provider
    } )

    return {
      providers: response
    }

  }

}

function getConnectionDetailCtrl( req, res ) {

  let credentialSetId = req && req.params ? req.params.credentialSetId : ''

  getCredentialSetDetail( req, credentialSetId ).then(({ status, body })=>{
    let credentialsModel = new CredentialsModel( body )
    res.status( status ).send( credentialsModel.credentials || {} )
  })
  .catch((error)=>{
    if (error.stack) error = new Error( 'stack', error, req.headers )
    res.status( error.statusCode || 500 ).send( error )
  })

}

function saveConnectionCtrl( req, res ) {
  let body = req.body || {}

  let profilePayload = {
    providerId: body.providerId,
    credSetId: body.credentialSetId,
    offeringPreferences: body.offeringPreferences,
    folderId: body.batchFolderId ? body.batchFolderId : body.folderId,
    batchEligible: body.batchEligible || true
  }

  let credentialsPayload = {
    providerId: body.providerId,
    status: body.verified,
    statusDetail: body.statusDetail,
    compliance : body.compliance,
    credentials: body.credentialSets
  }


  if ( body.isTransientProvider ) {
    addCredentialSet( req, profilePayload ).then(()=>{
      res.status( 200 ).send( { message: 'we can not save credentials for this provider' } )
    })
    .catch((error)=>{
      if (error.stack) error = new Error( 'stack', error, req.headers )
      res.status( error.statusCode || 500 ).send( error )
    })
  } else if( body.credentialSetId ) {

    Promise.all( [ credentialsPromise(), profilePromise() ] )
      .then( mergeResponses )
      .then( ( result ) => {
        res.status( 204 ).send( result )
      } )
      .catch( ( error ) => {
        if (error.stack) error = new Error( 'stack', error, req.headers )
        res.status( 500 ).send( error )
      } )

  } else {

    addCredentials( req, credentialsPayload ).then(({ status, body })=>{
      profilePayload.credSetId = body.credentialSetId

      addCredentialSet( req, profilePayload ).then(()=>{

        res.status( status ).send( body )
      })
      .catch(( error )=>{
        if (error.stack) new Error( 'stack', error, req.headers )
        res.status( status ).send( body )
      })
    })
    .catch(( error )=>{
      if (error.stack) error = new Error( 'stack', error, req.headers )
      res.status( error.statusCode || 500 ).send( error )
    })

  }

  function profilePromise() {
    return new Promise( ( resolve ) => {
      addCredentialSet( req, profilePayload  ).then(({ body })=>{
        resolve( body )
      })
      .catch(()=>{
        resolve( null )
      })
    } )
  }

  function credentialsPromise() {
    return new Promise( ( resolve ) => {
      updateCredentials( req, body.credentialSetId, credentialsPayload ).then(({ body })=>{
        resolve( body )
      })
      .catch(()=>{
        resolve( null )
      })
    } )
  }

  function mergeResponses( responses ) {
    let credentialsResponse = responses[ 0 ]
    let profileResponse = responses[ 1 ]
    let bothSucces = ( credentialsResponse !== null) || ( profileResponse !== null )

    if( bothSucces ) return bothSucces
    else throw new Error ( 'VALUT_SERVER_ERROR', 'connections did not save properly', req )
  }
}

function removeConnectionCtrl( req, res ) {

  let providerId = req.params.providerId || null //should always have this one
  let credentialSetId = req.params.credentialSetId || null
  let deleteCredentialSetRoute = !!credentialSetId


  Promise.all( [ credentialsPromise(), profilePromise() ] )
    .then( manageResponse )
    .then( ( result ) => {
      res.status( 204 ).send( result )
    } )
    .catch( ( error ) => {
      if (error.stack) error = new Error( 'stack', error, req.headers )
      res.status( 500 ).send( error )
    } )

  function profilePromise() {
    return new Promise( ( resolve ) => {
      if ( deleteCredentialSetRoute ) {
        removeCredentialSet( req, providerId, credentialSetId ).then( ({ status })=> {
          resolve( status )
        } )
        .catch( ()=>{
          resolve( null )
        } )
      } else {
        removeProviderProfile( req, providerId ).then( ({ status })=> {
          resolve( status )
        } )
        .catch( ()=>{
          resolve( null )
        } )

      }
    } )
  }

  function credentialsPromise() {
    return new Promise( ( resolve ) => {
      if ( deleteCredentialSetRoute ) {
        deleteCredentialSet( req, credentialSetId ).then( ({ status })=> {
          resolve( status )
        } )
        .catch(( error ) => {
          resolve( error.statusCode )
        } )
      } else {
        deleteAllProviderCredentials( req, providerId ).then( ({ status })=> {
          resolve( status )
        } )
        .catch(( error )=>{
          resolve( error.statusCode )
        } )
      }
    } )
  }

  function manageResponse( result ) {

    let deleteCredentialsError = result[ 0 ]
    let deleteProfileError = result[ 1 ]

    if ( deleteCredentialsError === 204 && deleteProfileError === 200 ) return
    else if ( deleteCredentialsError === 404 && deleteProfileError === 200 ) return
    else if ( deleteCredentialsError === 204 && deleteProfileError === 404 ) return
    else throw new Error ( 'VALUT_SERVER_ERROR', 'one or more credentials were not deleted', req.headers )

  }
}

exports.getConnectionsCtrl = getConnectionsCtrl
exports.getConnectionDetailCtrl = getConnectionDetailCtrl
exports.saveConnectionCtrl = saveConnectionCtrl
exports.removeConnectionCtrl = removeConnectionCtrl
