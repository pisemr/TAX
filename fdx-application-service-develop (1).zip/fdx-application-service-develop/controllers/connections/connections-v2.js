import { getProvidersByUserId } from '../../services/credential'
import { getAllProviderId } from '../../services/providers'
import { listAccountsForProvider } from '../../services/avs'
import { avmGet } from '../../services/fpo'
import Error from '../../models/Error'
import config from  '../../lib/config'
import ProviderDetail from '../../models/providers/ProviderDetail'
import AccountListModel from '../../models/accounts/account-list-model'
import { setCachedProvider, getCachedProviderEntry } from '../../lib/vault-utils'

function getProvidersByUserIdCtrl( req, res ) {
  req.normalizedPath = 'GET /v2/connections/providers'
  req.dependencies =  'PROVIDERS:' + config.services.providers.root
  getProvidersByUserId(req)
   .then(({ body }) => providerDetailPromise(req, body))
   .then(values => {
     res.status( 200 ).send( {
       results: values ? values.filter(v => v != null) : []
     } )
   })
  .catch( (error)=>{
    if (error.stack) error = new Error( 'stack', error, req.headers )
    res.status( error.statusCode || 500 ).send( error )
  } )
}

function providerDetailPromise(req, body) {
  const promises = []
  body.providers.forEach(provider => {
    promises.push(providerPromise(req, provider))
  })

  return Promise.all(promises)
}

function providerPromise(req, provider) {
  return new Promise( ( resolve ) => {
    let cachedProviderEntry = getCachedProviderEntry(provider.providerId)
    if (cachedProviderEntry && !cachedProviderEntry.provider.isExpired) {
      resolve(Object.assign({},cachedProviderEntry.provider, provider))
    }
    else {
      const serviceType = req.query.service
      getAllProviderId( req, provider.providerId )
        .then( ({ body }) => {
          let __model = new ProviderDetail(body, serviceType)
          resolve(Object.assign({},__model, provider))
          setCachedProvider(req, __model)
        } )
        .catch( (error) => {
          if (error.stack) error = new Error( 'stack', error, req.headers )
          resolve( null )
        } )
    }    
  } )
}

function listCtrl( req, res ) {
  const providerId = req.params.providerId
  const credentialSetIds = req.query ? req.query.credentialSetIds : null
  const accountTypes = req.query ? req.query.accountTypes : null
  const viewName = req.query ? req.query.viewName : null
  Promise.all([ avmGetPromise(req, viewName) , listAccountsForProviderPromise(req, providerId, credentialSetIds, accountTypes) ])
   .then(values => {
     const avmResponse = values[0]
     const listResponse = values[1]

     if (avmResponse && Array.isArray(avmResponse.accountIds) && Array.isArray(listResponse)) {
       listResponse.forEach((model) => {
         if(avmResponse.accountIds.indexOf(model.accountId) >= 0) {
           model.setSelected(true)
         }
       })
     }

     res.status( 200 ).send( {
       results: listResponse
     } )
   })
  .catch( (error)=>{
    if (error.stack) error = new Error( 'stack', error, req.headers )
    console.error(error)
    res.status( error.statusCode || 500 ).send( error )
  } )
}

function avmGetPromise(req, viewName) {
  if (!viewName) {
    return new Promise((resolve) => resolve(null))
  }

  return new Promise( (resolve) => {
    avmGet(req, viewName)
     .then(({ body }) => {
       resolve(body)
     })
    .catch( (error)=>{
      if (error.stack) error = new Error( 'stack', error, req.headers )
      console.error(error)
      resolve( null )
    } )    
  })
}

function listAccountsForProviderPromise(req, providerId, credentialSetIds, accountTypes) {
  return new Promise ( (resolve)  => {
    listAccountsForProvider(req, providerId, credentialSetIds, accountTypes)
     .then( ({ body }) => {
       const result = []
       if(Array.isArray(body)) {
         body.forEach((account) => {
           let flag = true
           if (credentialSetIds) {
            // filter for credentialsetids
             flag = (credentialSetIds.indexOf(account.credentialSetId) != -1)
           }

           if (flag && accountTypes) {
             // filter for accountTypes
             flag = (accountTypes.indexOf(account.accountType) != -1)
           }

           if (flag) {
             const __model = new AccountListModel(account)
             result.push(__model)            
           }
         })
       }
       resolve(result)
     })
    .catch( (error)=>{
      if (error.stack) error = new Error( 'stack', error, req.headers )
      console.error(error)
      resolve( error )
    } )    
  })
}


exports.getProvidersByUserIdCtrl = getProvidersByUserIdCtrl
exports.listCtrl = listCtrl