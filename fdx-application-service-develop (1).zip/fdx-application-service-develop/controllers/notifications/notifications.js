import { getCredentialSetByCredentialSetId } from '../../services/credential'
import { getMigrations, getProjectById } from '../../services/fdms'
import { createNotificationModel } from '../../models/notifications/notification-model'

function getNotifications( req, res )  {
  const sourceCredentialSetId = req.query.sourceCredentialSetId
  const sourceAccountId = req.query.sourceAccountId

  if(sourceAccountId && sourceAccountId.length > 0) {
    getMigrations(req, sourceCredentialSetId, sourceAccountId)
    .then(({ body }) => {
      if(Array.isArray(body)) {
        if(body.length > 0) {
          const arr = []
          body.forEach(migration => {
            arr.push(processMigrationPromise(req, sourceCredentialSetId, migration))
          })
          Promise.all(arr).then(values => {
            res.status( 200 ).send( values )
          })          
        } else {
          getCredentialDetails(req, sourceCredentialSetId)
          .then(value => {
            const __model = createNotificationModel({}, value)
            res.status( 200 ).send( [ __model ] )
          })       
        }
      }
    })      
    .catch(error => {
      if (error.stack) error = new Error( 'stack', error, req.headers )
      res.status( error.statusCode || 500 ).send( error )
    } )
  } else {
    getCredentialDetails(req, sourceCredentialSetId)
    .then(value => {
      const __model = createNotificationModel({}, value)
      res.status( 200 ).send( [ __model ] )
    })    
     .catch(error => {
       if (error.stack) error = new Error( 'stack', error, req.headers )
       res.status( error.statusCode || 500 ).send( error )
     } )    
  }
}

function processMigrationPromise(req, sourceCredentialSetId, migration) {
  return new Promise((resolve, reject) => {
    processMigrations(req, sourceCredentialSetId, migration)
      .then(values => {
        const __model = createNotificationModel(migration, ...values)
        resolve(__model)
      })
    .catch( (error) => {
      if (error.stack) error = new Error( 'stack', error, req.headers )
      reject(error)  
    } )          
  })
}

function getCredentialDetails(req, credentialSetID) {
  return new Promise( ( resolve, reject  ) => {
    getCredentialSetByCredentialSetId(req, credentialSetID)
    .then( ({ body }) => {
      resolve(body)
    } )
    .catch( (error) => {
      if (error.stack) error = new Error( 'stack', error, req.headers )
      reject(error)  
    } )
  })  
}

function getProjectDetails(req, projectId) {

  return new Promise( ( resolve, reject  ) => {
    if (!projectId) {
      resolve({})
    }
    getProjectById(req, projectId)
    .then( ({ body }) => {
      resolve(body)
    } )
    .catch( (error) => {
      if (error.stack) error = new Error( 'stack', error, req.headers )
      reject(error)  
    } )
  })   
}



function processMigrations(req, sourceCredentialSetId, migration) {
  let _credentialSetID = sourceCredentialSetId
  let projectId 
  if (migration) {
    projectId = migration.projectId

    if (migration.targetCredentialSetId) {
      _credentialSetID = migration.targetCredentialSetId
    } 
  }
  return Promise.all([ getCredentialDetails(req, _credentialSetID),
                       getProjectDetails(req, projectId) ])

}


exports.getNotifications = getNotifications
