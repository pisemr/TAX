import {
  acquire
} from '../../services/fpo'

import {
  handleRequest
} from '../accounts/accounts'

import {
  AcquireModelOld
} from '../../models/acquire/acquire-request-model.old'

import {
  FpoRequestModel
} from '../../models/fpo/FpoRequestModel'

// import Error from '../../models/Error'

export const entityTypeMissinsgError = 'entityTypes is required when acquireContext is not present'


function acquireAccountsCtrl( req, res ) {
  handleRequest(req, res, AcquireModelOld, acquire)
}

function acquireTransactionsCtrl( req, res ) {
  handleRequest(req, res, AcquireModelOld, acquire)
}

function acquireDocumentsCtrl( req, res ) {
  handleRequest(req, res, AcquireModelOld, acquire)
}

function fpoCtrl( req, res ) {
  const context = req.body.acquireContext ? req.body.acquireContext[0] : null
  const entityTypes = Array.isArray(req.body.entityTypes) ? req.body.entityTypes : []

  if ( !context && !entityTypes.length ) {
    req.body.entityTypes = [ 'ACCOUNT' ] // For Backward Compatibility
    // return res.status( 400 ).send( new Error( null, { message: entityTypeMissinsgError }, req.headers ) )
  }

  // we only support one credentialSetId
  if (Array.isArray(req.body.credentialSetIds) && req.body.credentialSetIds.length > 0) {
    req.body.credentialSetId = req.body.credentialSetIds[0]
  }

  switch (context) {
    case 'documents' : acquireDocumentsCtrl(req, res)
      break
    case 'transactions' : acquireTransactionsCtrl(req, res)
      break
    case 'accounts' : acquireAccountsCtrl(req, res)
      break
    default : handleRequest(req, res, FpoRequestModel, acquire)
  }
}

exports.fpoCtrl = fpoCtrl