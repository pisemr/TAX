import { customerAuthorizationForm } from '../../services/fpo'
import { CAfForm } from '../../models/caf/caf-form-model'
import Error from '../../models/Error'



function customerAuthorizationFormCtrl( req, res ) {
  let providerId = req.body.providerId
  let cafFormData = new CAfForm(req.body)
  customerAuthorizationForm( req, cafFormData, providerId )
  .then(( { body, status } ) => res.status(status).send(body))
  .catch(error => {
    if (error.stack) error = new Error( 'stack', error, req.headers) 
    res.status( error.statusCode || 500 ).send( error )    
  })
}

exports.customerAuthorizationFormCtrl = customerAuthorizationFormCtrl
