import moment from 'moment'
import cache from '../../lib/cache'
import config from '../../lib/config'
import logger from '../../lib/logger'
import { getAllProviders } from '../../services/providers'
import ProviderModel from '../../models/providers/provider-model'

function providersTask() {
  let callCount = 0
  function callProviders() {
    if ( callCount < 5 ) {
      getAllProviders().then( ( { status, body } )=>{
        if ( status === 200 ) {
          let cachedDate = moment( new Date() ).format( 'dddd, MMMM Do YYYY, h:mm:ss a' )
          let handlerOptions = {}
          let providerModel = new ProviderModel()
          providerModel.providers = { body, handlerOptions }

          cache.set( 'cachedProviders', providerModel.providers )
          cache.set( 'providersCachedFromCron', { cronCache: 'success', timeStamp: cachedDate } )
          logger.info( `cronCache="success" timeStamp="${cachedDate}" appEnv=${config.ENV}`)
          callCount = null
        } else {
          throw new Error( `provider service status: ${status}` )
        }

      } )
      .catch( ( error )=>{
        let date = new Date()
        logger.error( `cronCache="${error}" timeStamp="${date}" appEnv=${config.ENV}` )
        cache.set( 'providersCachedFromCron', { cronCache: error, timeStamp: date } )
        callProviders()
        callCount++
      } )
    }
  }
  callProviders()
}

exports.providersTask = providersTask
