import objPath from 'object-path'

// Services
import { getproviderByEIN, getAllProviderId } from '../../services/providers'
import { getEmployerByEIN } from '../../services/sangria'
import { searchProviders } from '../../services/sts'
import { searchProviderSuggestions } from '../../services/suggestions'
// Models
import AddProviderModel from '../../models/providers/AddProviderModel'
import QueryString from '../../models/providers/QueryString'
import normalizeProviders from '../../models/providers/normalize-providers'
import EmployerModel from '../../models/employers/employers-model'
import TypeaheadModel from '../../models/providers/Typeahead'
import ProviderDetail from '../../models/providers/ProviderDetail'
import SuggestionsModel from '../../models/providers/suggestions'
import Error from '../../models/Error'
import logger from '../../lib/logger'
import config from  '../../lib/config'
import { setCachedProvider, getCachedProviderEntry } from '../../lib/vault-utils'

const TOP_N_PROVIDERS = 'topN_providers'

function _searchProvidersCtrl( req={}, res, template ) {
  let query = new QueryString({ ...req.query, template  })

  searchProviders( req, { ...query } ).then( ({ status, body })=> {
    let newBody = objPath(body)
    let results = []

    getParentProviderData().then(() =>{
      //sort the result array back to original order before sending response
      //as async calls to get parent provider might have shuffled the order
      res.status( status ).send( {
        results: _sortResultsArray(body.results, results),
        totalhits: newBody.get('aggregates.access:summary.root.totalhits', results.length ) || 0
      } )
    })

    async function getParentProviderData() {
      await Promise.all(body.results.map(async (result) => {
        const instance = await TypeaheadModel.createInstance( result, req )
        results.push(instance)
      }))
      .catch( ( error ) => {
        console.log('error in parent provider data promise', error)
      } )
    }

  } )
  .catch( (error)=>{
    if (error.stack) error = new Error( 'stack', error, req.headers )
    res.status( error.statusCode || 500 ).send( error )
  } )
}

function _sortResultsArray(originalResultsArray, updatedResultsArray) {
  let finalResultsArray = []

  for(let i=0; i<=originalResultsArray.length-1; i++) {
    finalResultsArray.push(
      updatedResultsArray.find( function ( item ) {
        return originalResultsArray[i].provider_id === item.id
      } )
    )
  }

  return finalResultsArray
}

function _searchProviderSuggestionsCtrl( req={}, res, template) {
  Promise.all( [ providerSuggestionsPromise(), stsProvidersPromise() ] )
    .then( mergeSuggestionResponses )
    .then( result => {
      res.status( 200 ).send( result )
    } )
    .catch( ( error ) => {
      if (error.stack) error = new Error( 'stack', error, req.headers )
      res.status( 500 ).send( error )
    } )

  function providerSuggestionsPromise() {
    let suggestionsResponseReceived = false

    return new Promise( ( resolve ) => {
      searchProviderSuggestions( req ).then( ({ body })=> {
        suggestionsResponseReceived = true
        let results = body.providerSuggestions.map(result => new SuggestionsModel(result))
        resolve( results )
      } )
      .catch(()=>{
        resolve( null )
      })

      setTimeout(function () {
        if(!suggestionsResponseReceived) {
          logger.info(`Suggestions Promise timed out after ${config.services.suggestions.timeout} milliseconds`)
          resolve( null )
        }
      }, config.services.suggestions.timeout)
    } )
  }

  function stsProvidersPromise() {
    let query = new QueryString({ ...req.query, template  })

    return new Promise( ( resolve ) => {
      searchProviders( req, { ...query } ).then( ({ body })=> {
        let results = body.results.map(result => new TypeaheadModel(result))
        resolve( results )
      } )
      .catch(()=>{
        resolve( null )
      })
    } )
  }

  function mergeSuggestionResponses( responses ) {
    try {
      let resultsLimit = Number(req.query.limit)

      //check for any null responses
      //and then merge suggestion and sts responses
      let suggestionResults = responses[ 0 ] !== null ? responses[ 0 ] : []
      let STSResults = responses[ 1 ] !== null ? responses[ 1 ] : []
      let results = [ ...suggestionResults, ...STSResults ]
      const dedupedResults = results.filter((result, index, self) => self.findIndex(i => i.id === result.id) === index)

      //only return number of results reqd by client
      if(dedupedResults.length > resultsLimit) {
        dedupedResults.length = resultsLimit
      }

      return {
        results: dedupedResults,
        totalhits: results.length || 0
      }
    } catch(error) {
      console.log('Error in mergeSuggestionResponses - ', error)
      return {
        results: [],
        totalhits: 0
      }
    }
  }

}

function getProvidersCtrl( req, res ) {
  req.normalizedPath =  'GET /v2/providers'
  req.dependencies =  'PROVIDER:' + config.services.providers.root
  res.status(200).send('Coming Soon')
}

function addProvidersCtrl( req, res ) {
  req.normalizedPath =  'POST /v2/providers'
  req.dependencies =  'SPLUNK'

  logger.info(new AddProviderModel(req.body).logEntry)
  res.status(204).send()
}

function getRecommendedProvidersCtrl( req={}, res ) {
  let includeSuggestions = req.query.includeSuggestions == 'true'

  //if true - call sugesstion services along with STS
  if(includeSuggestions) {
    _searchProviderSuggestionsCtrl(req, res, TOP_N_PROVIDERS)
  } else {
    _searchProvidersCtrl(req, res, TOP_N_PROVIDERS)
  }
}

function getTypeaehaedProvidersCtrl( req={}, res ) {
  req.normalizedPath =  'GET /v2/providers/typeahead'
  req.dependencies =  'STS:' + config.services.sts.root
  _searchProvidersCtrl(req, res, 'fi_typeahead')
}

function getProviderByEINCtrl( req, res ) {
  req.normalizedPath =  'GET /v2/providers/ein/{ein}'
  req.dependencies =  'PROVIDER:' + config.services.providers.root + ';' + 'SANGRIA:' + config.services.sangria.root

  let reqObj = objPath( req, {} )
  let ein = reqObj.get( 'params.ein', reqObj.get( 'query.ein' ) )

  Promise.all( [ providersPromise(), sangriaPromise() ] )
    .then( mergeResponses )
    .then( ( result ) => {
      res.status( 200 ).send( result )
    } )
    .catch( ( error ) => {
      if (error.stack) error = new Error( 'stack', error, req.headers )
      res.status( 500 ).send( error )
    } )

  function providersPromise() {
    return new Promise( ( resolve ) => {
      getproviderByEIN( req, ein ).then( ( { body } )=>{
        let results = normalizeProviders( body, 'ein' )
        resolve( results )
      } )
      .catch(()=>{
        resolve( null )
      })
    } )
  }

  function sangriaPromise() {
    return new Promise( ( resolve ) => {
      getEmployerByEIN( req, ein ).then( ( { body } )=>{
        let businesses = body.taxBusinesses.map(( business )=>{
          return new EmployerModel( business )
        })

        resolve( businesses )
      } )
      .catch(()=>{
        resolve( null )
      })
    } )
  }

  function mergeResponses( responses ) {
    let results = {}
    results.providers = responses[ 0 ] || {}
    results.employers = responses[ 1 ] || {}
    return results
  }
}

function getProviderByIdCtrl( req, res ) {
  req.normalizedPath = 'GET /v2/providers/{providerId}'
  req.dependencies =  'PROVIDER:' + config.services.providers.root

  let cachedProviderEntry = getCachedProviderEntry(req.params.id)
  if (cachedProviderEntry && !cachedProviderEntry.provider.isExpired) {
    res.status(200).send(cachedProviderEntry.provider)
  }
  else {
    const serviceTypes = req.query.service ? req.query.service.split(';') : []
    getAllProviderId( req, req.params.id ).then( ({ status, body })=> {
      let result = new ProviderDetail(body, serviceTypes)
      result.fromCache = false
      result.isExpired = false
      res.status( status ).send( result )

      setCachedProvider(req, result)
    } )
    .catch( (error)=>{
      if (cachedProviderEntry) {
        res.status(200).send(cachedProviderEntry.provider)
      }
      else {
        if (error.stack) error = new Error( 'stack', error, req.headers )
        res.status( error.statusCode || 500 ).send( error )
      }

    } )
  }
}

exports.getProvidersCtrl = getProvidersCtrl
exports.addProvidersCtrl = addProvidersCtrl
exports.getRecommendedProvidersCtrl = getRecommendedProvidersCtrl
exports.getTypeaehaedProvidersCtrl = getTypeaehaedProvidersCtrl
exports.getProviderByEINCtrl = getProviderByEINCtrl
exports.getProviderByIdCtrl = getProviderByIdCtrl
