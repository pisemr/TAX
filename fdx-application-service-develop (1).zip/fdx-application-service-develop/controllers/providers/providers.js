import objPath from 'object-path'
import moment from 'moment'
// Services
import { getAllProviders, getproviderByEIN } from '../../services/providers'
import { getEmployerByEIN } from '../../services/sangria'
import { searchProviders } from '../../services/sts'
// Models
import ProviderModel from '../../models/providers/provider-model'
import AddProviderModel from '../../models/providers/AddProviderModel'
import normalizeProviders from '../../models/providers/normalize-providers'
import EmployerModel from '../../models/employers/employers-model'
import TypeaheadModel from '../../models/providers/Typeahead'
import lookUpMap from '../../lib/lookup-map'
import { providersTask } from './providers-cron'
import Error from '../../models/Error'
import logger from '../../lib/logger'
// Internal modules
import cache from '../../lib/cache'


function getAllProvidersCtrl( req, res ) {
  let cachedProviders = cache.get( 'cachedProviders' )
  let now = moment( new Date() )
  let isStale = cachedProviders.cachedProviders ? now.diff( moment( cachedProviders.cachedProviders.status.date ), 'hours' ) > 23 : 'true'
  let reqObj = objPath( req, {} )
  let type = reqObj.get( 'query.type' )

  if ( cachedProviders && !isStale ) {
    let responseData = {}
    responseData = cachedProviders.cachedProviders
    responseData.fromCache = true
    responseData.isStale = isStale
    res.status(200).send(responseData)

  } else {

    getAllProviders( req ).then( ({ status, body })=> {

      let handlerOptions = {
        headers: req.headers,
        type: type
      }
      let responseObj = {}
      let providerModel = new ProviderModel()
      providerModel.providers = { body, handlerOptions }
      responseObj = providerModel.providers
      responseObj.fromCache = false

      res.status( status ).send( responseObj )

    } )
    .catch( (error)=>{
      if (error.stack) error = new Error( 'stack', error, req.headers )
      res.status( error.statusCode || 500 ).send( error )
    } )
  }
}

function getProviderByEINCtrl( req, res ) {

  let reqObj = objPath( req, {} )
  let ein = reqObj.get( 'params.ein', reqObj.get( 'query.ein' ) )

  Promise.all( [ providersPromise(), sangriaPromise() ] )
    .then( mergeResponses )
    .then( ( result ) => {
      res.status( 200 ).send( result )
    } )
    .catch( ( error ) => {
      if (error.stack) error = new Error( 'stack', error, req.headers )
      res.status( 500 ).send( error )
    } )

  function providersPromise() {
    return new Promise( ( resolve ) => {
      getproviderByEIN( req, ein ).then( ( { body } )=>{
        let results = normalizeProviders( body, 'ein' )
        resolve( results )
      } )
      .catch(()=>{
        resolve( null )
      })
    } )
  }

  function sangriaPromise() {
    return new Promise( ( resolve ) => {
      getEmployerByEIN( req, ein ).then( ( { body } )=>{
        let businesses = body.taxBusinesses.map(( business )=>{
          return new EmployerModel( business )
        })

        resolve( businesses )
      } )
      .catch(()=>{
        resolve( null )
      })
    } )
  }

  function mergeResponses( responses ) {
    let results = {}
    results.providers = responses[ 0 ] || {}
    results.employers = responses[ 1 ] || {}
    return results
  }
}

function getRecommendedProvidersCtrl( req, res ) {
  let cachedProviders = cache.get( 'cachedProviders' )
  let now = moment( new Date() )
  let isStale = cachedProviders.cachedProviders ? now.diff( moment( cachedProviders.cachedProviders.status.date ), 'hours' ) > 23 : 'true'
  let type = req && req.query && req.query.type ? req.query.type : 'any'

  if ( cachedProviders && !isStale ) {
    let formattedResponse = {}
    let providerIds = lookUpMap.recommendedProvidersByDocType[type]
    formattedResponse.type = type
    formattedResponse.providers = providerIds.map((id)=>{
      let match
      cachedProviders.cachedProviders.providers.forEach((provider)=>{
        if (provider.id === id) {
          match = {
            id: provider.id,
            name: provider.name,
            logoUrl: provider.logoUrl
          }
        }
      })
      return match
    }).filter( (data) => data )

    res.status(200).send(formattedResponse)

  } else {
    providersTask
    let error = new Error( 'VALUT_SERVER_ERROR', 'providers are not cached, try again later', req.headers )
    res.status( error.statusCode || 500 ).send( error )
  }
}

function getProvidersCtrl( req={}, res ) {
  let qs = req.query || {}
  let { query='', limit=0, start=0, zip='', lang='en' } = qs

  searchProviders( req, query, zip, limit, start, lang ).then( ({ status, body })=> {
    let results = body.hits.map(result => new TypeaheadModel(result))

    res.status( status ).send( {
      results: results,
      totalhits: body.aggregates['access:summary'].root.totalhits || 0
    } )

  } )
  .catch( (error)=>{
    if (error.stack) error = new Error( 'stack', error, req.headers )
    res.status( error.statusCode || 500 ).send( error )
  } )
}

function addProvidersCtrl( req, res ) {
  logger.info(new AddProviderModel(req.body).logEntry)
  res.status(204).send()
}

function getProviderByIdCtrl( req, res ) {
  res.status(200).send('Work in progress, comming soon')
}

exports.getAllProvidersCtrl = getAllProvidersCtrl
exports.getProviderByEINCtrl = getProviderByEINCtrl

//v2 Route Controllers
exports.getProvidersCtrl = getProvidersCtrl
exports.getProviderByIdCtrl = getProviderByIdCtrl
exports.getRecommendedProvidersCtrl = getRecommendedProvidersCtrl
exports.addProvidersCtrl = addProvidersCtrl
