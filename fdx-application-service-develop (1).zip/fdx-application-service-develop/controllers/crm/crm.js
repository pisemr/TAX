import { createCRMCase } from '../../services/crm'
import { iusUserData } from '../../services/ius'

function createCRMCaseCtrl( req, res ) {
  iusUserData(req)
  .then( ({ body }) => {
    const iusData = { ...body }  
    createCRMCase( req, { 
      ...req.body,
      firstName: iusData.fullName ? iusData.fullName[0].givenName: 'firstName',  
      lastName: iusData.fullName ? iusData.fullName[0].surName : 'surName',  
      email: iusData.email.address
    } )
    .then(( { body, status } ) => res.status(status).send(body))
    .catch(error => {
      if (error.stack) error = new Error( 'stack', error, req.headers )
      res.status( error.statusCode || 500 ).send( error )
    })
  } )
  .catch(error => {
    if (error.stack) error = new Error( 'stack', error, req.headers )
    res.status( error.statusCode || 500 ).send( error )
  })
}

exports.createCRMCaseCtrl = createCRMCaseCtrl