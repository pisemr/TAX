import { getAllExperiments, getUserBucketsForExperiment, assignUserBucket, createUserEvent, getBucketDetail } from '../../services/abtesting'
import ExperimentModel from '../../models/abtesting/Experiment'
import config from '../../lib/config'
const IS_PROD = config.ENV === 'prod.lvdc' || config.ENV === 'prod.qdc'

function _getUserBucketsPromise(req, experiment) {
  return new Promise( resolve => {
    getUserBucketsForExperiment( req, experiment.label )
    .then(({ body={} })=>{
      resolve( {
        id: experiment.id,
        experiment: experiment.label,
        bucket: body.assignment
      } )
    })
    .catch(()=>{
      resolve( {
        id: experiment.id,
        experiment: experiment.label
      } )
    })
  } )
}

function _getBucketDetailPromise( req, experiment ) {
  return new Promise( resolve => {
    getBucketDetail(req, experiment.id)
    .then(({ body={} })=>{
      const isControl = body.buckets ? body.buckets.find( bucket=>bucket.label === experiment.bucket ).isControl : null
      resolve({
        ...experiment,
        isControl,
        buckets: body.buckets ? body.buckets.map(bucket=>bucket.label) : []
      })
    })
    .catch(()=>{
      resolve( { ...experiment } )
    })
  })
}

function _appendBucketDetail( req, assignedExperiment ) {
  return new Promise( resolve =>{
    assignedExperiment.bucket 
    ? _getBucketDetailPromise( req, assignedExperiment ).then(data=>resolve(data))
    : resolve(assignedExperiment)
  })
}

function getAllUserBucketsCtrl( req={}, res ) {
  getAllExperiments( req ).then( ({ status, body })=> {

    const experiments = body.map(experiment => new ExperimentModel(experiment))
      .filter(experiment=> (!IS_PROD && experiment.isPreprod)||(IS_PROD && !experiment.isPreprod))

    Promise.all( experiments.map( experiment => _getUserBucketsPromise( req, experiment )))
      .then(userAssignmentData =>
        Promise.all( userAssignmentData.map( assignedExperiment=> _appendBucketDetail( req, assignedExperiment )))
          .then( data=>res.status( status || 200 ).send( data )))
  } )
  .catch( error =>{
    if (error.stack) error = new Error( 'stack', error, req.headers )
    res.status( error.statusCode || 500 ).send( error )
  } )
}

function getUserBucketsForExperimentCtrl( req={}, res ) {
  let experiment = req.params && req.params.experiment
  getUserBucketsForExperiment( req, experiment ).then( ({ status, body })=> {
    res.status( status || 200 ).send( {
      experiment: experiment,
      bucket: body.assignment
    } )
  } )
  .catch( error =>{
    if (error.stack) error = new Error( 'stack', error, req.headers )
    res.status( error.statusCode || 500 ).send( error )
  } )
}

function assignUserBucketCtrl( req={}, res ) {
  let experiment = req.params && req.params.experiment
  assignUserBucket( req, experiment ).then( ()=> {
    res.status( 204 ).send()
  } )
  .catch( error =>{
    if (error.stack) error = new Error( 'stack', error, req.headers )
    res.status( error.statusCode || 500 ).send( error )
  } )
}

function createUserEventCtrl( req={}, res ) {
  createUserEvent( req ).then( ()=> {
    res.status( 204 ).send()
  } )
  .catch( error =>{
    if (error.stack) error = new Error( 'stack', error, req.headers )
    res.status( error.statusCode || 500 ).send( error )
  } )
}


exports.getAllUserBucketsCtrl = getAllUserBucketsCtrl
exports.getUserBucketsForExperimentCtrl = getUserBucketsForExperimentCtrl
exports.assignUserBucketCtrl = assignUserBucketCtrl
exports.createUserEventCtrl = createUserEventCtrl
