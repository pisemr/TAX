import objPath from 'object-path'
// Services
import { verifyAccessService } from '../../services/access'
import { verifyAccount, verfiyMFA } from '../../services/avs'
import { authenticateAndGetDocuments } from '../../services/financial-access'
import { getAccessToken, buildCredentialArrayFromResponseToken } from '../../services/partner-auth'
// Models
import { AccountsModel, MfaModel } from '../../models/accounts/accounts-model'
import { DocumentListModel } from '../../models/import/documentList-model'
import { getDocuments, updateDocument } from '../../services/documents'
// Internal Modules:
import { VAULT_ROUTE_ERRORS } from '@fdx/common/errors/error-mapping'
import Error from '../../models/Error'

function authenticateMFACtrl( req, res ) {

  verfiyMFA( req ).then(({ status, body })=>{
    let error = objPath.get( body,  'errors.0')
    if ( error ) {
      throw new Error( 'interaction', body, req.headers, status )
    } else {
      let accountsModel = new AccountsModel()
      accountsModel.list = body
      res.status( status ).send( accountsModel.list )
    }

  })
  .catch( error =>{
    if (error.stack) error = new Error( 'stack', error, req.headers )
    res.status( error.statusCode || 500 ).send( error )
  })

}

function authenticateCtrl( req, res ) {

  if( !req.body.authType ) {
    let error = new Error( 'VALUT_CLIENT_ERROR', 'missing authType', req.headers ) //messages.authenticate.missingAuthType
    res.status( error.statusCode || 500 ).send( error )
  } else if (req.body.authType === 'account') {
    avsService( req, res )
  } else {
    accessService( req, res )
  }
}

function avsService( req, res ) {
  verifyAccount( req ).then(({ status, body })=>{

    let error = objPath.get( body,  'errors.0')
    let errorCode = objPath.get( body,  'errors.0.code')

    if ( VAULT_ROUTE_ERRORS.interaction[ errorCode ] && VAULT_ROUTE_ERRORS.interaction[ errorCode ].errorType === 'mfa' ) {

      let mfaModel = new MfaModel()
      mfaModel.challenge = body
      res.status( status ).send( mfaModel.challenge )

    } else if ( error ) {
      throw new Error( 'interaction', body, req.headers, status )

    } else {
      let accountsModel = new AccountsModel()
      accountsModel.list = body
      res.status( status ).send( accountsModel.list )
    }

  })
  .catch((error)=>{
    if (error.stack) error = new Error( 'stack', error, req.headers )
    res.status( error.statusCode || 500 ).send( error )
  })
}

function accessService( req, res ) {
  let requestedDocType = req && req.query ? req.query.requestedDocType : {}
  let offeringAttributes = req && req.body ? req.body.offeringAttributes : {}

  verifyAccessService( req ).then(({ status, body })=>{

    let documentListModel = new DocumentListModel()
    documentListModel.list = { body, requestedDocType }

    if ( offeringAttributes.length ) {

      Promise.all( documentListModel.list.documents.map( ( document ) => {
        return new Promise( ( resolve ) => {
          getDocuments( req, document.documentId )
          .then(({ body })=>{
            let docToUpdate = body
            docToUpdate.commonAttributes = docToUpdate.commonAttributes || {}
            docToUpdate.commonAttributes.offeringAttributes = offeringAttributes
            return updateDocument( req, document.documentId )
          })
          .then(()=>{
            resolve( document )
          })
          .catch(()=>{
            resolve( document )
          })
        } )
      } ) )
      .then(()=>{
        res.status( status ).send( documentListModel.list )
      })

    } else {
      res.status( status ).send( documentListModel.list )
    }
  })
  .catch((error)=>{
    if (error.stack) error = new Error( 'stack', error, req.headers )
    res.status( error.statusCode || 500 ).send( error )
  })
}

function authenticateDocumentsCtrl( req, res ) {
  let requestedDocType = req && req.query ? req.query.requestedDocType : {}
  let returnRawData = false

  if ( req && req.query && req.query.rawdata === 'true' ) {
    returnRawData = true
  }

  //OAuth flow
  if (req && req.body && req.body.authType && req.body.authType.toLowerCase() === 'oauth') {
    getAccessToken( req )
      .then(_buildCredentialObjectFromTokenId)
      .then(authenticateAndGetDocuments)
      .then(_handleDocResponse)
      .catch(_handleError)
  }
  //credential set flow
  else {
    authenticateAndGetDocuments( req )
      .then(_handleDocResponse)
      .catch(_handleError)
  }

  function _buildCredentialObjectFromTokenId({ body }) {
    let tokenId = body.partnerAuthTokens[0].partnerAuthTokenId

    //modify req body to include encrypted credential set
    req.body.credentials = buildCredentialArrayFromResponseToken(tokenId)

    return req //return original request from client
  }

  function _handleDocResponse({ status, body }) {
    if ( returnRawData ) {
      res.status( status ).send( body )
    } else {
      let documentListModel = new DocumentListModel()
      documentListModel.list = { body, requestedDocType }
      res.status( status ).send( documentListModel.list )
    }
  }

  function _handleError(error) {
    if (error.stack) error = new Error( 'stack', error, req.headers )
    res.status( error.statusCode || 500 ).send( error )
  }
}

exports.authenticateMFACtrl = authenticateMFACtrl
exports.authenticateCtrl = authenticateCtrl
exports.authenticateDocumentsCtrl = authenticateDocumentsCtrl
