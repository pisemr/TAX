import { migrate } from '../../services/fdms'
import MigrateModel from '../../models/migrations/migrate-req'

function migrateCtrl(req, res) {
  const migrationId = req.body.migrationId
  const model = new MigrateModel(req.body)

  migrate( req,  migrationId, model)
    .then(( { body, status } ) => res.status(status).send(body))
    .catch(error => {
      if (error.stack) error = new Error( 'stack', error, req.headers )
      res.status( error.statusCode || 500 ).send( error )
    })  
}

exports.migrateCtrl = migrateCtrl