import {
  getDocuments,
  getSource,
  getAlternativeData,
  uploadDocument,
  uploadDocumentToFolder,
  deleteDocument,
  getDocumentsFrmFolder,
  createFolder
} from '../../services/documents'


function uploadDocumentCtrl(req, res) {
  let syncExtraction
  if( req.query && req.query.syncExtraction ) {
    syncExtraction = req.query.syncExtraction
  }
  uploadDocument(req, syncExtraction)
    .then( body => {
      res.send(body)
    })
    .catch(err => {
      let error = err.stack ? new Error( 'stack', err, req.headers ) : err
      res.send(err.statusCode, error)
    })
}

function uploadDocumentToFolderCtrl(req, res) {
  uploadDocumentToFolder(req, req.params.id)
    .then( body => {
      res.send(body)
    })
    .catch(error => {
      if (error.stack) error = new Error( 'stack', error, req.headers )
      res.status( error.statusCode || 500 ).send( error )
    })
}

function getDocumentCtrl( req, res ) {
  if ( req.query && ( req.query.format === 'view' ) ) viewDocument( req, res )
  else getDocumentData( req, res )
}

function deleteDocumentCtrl( req, res ) {

  let documentId = req.params.documentId

  deleteDocument( req, documentId ).then(({ status, body })=>{
    res.status( status ).send( body )
  })
  .catch((error)=>{
    if (error.stack) error = new Error( 'stack', error, req.headers )
    res.status( error.statusCode || 500 ).send( error )
  })

}

function getDocumentData( req, res ) {
  let documentId = req.params.documentId

  getDocuments( req, documentId ).then(({ status, body })=>{
    res.status( status ).send( body )
  })
  .catch((error)=>{
    if (error.stack) error = new Error( 'stack', error, req.headers )
    res.status( error.statusCode || 500 ).send( error )
  })
}

function viewDocument( req, res ) {

  let documentId = req.params.documentId

  getSource( req, documentId ).then(({ status, body, headers })=>{
    res.header('content-disposition', headers['content-disposition'] || 'inline filename=Vault.pdf')
    res.header('content-type', headers['content-type'] || 'application/pdf')
    res.status( status ).send( body )
  })
  .catch((error)=>{
    if ( error.statusCode === 404 ) {

      getAlternativeData( req, documentId ).then(({ status, body, headers })=>{
        res.header('content-disposition', headers['content-disposition'] || 'inline filename=Vault.pdf')
        res.header('content-type', headers['content-type'] || 'application/pdf')
        res.status( status ).send( body )
      })
      .catch((error)=>{
        if (error.stack) error = new Error( 'stack', error, req.headers )
        res.status( error.statusCode || 500 ).send( error )
      })
    } else {
      if (error.stack) error = new Error( 'stack', error, req.headers )
      res.status( error.statusCode || 500 ).send( error )
    }


  })
}

function getDocumentsFrmFolderCtrl( req, res) {
  let folderId = req.params.id

  getDocumentsFrmFolder( req, folderId ).then(({ status, body })=>{
    res.status( status ).send( body )
  })
  .catch((error)=>{
    if (error.stack) error = new Error( 'stack', error, req.headers )
    res.status( error.statusCode || 500 ).send( error )
  })
}

function determineFolderIdFromSourceURL(location) {
  let folderIdPos = location.indexOf('v2/folders') + 11
  let folderId = location.substring(folderIdPos)

  // folderId above might contain subfolder
  // check for folderIdPos again. If yes, return the subfolder Id.
  let subFolderIdPos = folderId.indexOf('/folders')
  if (subFolderIdPos == -1) {
    return folderId
  } else {
    let subFolderId = folderId.substring(subFolderIdPos + 9)
    return subFolderId
  }
}

function createFolderCtrl(req, res) {
  let folderName = req.params.name

  createFolder(req, folderName).then( ({ status, headers }) => {

    let loc = headers['location']
    let id = determineFolderIdFromSourceURL(loc)

    let targetFolder = {
      name: folderName,
      id: id
    }
    res.status( status ).send(targetFolder)
  })
  .catch(error => {
    if (error.stack) error = new Error( 'stack', error, req.headers )
    res.send(error.statusCode, error)
  })
}

function getFolderByNameCtrl( req, res) {
  let name = req.params.name
  let parentId = req.params.parentId
  getDocumentsFrmFolder( req, parentId ).then(({ status, body })=>{
    let id = null

    body.folders.forEach(folder => {
      if (folder.name === name) {
        id = folder.id
      }
    })
    if (id === null) {
      res.status(404).send('Folder not found')
    }
    else {
      res.status( status ).send( { name: name, id: id } )
    }
  })
  .catch((error)=>{
    if (error.stack) error = new Error( 'stack', error, req.headers )
    res.status( error.statusCode || 500 ).send( error )
  })
}

exports.uploadDocumentCtrl = uploadDocumentCtrl
exports.uploadDocumentToFolderCtrl = uploadDocumentToFolderCtrl
exports.getDocumentCtrl = getDocumentCtrl
exports.deleteDocumentCtrl = deleteDocumentCtrl
exports.getDocumentsFrmFolderCtrl = getDocumentsFrmFolderCtrl
exports.createFolderCtrl = createFolderCtrl
exports.getFolderByNameCtrl = getFolderByNameCtrl
