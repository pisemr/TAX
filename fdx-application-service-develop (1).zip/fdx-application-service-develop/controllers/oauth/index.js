
import { getAuthUri } from '../../services/partner-auth'
import { OAuthInitClass, OAuthReturnClass } from '../../models/oauth/OAuth'
import Error from '../../models/Error'
import url from 'url'

const SERVICE_NAME = 'partnerauth'


function authenticate( req = {}, res ) {
  const query = req.query
  const txnId = query.txnId || req.headers.intuit_tid
  const returnJSON = shouldReturnJSON( req.headers )
  const offering_redirect_uri = query.offering_redirect_uri
  let initOauthClass = new OAuthInitClass({
    txnId,
    offerinRedirectUrl: offering_redirect_uri ? getUrlFromQueryParam(offering_redirect_uri) : null
  }).setIsJson( returnJSON )

  getAuthUri( req )
    .then( resp => {
      initOauthClass.response = resp
      if ( !returnJSON && initOauthClass.redirectUri ) {
        res.header( 'Location', initOauthClass.redirectUri )
          .sendStatus( 302 )
      } else if (!returnJSON && !initOauthClass.redirectUri) {
        throw getInvalidRouteError( SERVICE_NAME, req.headers )
      } else {
        res.status( resp.statusCode || 200 )
          .header( 'intuit_tid', txnId)
          .send( initOauthClass.response )
      }
    })
    .catch( err =>{
      // if it's a stack trace ... hopefully we catch it here and send JSON back either way.
      if (err.stack) {
        return res.status( err.statusCode || 400 )
          .header( 'intuit_tid', txnId)
          .send( new Error( 'stack', err, req.headers ) )
      }

      initOauthClass.response = err
      if ( !returnJSON && initOauthClass.redirectUri ) {
        res.header( 'Location', initOauthClass.redirectUri )
          .sendStatus( 302 )
      } else {
        res.status( err.statusCode || 400 )
          .header( 'intuit_tid', txnId)
          .send( err )
      }
    })
}

function redirect( req = {}, res ) {

  const returnJSON = shouldReturnJSON( req.headers )
  const query = req.query
  const txnId = query.txnId || req.headers.intuit_tid
  const headers = req.headers || {}
  let returnOauthClass = new OAuthReturnClass({ query, txnId, headers }).setIsJson( returnJSON )

  if (!returnJSON && returnOauthClass.redirectUri) {
    res.header( 'Location', returnOauthClass.redirectUri )
    res.sendStatus( 302 )
  } else if (!returnJSON && !returnOauthClass.redirectUri) {
    res.status( 400 )
      .header( 'intuit_tid', txnId)
      .send( getInvalidRouteError( SERVICE_NAME, req.headers ) )
  } else {
    res.status( 200 )
      .header( 'intuit_tid', txnId)
      .send( returnOauthClass.response )
  }
}

// Helpers

function getInvalidRouteError( serviceName, headers ) {
  return new Error( serviceName
    , { code: 'invalid_redirect_url'
      , message: 'invalid redirect uri'
      , moreInfo: 'can\'t redirect to a invalid uri, sending JSON error instead' }
    , headers
    , 400 )
}

function shouldReturnJSON(headers={}) {
  return headers['accept'] === 'application/json'
}

function getUrlFromQueryParam( offering_redirect_uri ) {
  if ( !offering_redirect_uri )
    return

  const uri = url.parse( offering_redirect_uri )
  const urlQueryParam = uri.query ? uri.query
    .split( '&' )
    .find( item => item.includes( 'redirect_url=' ) )
    .split( '=' )[ 1 ] : offering_redirect_uri

  return urlQueryParam
}


exports.redirect = redirect
exports.authenticate = authenticate
