
/*
WARNING: this is deprocated, kept it around for a bit just to be safe
*/


// Modules:
import objPath from 'object-path'
// Services:
import { getAuthUri } from '../../services/partner-auth'
// Models:
import OAuthModel from '../../models/oauth/oauth-model'
// Constants
const ERROR_CODES = require( '@fdx/common/errors/error-mapping' )

function authenticate( req, res ) {
  let reqObj = objPath( req )
  let query = reqObj.get( 'query', {} )

  //we know this is the initialization call to get the Auth URI
  getAuthUri( req, ( error, response, body ) => {

    let txnId = query.txnId
    let offering_redirect_uri = query.offering_redirect_uri
    let oauthModel = new OAuthModel()

    if ( !error && response.statusCode === 200 ) {
      oauthModel.successUri = { body, txnId }
    } else {
      oauthModel.errorUri = { body, txnId, offering_redirect_uri }
    }

    res.header( 'Location', oauthModel.uri )
    res.sendStatus( 302 )
  } )

}

function redirect( req, res ) {
  let reqObj = objPath( req )
  let query = reqObj.get( 'query', {} )

  let responseData = {}
  let partnerAuthError = query.error_code
  let token = query.token_query
  let redirectUri = query.redirect_url
  let fdpError = ERROR_CODES.PARTNER_AUTH_ERRORS[ partnerAuthError ]


  if ( fdpError ) {
    let fdpCode = ERROR_CODES.PARTNER_AUTH_ERRORS[ partnerAuthError ].fdp_code
    let message = query.error_description
    responseData.data = redirectUri + '?errorCode=' + fdpCode + '&errorMessage=' + message + '&txnId=' + query.txnId

  } else {

    let responseToken = token ? token.split( '=' ) : []
    responseToken = responseToken[ 1 ]
    responseData.data = redirectUri + '?txnId=' + query.txnId + '&response_token=' + responseToken + '&token=' + responseToken

  }

  res.header( 'Location', responseData.data )
  res.sendStatus( 302 )
}

exports.authenticate = authenticate
exports.redirect = redirect
