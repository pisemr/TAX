import { getBucketAssignment, assignBucket, createEvent } from '../../services/abtesting'

function getBucketAssignmentCtrl( req, res ) {
  getBucketAssignment( req ).then( ({ status, body })=> {
    res.status( status || 200 ).send( body )
  } )
  .catch( error =>{
    if (error.stack) error = new Error( 'stack', error, req.headers )
    res.status( error.statusCode || 500 ).send( error )
  } )
}

function assignBucketCtrl( req, res ) {
  assignBucket( req ).then( ({ status, body })=> {
    res.status( status || 200 ).send( body )
  } )
  .catch( error =>{
    if (error.stack) error = new Error( 'stack', error, req.headers )
    res.status( error.statusCode || 500 ).send( error )
  } )
}

function createEventCtrl( req, res ) {
  createEvent( req ).then( ({ status, body })=> {
    res.status( status || 200 ).send( body )
  } )
  .catch( error =>{
    if (error.stack) error = new Error( 'stack', error, req.headers )
    res.status( error.statusCode || 500 ).send( error )
  } )
}

exports.getBucketAssignmentCtrl = getBucketAssignmentCtrl
exports.assignBucketCtrl = assignBucketCtrl
exports.createEventCtrl = createEventCtrl
