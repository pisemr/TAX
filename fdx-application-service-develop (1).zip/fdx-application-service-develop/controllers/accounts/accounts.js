import {
  addToCache,
  retrieveFromCache
} from '../../services/cache'

import {
  acquire,
  refresh,
  editCredentials
} from '../../services/fpo'

import {
  getAccessToken,
  getAuthHeaders,
  buildCredentialArrayFromResponseToken
} from '../../services/partner-auth'

import CacheModel, {
  CACHE_STATUS_MAP,
  CACHE_CONNECTION_STATUS_MAP
} from '../../models/cache/CacheModel'

import {
  FpoAcquireModel,
  FpoMfaModel,
  FpoRefreshModel,
  FpoEditCredentialsModel
} from '../../models/accounts/fpo-request-model'

import logger from '../../lib/logger'

import { getUserAuthenticationData } from '../../lib/intuit-headers'
import { GENERIC_REALM_ID } from '../../constants/enums'
import Error from '../../models/Error'
import MfaSessionModel from '../../models/accounts/mfa-session-model'
import MigrationModel from '../../models/accounts/migration-model'
import GUIDGenerator from '../../lib/generate-tid'

import mockMfaResponse from './mockMfaResponse'
import mockInvalidCredentialsResponse from './mockInvalidCredentialsResponse'
import mockFinalResponse from './mockFinalResponse'
import mock187 from './mock187'

const SERVICE_NAMES = {
  'acquire' : acquire,
  'refresh' : refresh,
  'edit'    : editCredentials,
  'mfa'     : acquire
}

function acquireAccountsCtrl( req, res ) {
  handleRequest(req, res, FpoAcquireModel, SERVICE_NAMES.acquire)
}

function mfaSubmitCtrl( req, res ) {
  handleRequest(req, res, FpoMfaModel, SERVICE_NAMES.mfa)
}

function refreshSubmitCtrl( req, res ) {
  handleRequest( req, res, FpoRefreshModel, SERVICE_NAMES.refresh)
}

function editCredentialsCtrl( req, res ) {
  handleRequest( req, res, FpoEditCredentialsModel, SERVICE_NAMES.edit)
}

export function handleRequest( req, res, Model, name ) {

  const { intuit_realmid } = getUserAuthenticationData(req.headers || {}, req.cookies || {})
  const { isRealmContext } = req.body || {}

  if ( isRealmContext && intuit_realmid === GENERIC_REALM_ID ) {
    return res.status( 400 )
      .send( new Error( 'VALUT_CLIENT_ERROR', { message: `can not make downstream request to FPOS with generic realmId ${intuit_realmid}`, code: 'FDX-400' }, req.headers, 400 ) )
  }

  let isAsync = !req.body.sync
  let handler = _handleAsyncRequest
  if ( !isAsync ) {
    handler = _handleSyncRequest
  }

  //check for "oauth" authType
  if (req && req.body && req.body.authType && req.body.authType.toLowerCase() === 'oauth') {
    //call to partner Auth and get the PA token
    getAccessToken(req)
      .then(setPartnerAuthToken)
      .then(setOauthProxyTokenCredential)
      .then(getAuthHeaders)
      .then(setPartnerUserIdCredential)
      .then(() => handler( req, res, new Model( req.body, isAsync ), name))
      .catch(error => {
        if (error.stack) error = new Error( 'stack', error, req.headers )
        res.status( error.statusCode || 500 ).send( error )
      })
  }
  else {
    handler( req, res, new Model( req.body, isAsync ), name )
  }

  function setPartnerAuthToken({ body }) {
    req.body.partnerAuthToken = body.partnerAuthTokens[0].partnerAuthTokenId
    return req
  }

  //response token needs to be passed along as a credential object
  function setOauthProxyTokenCredential({ body }) {
    let tokenId = body.partnerAuthToken
    req.body.credentials = buildCredentialArrayFromResponseToken(tokenId)
    return req //return original request from client
  }

  function setPartnerUserIdCredential({ body }) {
    let authHeaders = body.otherHeaders
    for (let i=0; i < authHeaders.length; i++) {
      if (authHeaders[i].name === 'partnerUserId'
          && req.body.partnerUserId) {
        req.body.credentials[1] = {
          id: req.body.partnerUserId.id,
          type: 'primary',
          text: 'partnerUserId',
          value: authHeaders[i].value,
          encrypted: false
        }
      }
    }
    return req
  }
}

function fpoPollingCtrl( req, res ) {
  let correlationId = req.params.correlationId

  if ( req.query.mockMfaResponse ) {
    return res.status( 200 )
      .send( new CacheModel({
        correlationId,
        cacheStatus: CACHE_STATUS_MAP.READY,
        response: mockMfaResponse,
        connectionStatus: CACHE_CONNECTION_STATUS_MAP.MFA }) )
  }
  if ( req.query.mockMfa1450 ) {
    return res.status( 200 )
      .send( new CacheModel({
        correlationId,
        cacheStatus: CACHE_STATUS_MAP.READY,
        response: mockMfaResponse,
        connectionStatus: CACHE_CONNECTION_STATUS_MAP.RECAPTCHA }) )
  }
  if ( req.query.mock187 ) {
    return res.status( 400 )
      .send( new Error( 'fpo', mock187, req.headers, 400 ))
  }
  if ( req.query.mockInvalidCredentialsResponse ) {
    return res.status( 400 )
      .send( new CacheModel({
        correlationId,
        cacheStatus: CACHE_STATUS_MAP.READY,
        response: mockInvalidCredentialsResponse ,
        connectionStatus: CACHE_CONNECTION_STATUS_MAP.ERROR }) )
  }
  if ( req.query.mockFinalResponse ) {
    return res.status( 200 )
      .send( new CacheModel({
        correlationId,
        cacheStatus: CACHE_STATUS_MAP.READY,
        response: mockFinalResponse ,
        connectionStatus: CACHE_CONNECTION_STATUS_MAP.SUCCESS }) )
  }

  retrieveFromCache( req, correlationId )
    .then( body => {
      let cacheResp = body.body
      let cache = new CacheModel(cacheResp)

      let status = 200
      let responseData = cache

      if ( !cacheResp || cacheResp.correlationId != correlationId) {
        return res.status( 404 )
          .send( new Error( 'cache', { message: `cache data not found for correlationId ${correlationId}` }, req.headers, 404, { correlationId } ) )
      }

      if ( cache.cacheStatus === CACHE_STATUS_MAP.INITIAL ) {
        cache.cacheStatus = CACHE_STATUS_MAP.WAITING
      }

      if ( cache.isConnectionError() ) {
        const error = new Error( 'fpo', cacheResp.response, req.headers, 500, { correlationId } )
        status = error.statusCode
        responseData = error
      }

      res.status( status )
        .send( responseData )

    } )
    .catch( error => {
      if (error.stack) error = new Error( 'stack', error, req.headers )
      else error = new Error( 'cache', error, req.headers, null,  { correlationId })
      res.status( error.statusCode )
        .send( error )
    } )
}

function fpoCallbackCtrl( req, res ) {
  //Headers are always lower case
  let correlationId = req.headers.omscorrelationid
  logger.info( 'fpoCallbackCtrl: Processing callback for correlationId ', correlationId )
  let segment = 0
  let totalSegments = 0
  try {
    segment = req.headers.total_segments ? parseInt(req.headers.segment_number) : 0
    totalSegments = req.headers.total_segments ? parseInt(req.headers.total_segments) : 0
  } catch (ex) {
    //barfed on segment parsing
  }
  let response = req.body

  let isError = !!response.errors
  let mfaInfo = _extractMfa(response)
  let migrationInfo = _extractMigrationInfo(response)
  // let hasError1450 = isError ? response.errors.find( error => { return error.code === 'FDP-1450' } ) : false

  let newStatus = CACHE_STATUS_MAP.READY
  let newConnectionStatus = CACHE_CONNECTION_STATUS_MAP.SUCCESS

  if (isError) {
    if(migrationInfo) {
      response = migrationInfo
    } else if (mfaInfo) {
      newConnectionStatus = CACHE_CONNECTION_STATUS_MAP.MFA
      response = mfaInfo
    // } else if ( hasError1450 ) {
    //   newConnectionStatus = CACHE_CONNECTION_STATUS_MAP.RECAPTCHA
    } else {
      newConnectionStatus = CACHE_CONNECTION_STATUS_MAP.ERROR
    }
  } else if ( totalSegments && totalSegments > segment ) {
    newStatus = CACHE_STATUS_MAP.RECEIVING
    newConnectionStatus = CACHE_CONNECTION_STATUS_MAP.PENDING
  }

  retrieveFromCache( req, correlationId )
    .then( body => {
      // let cacheResp = body.body
      let cacheResp = new CacheModel(body.body)

      if ( cacheResp && cacheResp.correlationId == correlationId ) {

        // if connection state is PENDING, we need to update it to either MFA, SUCCESS or ERROR
        if ( cacheResp.connectionStatus === CACHE_CONNECTION_STATUS_MAP.PENDING) {
          _doAddToCache( req, res, correlationId, newStatus, response, newConnectionStatus, segment, totalSegments )
        } else {
          let error = new Error( 'cache', { message: 'FDI entry already updated' }, req.headers, 500, { correlationId } )
          res.status( error.statusCode )
            .send( error )
        }
      } else {
        //do we need to define a custom error here?
        let error = new Error( 'cache', { message: 'Document not found' }, req.headers, 404, { correlationId } )
        res.status( error.statusCode )
          .send( error )
      }
    } )
    .catch( error => {
      if (error.stack) error = new Error( 'stack', error, req.headers )
      else error = new Error( 'cache', error, req.headers, null, { correlationId } )
      res.status( error.statusCode )
        .send( error )
    } )

}

//~~~~~~~~~~~~ Handling Requests

function _handleAsyncRequest( req, res, fpoModel, service ) {

  if ( req.body.returnFPORequest ) {
    res.status( 200 )
      .send( fpoModel )
  }

  service( req, fpoModel )
    .then( body => {
      let fdiAsyncResponse = body.body
      let correlationId = fdiAsyncResponse.omsCorrelationId
      _doAddToCache( req, res, correlationId, CACHE_STATUS_MAP.INITIAL, fdiAsyncResponse, CACHE_CONNECTION_STATUS_MAP.PENDING )
    } )
    .catch( error => {
      // since the error was caught, it has already gone though the Error Model, unless its a stack trace
      // error = new Error( 'fpo', { message: 'Service error' }, req.headers, 400 )
      if (error.stack) error = new Error( 'stack', error, req.headers, null )
      res.status( error.statusCode )
        .send( error )
    } )
}

/**
Sync requests follow the same response structure as async requests
A "fake" correlationId will be generated and returned in the response
in order to support polling
*/
function _handleSyncRequest( req, res, fpoModel, service) {

  if ( req.body.returnFPORequest ) {
    res.status( 200 )
      .send( fpoModel )
  }

  let guidGenerator = new GUIDGenerator()
  let generatedCorrelationId = req.body.correlationId || guidGenerator.tid

  _doAddToCache( req, res, generatedCorrelationId, CACHE_STATUS_MAP.INITIAL, { omsCorrelationId: generatedCorrelationId }, CACHE_CONNECTION_STATUS_MAP.PENDING )

  //Send request to FDI /accounts endpoint, retrieve correlationId
  service( req, fpoModel )
    .then( body => {
      //Synchronous
      let newConnectionStatus = CACHE_CONNECTION_STATUS_MAP.SUCCESS
      let fdiSyncResponse = _stripResponse( body.body )
      let isError = false
      let mfaInfo = _extractMfa(fdiSyncResponse)
      let migrationInfo = _extractMigrationInfo(fdiSyncResponse)
      if ( fdiSyncResponse.errors ) {
        isError = true
      }

      if (isError) {
        if ( migrationInfo ) {
          fdiSyncResponse = migrationInfo
        } else if (mfaInfo) {
          newConnectionStatus = CACHE_CONNECTION_STATUS_MAP.MFA
          fdiSyncResponse = mfaInfo
        } else {
          newConnectionStatus = CACHE_CONNECTION_STATUS_MAP.ERROR
        }
      }

      _doAddToCache( req, null, generatedCorrelationId, CACHE_STATUS_MAP.READY, fdiSyncResponse, newConnectionStatus )

    } )
    .catch( error => {
      _doAddToCache( req, null, generatedCorrelationId, CACHE_STATUS_MAP.READY, error, CACHE_CONNECTION_STATUS_MAP.ERROR )
    } )
}

//~~~~~~~~~~~~ Handle Cache Request

function _doAddToCache( req, res, correlationId, cacheStatus, response, connectionStatus, segment, totalSegments) {

  let cache = new CacheModel({
    correlationId,
    cacheStatus,
    response,
    connectionStatus,
    segment,
    totalSegments
  })

  addToCache( req, cache )
    .then( () => {
      if ( res ) {
        res.status( 200 )
          .send( cache )
      }

    } )
    .catch( error => {
      if ( res ) {
        if (error.stack) error = new Error( 'stack', error, req.headers )
        else error = new Error( 'cache', error, req.headers, null, { correlationId } )
        res.status( error.statusCode )
          .send( error )
      }
    } )
}

//~~~~~~~~~~~~ HELPERS

//Copy only the data the UX needs
function _stripResponse( response ) {
  let strippedResponse = {}
  if ( response.providers ) {
    strippedResponse.providers = response.providers.map( provider => {
      let credentialSets = null

      if ( provider.credentialSets ) {
        credentialSets = provider.credentialSets
      } else if ( provider.accounts ) {
        credentialSets = []
        credentialSets[ 0 ] = {
          'credentialSetId': provider.accounts[ 0 ].credentialSetId
        }
      }

      return {
        providerId: provider.providerId,
        credentialSets: credentialSets
      }
    } )
  }

  if ( response.errors ) {
    strippedResponse.errors = response.errors
  }

  if ( response.responseParams ) {
    strippedResponse.responseParams = response.responseParams
  }

  return strippedResponse
}

function _extractMfa( response ) {
  if ( !response ) {
    return null
  }

  let mfaResponse = null
  if ( response.providers && response.responseParams && response.responseParams.mfaSession && response.errors ) {
    let hasError185 = response.errors.find( error => { return error.code === 'FDP-185' } )
    if ( hasError185 ) {
      mfaResponse = new MfaSessionModel( response.providers[ 0 ], response.responseParams.mfaSession )
    }
  }

  return mfaResponse
}

function _extractMigrationInfo( response ) {
  let migrationResponse = null
  if ( !response ) {
    return migrationResponse
  }

  if ( response.providers && response.errors ) {
    let hasError6601 = response.errors.find( error => { return error.code === 'FDP-6601' } )
    if( hasError6601 ) {
      migrationResponse = new MigrationModel( response )
    }
  }

  return migrationResponse
}

exports.acquireAccountsCtrl = acquireAccountsCtrl
exports.mfaSubmitCtrl = mfaSubmitCtrl
exports.refreshSubmitCtrl = refreshSubmitCtrl
exports.editCredentialsCtrl = editCredentialsCtrl
exports.fpoPollingCtrl = fpoPollingCtrl
exports.fpoCallbackCtrl = fpoCallbackCtrl
