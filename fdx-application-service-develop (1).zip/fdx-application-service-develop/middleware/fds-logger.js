import config from '../lib/config'
import logger from '../lib/logger'
import vUtils from '../lib/vault-utils'

module.exports = function FdsLoggerMiddleware() {
  return function FdsLoggerMiddlewareFunction( req, res, next ) {
    let request = Object.assign({}, req)
    let query = request.query || {}
    let reqHeaders = Object.assign({}, req.headers)
    let reqBody = Object.assign({}, req.body)
    let reqQuery = Object.assign({}, req.query)
    let startTime = new Date()
    let reqContentType = reqHeaders[ 'content-type' ] || ''
    let reqContentLength = reqHeaders[ 'content-length' ] || ''
    let tid = reqHeaders.intuit_tid || reqQuery.intuit_tid
    let payLoad = ''
    let headers = ''
    let reqPath = ''

    try {
      payLoad = reqBody ? JSON.stringify( reqBody ) : ''
      payLoad = vUtils.maskPersonalData(payLoad)
      reqPath = vUtils.maskQueryStringParam(request.originalUrl)('intuit_apikey') 
    } catch ( ex ) {
      // Error parsing PayLoad
    }

    try {
      reqHeaders.cookie = '*****'
      reqHeaders.authorization ? reqHeaders.authorization = vUtils.maskAuthHeader(reqHeaders.authorization) : null
      headers = JSON.stringify( reqHeaders )
    } catch ( ex ) {
      // Error parsing PayLoad
    }

    //follow logging standards https://wiki.intuit.com/display/FDP/Logging+Standard+in+FDS
    function logging( incoming ) {

      try {
        if ( !incoming ) {
          res.removeListener( 'finish', logging )
          res.removeListener( 'close', logging )
        }

        let responseTime = Date.now() - startTime
        // console.log( util.inspect( req.url, {
        //   showHidden: false,
        //   depth: null
        // } ) )
        let data = `
        LOG_ORIGIN="fds-logger-middleware"
        RESPONSE_LOG=true
        intuit_tid=${tid}
        fdp_widgets_version=${query.v || 'not provided' }
        fdp_widgets_flowid=${query.flowId}
        fdp_widgets_name=${query.flow_name}
        intuit_appid=${reqHeaders.intuit_assetalias}
        original_req_host=${config.host}
        original_req_method=${req.method}
        original_req_path_normalized=${req.normalizedPath}
        original_req_path=${reqPath}
        original_req_content_type=${reqContentType}
        original_req_content_length=${reqContentLength}
        original_req_body=${payLoad}
        original_req_headers=${headers}
        res_status=${res.statusCode}
        res_content_type=${res._headers[ 'content-type' ]}
        res_content_length=${res._headers[ 'content-length' ]}
        total_exec_time=${responseTime}
        dependencies=${req.dependencies}`

        if ( config.ENV !== 'local' ) data = data.replace( /\n/g, ' ' )

        if ( res.statusCode == 500 ) 
          logger.error( data )
        else 
          logger.info( data )

      } catch ( ex ) {
        ex.intuit_tid = tid
        logger.error( ex )
      }
    }

    res.on( 'finish', logging )
    res.on( 'close', logging )

    next()
  }
}
