import { verifyTicket } from '../services/axs'
import config from '../lib/config'

module.exports = function AuthMiddleware() {

  return function AuthMiddlewareFunction( req, res, next ) {
    let noAuthRoute  = config.no_auth_routes.filter(route=>route===req.baseUrl)

    if ( noAuthRoute.length )
      return next()

    verifyTicket(req).then(data=>{
      req.userData = data.body ? data.body : {}
      return next()
    })
    .catch(error =>{
      res.status( error.statusCode ).send( error )
    })
  }
}
