import Error from '../models/Error'
import config from '../lib/config'

const ENV_HEADERS = config.required_headers

module.exports = function ValidateHeadersMiddleware() {

  return function AuthMiddlewareFunction( req, res, next ) {
    const HEADERS = req.headers

    if ( validateHeaders( HEADERS ) ) {
      if ( req.baseUrl === '/v1/oauth' ) {
        let mgs = `${validateHeaders( HEADERS )} must be present in request header`
        sendRedirect(req, res, mgs)
      } else {
        res.status( 401 ).send( new Error ( 'VALUT_CLIENT_ERROR', `${validateHeaders( HEADERS )} must be present in request header`, req.headers ) )
      }
    } else {
      next()
    }

    function validateHeaders( headers ) {
      let missingHeaders = ENV_HEADERS.filter(header=>!headers[header])
      return missingHeaders ? missingHeaders.join(', ') : null
    }

    function getRedirectUri(offering_redirect_uri) {
      let stepOne = offering_redirect_uri.split('=')
      let stepTwo = stepOne[1].split('&')
      return stepTwo[0]
    }

    function sendRedirect(req, res, msg) {
      let redirectUri = getRedirectUri(req.query.offering_redirect_uri)
      let err = `${redirectUri}?errorCode=FDPAUTH-480&errorMessage=${msg}&txnId=${req.query.txnId}`
      res.header( 'Location', err )
      res.sendStatus( 302 )
    }
  }
}
