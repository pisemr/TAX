import {
  verifyGoogleReCaptcha
} from '../services/google'

import {
  assertRiskDetail
} from '../services/rss'

import RequestVariables from '../lib/request-variables'
import Error from '../models/Error'

const COMPLETED = 'captcha_completed'
const FAILED = 'captcha_failed'


module.exports = function ReCaptchaMiddleware() {

  return function ReCaptchaMiddlewareFunction( req, res, next ) {
    const query = { ...req.query }
    const body = { ...req.body }
    const reCaptchaValue = query.recaptcha || body.recaptcha
    
    if ( reCaptchaValue ) {
      verifyGoogleReCaptcha(req, reCaptchaValue)
        .then( response => {
          if (response.body && response.body.success ) {
            if ( req.body && req.body.recaptcha ) {
              delete req.body.recaptcha
            }

            if (!req.userData) {
              req.userData = {}
            }

            req.userData.reCaptchaStatus = 'pass'
            return COMPLETED
          } else {
            res.status(400).send(new Error('google', response.body, response.headers, 400))
            return FAILED
          }
        })
        .catch(() =>{
          // If Google API is down let's follow the OII lead and not block the user
          if ( req.body && req.body.recaptcha ) {
            delete req.body.recaptcha
          }
          return COMPLETED
        })
        .then(transaction => _assertValidation( req, res, next, transaction ))
    } else {
      return next()
    }
  }
}

function _assertValidation(req, res, next, transaction) {
  const { authid } = new RequestVariables( req )
  const { providerId } = req.body || {}
  return assertRiskDetail( req, { transaction, providerId, authid } )
    .then(()=>{
      return transaction === COMPLETED ? next() : null
    }).catch(err=>{
      throw err
    })
}

