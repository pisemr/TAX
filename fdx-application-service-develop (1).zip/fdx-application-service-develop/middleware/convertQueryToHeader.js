module.exports = function convertQueryToHeader() {

  return function convertQueryToHeaderFn( req, res, next ) {
    if (req.query && req.query.intuit_tid) {
      let newHeaders = Object.assign({}, req.headers, {
        intuit_tid: req.query.intuit_tid ? req.query.intuit_tid.split('.')[0] : '',
        intuit_flowid: req.query.flowId || req.query.intuit_flowid,
        intuit_country: req.query.country_code || req.query.intuit_country,
        intuit_locale: req.query.locale || req.query.intuit_locale
      })
      req.headers = newHeaders
      return next()
    }
    next ()
  }
}
