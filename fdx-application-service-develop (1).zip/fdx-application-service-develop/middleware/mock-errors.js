import Error from '../models/Error'

module.exports = function mockError() {

  return function ( req, res, next ) {
    let respondWithErrorCode = req.query.respondWithErrorCode
    if ( respondWithErrorCode ) {
      let message = {
        code: respondWithErrorCode,
        message: 'generic message '
      }
      res.status( 500 ).send( new Error ( 'MOCK', message, req.headers ) )

    } else {
      next()
    }
  }
}
