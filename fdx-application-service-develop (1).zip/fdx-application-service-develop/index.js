process.env.NODE_ENV = process.env.NODE_ENV || 'development'
process.env.PORT = process.env.PORT || 3000
import express from 'express'
import enrouten from 'express-enrouten'
import cors from 'cors'
import cookieParser from 'cookie-parser'
import bodyParser from 'body-parser'
// import mockErrors from './middleware/mock-errors'
import auth from './middleware/auth'
import convertQueryToHeader from './middleware/convertQueryToHeader'
import recaptcha from './middleware/validateReCaptcha'
import fdsLogger from './middleware/fds-logger'
import corsConfig from './lib/corsConfig'

let app = express()
app.use( '/content', express.static( 'static' ) )
// app.use( mockErrors() )
app.options( '/', cors( corsConfig ) )
app.use( cors( corsConfig ) )
app.use( cookieParser() )
app.use( bodyParser.json({ strict: false }) )
app.use( fdsLogger() )
app.use( '/v*', auth() )
app.use( '/v*', convertQueryToHeader() )
app.use( '/v*', recaptcha() )
app.use( enrouten( {
  directory: 'routes'
} ) )

export default app
