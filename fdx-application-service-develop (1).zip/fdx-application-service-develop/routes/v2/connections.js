
import { 
  getProvidersByUserIdCtrl,
  listCtrl
} from '../../controllers/connections/connections-v2'
import config from  '../../lib/config'

export default router => {

  router.get('/providers', (req, res) => {
    req.normalizedPath =  'GET /v2/connections/providers'
    req.dependencies =  'CREDENTIALS:' + config.services.credentials.root + ';' + 'PROFILE:' + config.services.profile.root
    getProvidersByUserIdCtrl(req, res)
  })

  /**
  * Accepts following Optional Query Params :
  * credentialSetId(s) : CredentialSetId(s) to filter
  * accountType(s): The account type(s) to filter (eg: CHECKING, SAVING etc.)
  * viewName: The AVM viewName associated with the Offering 
  */ 
  router.get('/:providerId/accounts', (req, res) => {
    req.normalizedPath =  'GET /v2/:providerId/accounts/list'
    req.dependencies =  'AVS:' + config.services.interaction.root + ';' + 'CACHE:' + config.services.cache.root
    listCtrl(req, res)    
  })    
}
