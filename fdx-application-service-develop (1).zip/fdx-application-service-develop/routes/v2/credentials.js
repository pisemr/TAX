import {
  editCredentialsCtrl
} from '../../controllers/accounts/accounts'
import {
  getPrivateKeyCtrl
} from '../../controllers/credentials/credentials'
import config from  '../../lib/config'

export default router => {

  router.put( '/',  (req, res) => {
    req.normalizedPath =  'PUT /v2/credentials'
    req.dependencies =  'CREDENTIALS:' + config.services.credentials.root + ';' + 'PROFILE:' + config.services.profile.root
    editCredentialsCtrl(req, res)
  })

  router.get( '/key',  (req, res) => {
    req.normalizedPath =  'GET /v2/key'
    req.dependencies =  'CREDENTIALS:' + config.services.credentials.root
    getPrivateKeyCtrl(req, res)
  })

}

