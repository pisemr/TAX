import { acquireAccountsCtrl } from '../../controllers/accounts/accounts'
import { authenticateDocumentsCtrl } from '../../controllers/authenticate/authenticate'
import config from  '../../lib/config'

module.exports = function documentsRouter( router ) {
  router.post( '/accounts',  (req, res) => {
    req.normalizedPath =  'POST /v2/authenticate/accounts'
    req.dependencies =  'FPO:' + config.services.fpo.root
    acquireAccountsCtrl(req, res)
  })
  router.post( '/documents',  (req, res) => {
    req.normalizedPath =  'POST /v2/authenticate/documents'
    req.dependencies =  'ACCESS:' + config.services.access.root
    authenticateDocumentsCtrl(req, res)
  })
}
