import {
  getAllUserBucketsCtrl,
  getUserBucketsForExperimentCtrl,
  assignUserBucketCtrl,
  createUserEventCtrl
} from '../../../controllers/widget/abtesting'
import config from  '../../../lib/config'

module.exports = function abTestingRouter(router) {
  router.get( '/buckets',  (req, res) => {
    req.normalizedPath =  'GET /v2/abtesting/buckets'
    req.dependencies =  'ABTESTING:' + config.services.ab.root
    getAllUserBucketsCtrl(req, res)
  })
  router.get( '/buckets/:experiment',  (req, res) => {
    req.normalizedPath =  'GET /v2/abtesting/buckets/:experiment'
    req.dependencies =  'ABTESTING:' + config.services.ab.root
    getUserBucketsForExperimentCtrl(req, res)
  })
  router.put( '/buckets/:experiment',  (req, res) => {
    req.normalizedPath =  'PUT /v2/abtesting/:experiment'
    req.dependencies =  'ABTESTING:' + config.services.ab.root
    assignUserBucketCtrl(req, res)
  })
  router.post('/event',  (req, res) => {
    req.normalizedPath =  'POST /v2/abtesting/event'
    req.dependencies =  'ABTESTING:' + config.services.ab.root
    createUserEventCtrl(req, res)
  })
}
