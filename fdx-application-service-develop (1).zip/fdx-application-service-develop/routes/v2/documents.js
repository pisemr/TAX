import {
  uploadDocumentToFolderCtrl,
  uploadDocumentCtrl,
  getDocumentCtrl,
  deleteDocumentCtrl,
  getDocumentsFrmFolderCtrl,
  createFolderCtrl,
  getFolderByNameCtrl,
  getFolderByIdCtrl
 } from '../../controllers/documents/documents'
import config from  '../../lib/config'

module.exports = function documentsRouter( router ) {
  router.get( '/', (req, res) => {
    req.normalizedPath =  'GET /v2/documents'
    req.dependencies =  'DOCUMENTS:' + config.services.documents.root
    getDocumentCtrl(req, res)
  })
  router.get('/folders/', (req, res) => {
    req.normalizedPath =  'GET /v2/documents/folders'
    req.dependencies =  'DOCUMENTS:' + config.services.documents.root
    getDocumentsFrmFolderCtrl(req, res)
  })
  router.get( '/:documentId', (req, res) => {
    req.normalizedPath =  'GET /v2/documents/:documentId'
    req.dependencies =  'DOCUMENTS:' + config.services.documents.root
    getDocumentCtrl(req, res )
  })
  router.get('/folders/:id', (req, res) => {
    req.normalizedPath =  'GET /v2/documents/folders/:id'
    req.dependencies =  'DOCUMENTS:' + config.services.documents.root
    getDocumentsFrmFolderCtrl(req, res)
  })
  router.get('/folder/:name/:parentId?', (req, res) => {
    req.normalizedPath =  'GET /v2/documents/folder/:name/:parentId'
    req.dependencies =  'DOCUMENTS:' + config.services.documents.root
    getFolderByNameCtrl(req, res)
  })
  router.post( '/', (req, res) => {
    req.normalizedPath =  'POST /v2/documents'
    req.dependencies =  'DOCUMENTS:' + config.services.documents.root
    uploadDocumentCtrl(req, res)
  })
  router.post( '/folders/:id', (req, res) => {
    req.normalizedPath =  'POST /v2/documents/folders/:id'
    req.dependencies =  'DOCUMENTS:' + config.services.documents.root
    uploadDocumentToFolderCtrl(req, res)
  })
  router.post( '/folder/:name', (req, res) => {
    req.normalizedPath =  'POST /v2/documents/folder/:name'
    req.dependencies =  'DOCUMENTS:' + config.services.documents.root
    createFolderCtrl(req, res)
  })
  router.delete( '/:documentId', (req, res) => {
    req.normalizedPath =  'DELETE /v2/documents/:documentId'
    req.dependencies =  'DOCUMENTS:' + config.services.documents.root
    deleteDocumentCtrl(req, res)
  })
}
