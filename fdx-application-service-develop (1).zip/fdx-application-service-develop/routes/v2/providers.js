import {
  getProvidersCtrl,
  addProvidersCtrl,
  getRecommendedProvidersCtrl,
  getTypeaehaedProvidersCtrl,
  getProviderByIdCtrl,
  getProviderByEINCtrl,
  //TODO: once we no longer need to support v1 rename to /providers
} from '../../controllers/providers/providers-v2'

import config from  '../../lib/config'

module.exports = function providersRoute( router ) {

  router.get( '/', (req, res) => {
    req.normalizedPath =  'GET /v2/providers'
    req.dependencies =  'PROVIDERS:' + config.services.providers.root
    getProvidersCtrl(req, res)
  })
  router.post( '/', (req, res) => {
    req.normalizedPath =  'POST /v2/providers'
    req.dependencies =  'SPLUNK'
    addProvidersCtrl(req, res)
  })
  router.get( '/recommended', (req, res) => {
    req.normalizedPath =  'GET /v2/providers/recommended'
    req.dependencies =  'STS:' + config.services.sts.root
    getRecommendedProvidersCtrl(req, res)
  })
  router.get( '/typeahead', (req, res) => {
    req.normalizedPath =  'GET /v2/providers/typeahead'
    req.dependencies =  'STS:' + config.services.sts.root
    getTypeaehaedProvidersCtrl(req, res)
  })
  router.get( '/:id', (req, res) => {
    req.normalizedPath =  'GET /v2/providers/:id'
    req.dependencies =  'PROVIDER:' + config.services.providers.root
    getProviderByIdCtrl(req, res)
  })
  router.get( '/ein/:ein', (req, res) => {
    req.normalizedPath =  'GET /v2/providers/ein/:ein'
    req.dependencies =  'PROVIDER:' + config.services.providers.root + ';' + 'SANGRIA:' + config.services.sangria.root
    getProviderByEINCtrl(req, res)
  })
}