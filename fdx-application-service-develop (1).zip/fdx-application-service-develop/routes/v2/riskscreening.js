import {
  getRiskLevel,
  assertRiskDetail
} from '../../services/rss'

import {
  verifyGoogleReCaptcha
} from '../../services/google'

import RequestVariables from '../../lib/request-variables'
import config from '../../lib/config'

const BLOCKED = 'blocked'
// const REVIEW = 'review'
const PASS = 'pass'


export default function screenRoute( router ) {
  // router.get( '/', getRiskProfile)
  router.post( '/', postRiskAssertion)
  router.post( '/validate', validateClientToken)
  router.post( '/status', getUserRiskStatusCtrl)
  router.post( '/feedback', postRiskAssertion)
}

export function validateClientToken( req, res ) {
  const body = { ...req.body }
  const reCaptchaValue = body.token

  verifyGoogleReCaptcha(req, reCaptchaValue)
    .then( response => {
      if ( response.body && response.body.success )
        res.status(200).send(response.body) 
      else 
        throw response.body 
    })
    .catch(error =>{
      res.status(400).send(new Error('google', error, req.headers, 400))
    })
}

export function getUserRiskStatusCtrl( req, res ) {
  const { providerId } = req.body || {}
  getRiskLevel(req, { providerId })
    .then(data=>{
      const { recommendation } = data.body || {}
      res.status(200).send({
        // we don't want the bad actor to know that they are blocked.
        // we let them go and allow FPOS to return the 103
        // This is at the recommendation of the RSS team
        recommendation: recommendation === BLOCKED ? PASS : recommendation
      })
    }).catch(()=>{
      res.status(200).send({ recommendation: PASS })
    })
}

export function postRiskAssertion( req, res ) {
  req.normalizedPath = 'GET /v2/riskscreening'
  req.dependencies =  `RSS: ${config.services.rss.root}`
  
  const { authid } = new RequestVariables( req )
  const { providerId, transaction } = req.body || {}

  if ( !providerId || !transaction ) {
    return res.status(400).send({ error: 'missing data providerId or transaction value' })
  }

  assertRiskDetail( req, { transaction, providerId, authid } )
    .then(()=>{
      res.status(204).send()
    }).catch(()=>{
      res.status(204).send()
    })

}