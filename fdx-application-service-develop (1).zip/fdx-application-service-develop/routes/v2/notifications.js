
import { 
  getNotifications
} from '../../controllers/notifications/notifications'
import config from  '../../lib/config'

export default router => {

  router.get('/', (req, res) => {
    req.normalizedPath =  'GET /v2/notifications'
    req.dependencies =  'CREDENTIALS:' + config.services.credentials.root + ';' + 'FDMS:' + config.services.fdms.root
    getNotifications(req, res)
  })

  
}
