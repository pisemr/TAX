import {
  acquireAccountsCtrl,
  refreshSubmitCtrl,
  mfaSubmitCtrl,
  fpoPollingCtrl,
  fpoCallbackCtrl
} from '../../controllers/accounts/accounts'
import config from  '../../lib/config'


export default router => {
  router.post( '/',  (req, res) => {
    req.normalizedPath =  'POST /v2/accounts'
    req.dependencies =  'FPO:' + config.services.fpo.root + ';' + 'CACHE:' + config.services.cache.root
    acquireAccountsCtrl(req, res)
  })
  router.get( '/:correlationId',  (req, res) => {
    req.normalizedPath =  'GET /v2/accounts/:correlationId'
    req.dependencies =  'FPO:' + config.services.fpo.root + ';' + 'CACHE:' + config.services.cache.root
    fpoPollingCtrl(req, res)
  })
  router.post( '/async',  (req, res) => {
    req.normalizedPath =  'POST /v2/accounts/async'
    req.dependencies =  'FPO:' + config.services.fpo.root + ';' + 'CACHE:' + config.services.cache.root
    fpoCallbackCtrl(req, res)
  })
  router.post( '/mfa',  (req, res) => {
    req.normalizedPath =  'POST /v2/accounts/mfa'
    req.dependencies =  'FPO:' + config.services.fpo.root + ';' + 'CACHE:' + config.services.cache.root
    mfaSubmitCtrl(req, res)
  })
  router.post( '/refresh',  (req, res) => {
    req.normalizedPath =  'POST /v2/accounts/refresh'
    req.dependencies =  'FPO:' + config.services.fpo.root + ';' + 'CACHE:' + config.services.cache.root
    refreshSubmitCtrl(req, res)
  })
}
