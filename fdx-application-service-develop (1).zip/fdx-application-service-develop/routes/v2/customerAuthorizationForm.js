import { customerAuthorizationFormCtrl } from '../../controllers/customerAuthorizationForm/customerAuthorizationForm'
import config from  '../../lib/config'

module.exports = function customerAuthorizationFormRouter(router) {
  router.post('/', (req, res) => {
    req.normalizedPath = 'POST /v2/realms/:parentid/providers/:providerId/customerAuthorizationForm'
    req.dependencies = 'FPO:' + config.services.fpo.root_v2
    customerAuthorizationFormCtrl(req, res)
  })
}
