
import {
  migrateCtrl
} from '../../controllers/migrations/migrations'
import config from  '../../lib/config'

export default router => {

  router.post('/migrate', (req, res) => {
    req.normalizedPath =  'POST /v2/migrations/migrate'
    req.dependencies =  'FDMS:' + config.services.fdms.root
    migrateCtrl(req, res)
  })

}
