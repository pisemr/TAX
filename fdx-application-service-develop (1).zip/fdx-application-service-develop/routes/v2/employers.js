import {
  getProviderByEINCtrl
} from '../../controllers/providers/providers'

import config from  '../../lib/config'

module.exports = function providersRoute( router ) {
  router.get( '/', (req, res) => {
    req.normalizedPath =  'GET /v2/employers'
    req.dependencies =  'PROVIDER:' + config.services.providers.root + ';' + 'SANGRIA:' + config.services.sangria.root
    getProviderByEINCtrl(req, res)
  })
}
