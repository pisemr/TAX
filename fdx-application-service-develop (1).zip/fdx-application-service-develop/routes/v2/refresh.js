import {
  fpoCtrl
} from '../../controllers/fpo/fpo'
import config from  '../../lib/config'

export default router => {
  router.post( '/',  (req, res) => {
    req.normalizedPath =  'POST /v2/refresh'
    req.dependencies =  'FPO:' + config.services.fpo.root + ';' + 'CACHE:' + config.services.cache.root
    fpoCtrl(req, res)
  })
}