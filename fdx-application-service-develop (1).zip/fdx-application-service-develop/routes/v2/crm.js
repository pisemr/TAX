import { createCRMCaseCtrl } from '../../controllers/crm/crm'

module.exports = function crmServiceRouter(router) {
  router.post('/', (req, res) => {
    createCRMCaseCtrl(req, res)
  })
}