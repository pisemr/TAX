import HealthCheck from '../services/health'
import config from '../lib/config'
import HealthWatcher from '../lib/HealthWatcher'

const watcher = new HealthWatcher()

function respondToHealthCheck(res) {
  if (!watcher.isOnline()) {
    res.status(503).send('Server offline')
  } else {
    res.status(200).send('Health Check Ok')
  }
}

module.exports = function healthCustomRouter( router ) {

  router.get('/full', function healthFull( req, res ) {
    if (req.query && req.query.timeout) {
      let timeout = req.query.timeout || 25000
      setTimeout(() => {
        respondToHealthCheck(res)
      }, timeout)
    }
    else {
      respondToHealthCheck(res)
    }
  })

  router.get('/local', function healthLocal( req, res ) {
    respondToHealthCheck(res)
  })

  router.get( '/dependencies', function getDependantServices( req, res ) {
    let healthCheck = new HealthCheck( req )
    healthCheck.getDependencies( ( err, data ) => {
      if ( !err ) {
        data.env = config.ENV
        res.status( 200 ).send( data )
      } else {
        res.status( 500 ).send( err )
      }
    } )
  } )

  router.get( '/build', function getStatus( req, res ) {
    let healthCheck = new HealthCheck( req )
    healthCheck.getBuild( function ( err, data ) {
      if ( !err ) {
        res.status( 200 ).send( data )
      } else {
        res.status( 500 ).send( err )
      }
    } )
  } )
}
