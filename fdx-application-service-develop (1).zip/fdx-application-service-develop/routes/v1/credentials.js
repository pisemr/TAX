
import { getCredentialsCtrl ,addCrededentialsCtrl ,updateCredentialsCtrl ,deleteProviderCredentialsCtrl ,deleteCredentialSetCtrl } from '../../controllers/credentials/credentials'
import config from  '../../lib/config'

module.exports = function credentialsRouter( router ) {
  router.get( '/',  (req, res) => {
    req.normalizedPath =  'GET /v1/credentials'
    req.dependencies =  'CREDENTIALS:' + config.services.credentials.root + ';' + 'PROFILE:' + config.services.profile.root
    getCredentialsCtrl(req, res)
  })
  router.get( '/:id',  (req, res) => {
    req.normalizedPath =  'GET /v1/credentials/:id'
    req.dependencies =  'CREDENTIALS:' + config.services.credentials.root + ';' + 'PROFILE:' + config.services.profile.root
    getCredentialsCtrl(req, res)
  })
  router.post( '/',  (req, res) => {
    req.normalizedPath =  'POST /v1/credentials'
    req.dependencies =  'CREDENTIALS:' + config.services.credentials.root + ';' + 'PROFILE:' + config.services.profile.root
    addCrededentialsCtrl(req, res)
  })
  router.put( '/:id',  (req, res) => {
    req.normalizedPath =  'PUT /v1/credentials/:id'
    req.dependencies =  'CREDENTIALS:' + config.services.credentials.root + ';' + 'PROFILE:' + config.services.profile.root
    updateCredentialsCtrl(req, res)
  })
  router.delete( '/:id',  (req, res) => {
    req.normalizedPath =  'DELETE /v1/credentials/:id'
    req.dependencies =  'CREDENTIALS:' + config.services.credentials.root + ';' + 'PROFILE:' + config.services.profile.root
    deleteCredentialSetCtrl(req, res)
  })
  router.delete( '/provider/:id',  (req, res) => {
    req.normalizedPath =  'DELETE /v1/credentials/provider/:id'
    req.dependencies =  'CREDENTIALS:' + config.services.credentials.root + ';' + 'PROFILE:' + config.services.profile.root
    deleteProviderCredentialsCtrl(req, res)
  })
}
