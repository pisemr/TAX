import objPath from 'object-path'
import config from  '../../lib/config'

module.exports = function documentsRouter(router) {
  router.get('/', function headerRoute(req, res) {
    req.normalizedPath =  'GET /v1/headers'
    req.dependencies =  ''
    let REQ = objPath(req)
    res.status(200).send(REQ.get('headers'))
  })
}
