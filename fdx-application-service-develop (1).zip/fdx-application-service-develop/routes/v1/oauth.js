import { authenticate, redirect } from '../../controllers/oauth'
import config from  '../../lib/config'


module.exports = function OauthRouter( router ) {
  //ROUTES
  router.get( '/',  (req, res) => {
    req.normalizedPath =  'GET /v1/oauth'
    req.dependencies =  'PARTNER_AUTH:' + config.services.partnerAuth.root
    authenticate(req, res)
  })
  router.get( '/redirect',  (req, res) => {
    req.normalizedPath =  'GET /v1/oauth/redirect'
    req.dependencies =  'PARTNER_AUTH:' + config.services.partnerAuth.root
    redirect(req, res)
  })
}
