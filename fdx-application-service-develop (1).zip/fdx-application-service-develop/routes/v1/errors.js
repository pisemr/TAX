
import logger from '../../lib/logger'
import config from  '../../lib/config'

module.exports = function errorsRoute( router ) {
  router.post( '/', function postError( req, res ) {
    req.normalizedPath =  'GET /v1/errors'
    req.dependencies =  ''
    let toLog = 'CLIENT_ERROR=true '
    let content = req.body
    for ( let property in content ) {
      if ({}.hasOwnProperty.call(content, property)) {
        toLog += property + '=\"' + content[ property ] + '\" '
      }
    }
    logger.error( toLog )
    res.status( 201 ).end()
  } )
}
