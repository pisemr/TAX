import conf from '../../lib/config'
import cache from '../../lib/cache'
import pjson from '../../package.json'

module.exports = function statusRouter(router) {
  router.get('/', function statusRoute(req, res) {
    req.normalizedPath =  'GET /v1/status'
    req.dependencies =  ''
    let data = {
      env: conf.ENV,
      build: pjson && pjson.build ? pjson.build : 'unavailable',
      cache: {
        lastCronTick: cache.get('lastCronRun') ? cache.get('lastCronRun') : 'Cron has not had a tick yet',
        providersCacheFromTask: cache.get('providersCachedFromCron') ? cache.get('providersCachedFromCron') : 'Providers not cached'
      }
    }
    res.status(200).send(data)
  })
}
