import { authenticateMFACtrl, authenticateCtrl } from '../../controllers/authenticate/authenticate'
import config from  '../../lib/config'

module.exports = function authenticateRouter( router ) {
  router.post( '/', authenticateCtrl )
  router.post( '/mfa', authenticateMFACtrl )

  /*router.post( '/',  (req, res) => {
    req.normalizedPath =  'GET /v1/authenticate'
    req.dependencies =  'INTERACTION:' + config.services.interaction.root + ";" + 'ACCESS:' + config.services.access.root
    authenticateCtrl(req, res)
  })
  router.post( '/mfa',  (req, res) => {
    req.normalizedPath =  'GET /v1/authenticate'
    req.dependencies =  'INTERACTION:' + config.services.interaction.root
    authenticateMFACtrl(req, res)
  })*/
}
