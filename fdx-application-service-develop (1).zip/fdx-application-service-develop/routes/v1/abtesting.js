import { getBucketAssignmentCtrl, assignBucketCtrl, createEventCtrl } from '../../controllers/abtesting/abtesting'
import config from  '../../lib/config'

module.exports = function abTestingRouter(router) {
  router.get( '/',  (req, res) => {
    req.normalizedPath =  'GET /v1/abtesting'
    req.dependencies =  'ABTESTING:' + config.services.ab.root
    getBucketAssignmentCtrl(req, res)
  })
  router.put( '/',  (req, res) => {
    req.normalizedPath =  'PUT /v1/abtesting'
    req.dependencies =  'ABTESTING:' + config.services.ab.root
    assignBucketCtrl(req, res)
  })
  router.post('/',  (req, res) => {
    req.normalizedPath =  'POST /v1/abtesting'
    req.dependencies =  'ABTESTING:' + config.services.ab.root
    createEventCtrl(req, res)
  })
}
