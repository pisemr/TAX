import { getAllProvidersCtrl, getProviderByEINCtrl } from '../../controllers/providers/providers'
import cache from '../../lib/cache'
import config from  '../../lib/config'

module.exports = function providersRoute( router ) {

  /*  freshProviderCall params:
   *  @res: object => express response object
   *  @req: object  => express request object
   *  @methodOverride : string => an override to the http Method ( this is used to call the correct function in the model )
   *  @shouldCache : bool => do we want to cache the response we get?
   */

  //ROUTES
  router.get( '/', function getProviders( req, res ) {
    if( req && req.query && req.query.ein ) {
      req.normalizedPath =  'GET /v1/providers/:ein'
      req.dependencies =  'PROVIDERS:' + config.services.providers.root
      getProviderByEINCtrl( req, res )
    }
    else {
      req.normalizedPath =  'GET /v1/providers'
      req.dependencies =  'PROVIDERS:' + config.services.providers.root
      getAllProvidersCtrl( req, res )
    }
  } )

  router.get( '/clear', function clearProvidersCache( req, res ) {
    req.normalizedPath =  'GET /v1/providers'
    req.dependencies =  ''

    let auth = req && req.query ? req.query.auth : null
    if ( auth === 'vaultAdminClearCache' ) {
      cache.del( 'cachedProviders' )
      res.status( 204 ).end()
    } else {
      res.status( 401 ).end()
    }
  } )
}
