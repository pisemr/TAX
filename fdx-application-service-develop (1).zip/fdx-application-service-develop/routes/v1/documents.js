
import { uploadDocumentToFolderCtrl, getDocumentCtrl, deleteDocumentCtrl } from '../../controllers/documents/documents'
import config from '../../lib/config'

module.exports = function documentsRouter( router ) {
  router.get( '/',  (req, res) => {
    req.normalizedPath =  'GET /v1/documents'
    req.dependencies =  'DOCUMENTS:' + config.services.documents.root
    getDocumentCtrl(req, res)
  })
  router.get( '/:documentId',  (req, res) => {
    req.normalizedPath =  'GET /v1/documents/:documentId'
    req.dependencies =  'DOCUMENTS:' + config.services.documents.root
    getDocumentCtrl(req, res)
  })
  router.put( '/folders/:id',  (req, res) => {
    req.normalizedPath =  'PUT /v1/documents/folders/:documentId'
    req.dependencies =  'DOCUMENTS:' + config.services.documents.root
    uploadDocumentToFolderCtrl(req, res)
  })
  router.delete( '/:documentId',  (req, res) => {
    req.normalizedPath =  'DELETE /v1/documents/:documentId'
    req.dependencies =  'DOCUMENTS:' + config.services.documents.root
    deleteDocumentCtrl(req, res)
  })
}
