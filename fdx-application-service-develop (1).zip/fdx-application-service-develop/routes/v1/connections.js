import { getConnectionsCtrl, getConnectionDetailCtrl, saveConnectionCtrl, removeConnectionCtrl } from '../../controllers/connections/connections'
import config from  '../../lib/config'

module.exports = function connectionsRouter( router ) {
  router.get( '/',  (req, res) => {
    req.normalizedPath =  'GET /v1/connections'
    req.dependencies =  'CREDENTIALS:' + config.services.credentials.root + ';' + 'PROFILE:' + config.services.profile.root
    getConnectionsCtrl(req, res)
  })
  router.get( '/credentials/:credentialSetId',  (req, res) => {
    req.normalizedPath =  'GET /v1/connections/credentials/:credentialSetId'
    req.dependencies =  'CREDENTIALS:' + config.services.credentials.root + ';' + 'PROFILE:' + config.services.profile.root
    getConnectionDetailCtrl(req, res)
  })
  router.put( '/',  (req, res) => {
    req.normalizedPath =  'PUT /v1/connections'
    req.dependencies =  'CREDENTIALS:' + config.services.credentials.root + ';' + 'PROFILE:' + config.services.profile.root
    saveConnectionCtrl(req, res)
  })
  router.delete( '/provider/:providerId',  (req, res) => {
    req.normalizedPath =  'DELETE /v1/connections/provider/:providerId'
    req.dependencies =  'CREDENTIALS:' + config.services.credentials.root + ';' + 'PROFILE:' + config.services.profile.root
    removeConnectionCtrl(req, res)
  })
  router.delete( '/provider/:providerId/credentials/:credentialSetId', (req, res) => {
    req.normalizedPath =  'DELETE /v1/connections/provider/:providerId/credentials/:credentialSetId'
    req.dependencies =  'CREDENTIALS:' + config.services.credentials.root + ';' + 'PROFILE:' + config.services.profile.root
    removeConnectionCtrl(req, res)
  })
}
