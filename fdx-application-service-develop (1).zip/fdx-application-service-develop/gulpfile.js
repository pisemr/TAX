require( 'babel-polyfill' )
var gulp = require( 'gulp' )
var gulpIf = require( 'gulp-if' )
var argv = require( 'yargs' ).boolean( 'report' ).argv
var runSequence = require( 'run-sequence' )
var mocha = require( 'gulp-mocha' )
var babel = require( 'babel-core/register' )
var istanbul = require( 'gulp-istanbul' )
var isparta = require( 'isparta' )
var config = require( 'gulp-config' )( gulp, {
    tasks: [ './test/tasks/*.js' ]
  } )

//OJC 9-23-15
//this process.env.PWD hack is needed to thwart a bug in the isp module, core-class.js to be specific.
//it's assuming process.env.PWD is where the gulfile is, which isn't always the case (for example, when launched
//in webstorm or from a different root directory
process.env.PWD = __dirname
process.env.NODE_ENV = 'test'

var tests = [
  './test/**/*.spec.js',
  '!./test/functional/**/*.spec.js'
]

gulp.task( 'test', [ 'lint', 'pre-test' ], function () {
  return gulp.src( tests, {
    read: false
  } )
    .pipe( mocha( {
      reporter: 'spec',
      compilers: {
        js: babel
      }
    } ) )

  .pipe( gulpIf( argv.report, istanbul.writeReports( {
    dir: './static/coverage',
    reporters: ['clover', 'lcov', 'json', 'json-summary', 'cobertura']
  } ) ) )
    .pipe( istanbul.enforceThresholds( {
      thresholds: {
        global: {
          statements: 80,
          branches: 50, // Reduced becauase Branches are generally guards against bad params. TODO: stop using branches and use default vaules
          lines: 80,
          functions: 80
        }
      }
    } ) )
    .once( 'error', function ( ) {
      console.log('Code Coverage is lower than expected...')
      process.exit( 1 )
    } )
    .once( 'end', function () {
      process.exit()
    } )
} )

gulp.task( 'pre-test', function () {

  return gulp.src( [ './controllers/**/*.js', './middleware/**/*.js', './models/**/*.js', './services/**/*.js', './lib/**/*.js', '!./lib/logger.js', '!./lib/crypt.js', '!./lib/request.js', '!./models/import/document-commonAttributes.js ' ] )
    // Covering files
    .pipe( istanbul( {
      instrumenter: isparta.Instrumenter // Use the isparta instrumenter (code coverage for ES6)
        // Istanbul configuration (see https://github.com/SBoudrias/gulp-istanbul#istanbulopt)
        // ...
    } ) )
    // Force `require` to return covered files
    .pipe( istanbul.hookRequire() )
} )

gulp.task( 'default', [ 'test' ] )

gulp.task( 'release', function ( cb ) {
  runSequence( 'default', 'bump', cb )
} )
