import url from 'url'
import requestPromise from '../lib/vault-request-promise'
import RequestVariables from '../lib/request-variables'
import config from '../lib/config'

const SERVICE_NAME = 'access'
const ACCESS_ROOT = config.services.access.root
//check for unique protocol setting for service, otherwise fall back to default
const PROTOCAL = config.services.access.protocal || config.services.protocal

const ENTITY_GROUPS = {
  '1099': [
    '1099-INT',
    '1099-DIV',
    '1099-INT',
    '1099-OID',
    '1099-B',
    '1099-R',
    '1099-MISC',
    '1099-G'
  ],
  '1098': [
    '1098-E',
    '1098-T',
    '1098'
  ],
  '1040': [
    '1040',
    '1040-A',
    '1040-EZ'
  ]
}

function getEntities(input) {
  if (Array.isArray(input)) {
    return input
  }
  else {
    return ENTITY_GROUPS[input.toString().toLowerCase()] || [ input.toString().toUpperCase() ]
  }
}

class AccessPostBodyModel {
  constructor( body ) {
    this.providerId = body.providerId
    this.credentialParams = {
      credential : body.credentials.map(credential=>{
        return {
          authenticationFieldType: credential.authenticationFieldType,
          type: credential.type,
          authenticationFieldId: credential.id,
          encrypted: credential.encrypted,
          certVersion: credential.certVersion,
          authenticationFieldValue: credential.value
        }
      }),
      certVersion: 'v01_credential_service_cryption_nonprod_key.corp.intuit.net'
    }
    this.persistenceParams = {
      folderId: body.folderId,
      persistAsync: false
    }
    this.taxYear = body.taxYear
    this.is7216 = body.is7216
    this.entityTypes = body.entityType ? getEntities(body.entityType) : getEntities(body.entityTypes)
  }
}

function authenticateAndGetDocuments( request ) {

  let { headers, originalUrl } = new RequestVariables( request )

  let postBody = new AccessPostBodyModel( request.body )
  headers.addHeader('intuit_error_code_version', '2.0')

  //check if payload version has been sent by client, if so add additional header
  if ( request.body && request.body.payloadVersion ) {
    headers.addHeader('accept', `application/json;version=${request.body.payloadVersion}`)
  }

  let path = url.format( {
    protocol: PROTOCAL,
    host: ACCESS_ROOT,
    pathname: 'access'
  } )

  let options = {
    method: 'POST',
    url: path,
    headers: headers,
    body: postBody,
    serviceName: SERVICE_NAME,
    reqPath: originalUrl
  }

  return requestPromise( options )

}

exports.authenticateAndGetDocuments = authenticateAndGetDocuments


// {
// 	"credentialParams": {
// 		"credential": [{
// 			"type": "nonSecret",
// 			"encrypted": false,
// 			"certVersion": "v01_credential_service_cryption_nonprod_key.corp.intuit.net",
// 			"authenticationFieldId": "1e292fc4-d68f-4bea-9e75-ea28602830f2",
// 			"authenticationFieldValue": "200_{W2}5"
// 		}, {
// 			"type": "nonSecret",
// 			"encrypted": false,
// 			"certVersion": "v01_credential_service_cryption_nonprod_key.corp.intuit.net",
// 			"authenticationFieldId": "d78b2a16-a3ba-436b-b2fd-0aea749cfe5c",
// 			"authenticationFieldValue": "200_{W2}5"
// 		}, {
// 			"type": "nonSecret",
// 			"encrypted": false,
// 			"certVersion": "v01_credential_service_cryption_nonprod_key.corp.intuit.net",
// 			"authenticationFieldId": "5ed7efe0-e028-4249-a633-2891231a8e06",
// 			"authenticationFieldValue": "200_{W2}5"
// 		}]
// 	},
// 	"persistenceParams": {
// 		"folderId": "b27d6203-66a4-4417-b3a8-4103ff3a794a",
// 		"persistAsync": false
// 	},
// 	"taxYear": 2015,
// 	"is7216": true,
// 	"providerId": "2677fd8a-dd2f-4078-aa8e-fa3ab4161fa5",
// 	"entityTypes": ["W2"]
// }
