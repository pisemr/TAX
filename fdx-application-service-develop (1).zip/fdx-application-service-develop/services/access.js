import url from 'url'
import requestPromise from '../lib/vault-request-promise'
import RequestVariables from '../lib/request-variables'
import config from '../lib/config'
import PostBody from '../models/post-body-model'

const SERVICE_NAME = 'accessV1'
const ACCESS_ROOT = config.services.access.root
const PROTOCAL = config.services.protocal

function verifyAccessService( request ) {

  let { headers, originalUrl } = new RequestVariables( request )

  let postBody = new PostBody( request.body )
  postBody.formatForDocuments()

  headers.addHeader('intuit_error_code_version', '2.0')

  let path = url.format( {
    protocol: PROTOCAL,
    host: ACCESS_ROOT,
    pathname: 'access'
  } )

  let options = {
    method: 'POST',
    url: path,
    headers: headers,
    body: postBody.bodyForRequest,
    serviceName: SERVICE_NAME,
    reqPath: originalUrl
  }

  return requestPromise( options )

}

exports.verifyAccessService = verifyAccessService
