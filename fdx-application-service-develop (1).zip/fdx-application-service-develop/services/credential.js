import url from 'url'
import requestPromise from '../lib/vault-request-promise'
import RequestVariables from '../lib/request-variables'
import config from '../lib/config'

const SERVICE_NAME = 'credentials'
const CREDENTIALS_ROOT = config.services.credentials.root
const CREDENTIALS_ROOT_V2 = config.services.credentials.root_v2
// const CREDENTIALS_ROOT_QAL = config.services.credentials.root_QAL
const ID_DOMAIN = config.services.fpo.iddomain
const REALM_GET_CREDENTIALSET = config.services.credentials.realmGetCredentialSetByCredentialSetId
const USERS_GET_CREDENTIALSET = config.services.credentials.userGetCredentialSetByCredentialSetId
const REALM_GET_PRIVATE_KEY = config.services.credentials.getPrivateKeyRealmContext
const USERS_GET_PRIVATE_KEY = config.services.credentials.getPrivateKeyUserContext


function getCredentialSetDetail( request, credId ) {
  let { headers, originalUrl } = new RequestVariables( request )
  let pathname = 'credentials/' + credId
  let path = url.format( {
    protocol: 'https',
    host: CREDENTIALS_ROOT,
    pathname: pathname
  } )

  let options = {
    method: 'GET',
    url: path,
    rejectUnauthorized: false,
    headers: headers,
    serviceName: SERVICE_NAME,
    reqPath: originalUrl
  }

  return requestPromise( options )

}

function getAllCredentials( request ) {
  let { headers, originalUrl } = new RequestVariables( request )
  let pathname = 'providers'
  let path = url.format( {
    protocol: 'https',
    host: CREDENTIALS_ROOT,
    pathname: pathname
  } )

  let options = {
    method: 'GET',
    url: path,
    rejectUnauthorized: false,
    headers: headers,
    serviceName: SERVICE_NAME,
    reqPath: originalUrl
  }

  return requestPromise( options )

}

function addCredentials( request, payload ) {
  let { headers, originalUrl } = new RequestVariables( request )
  let path = url.format( {
    protocol: 'https',
    host: CREDENTIALS_ROOT,
    pathname: 'credentials'
  } )
  let options = {
    method: 'POST',
    url: path,
    rejectUnauthorized: false,
    headers: headers,
    body: payload,
    serviceName: SERVICE_NAME,
    reqPath: originalUrl
  }

  return requestPromise( options )

}

function updateCredentials( request, credId, payload ) {
  let { headers, originalUrl } = new RequestVariables( request )
  let path = url.format( {
    protocol: 'https',
    host: CREDENTIALS_ROOT,
    pathname: 'credentials/' + credId
  } )
  let options = {
    method: 'PUT',
    url: path,
    rejectUnauthorized: false,
    headers: headers,
    body: payload,
    serviceName: SERVICE_NAME,
    reqPath: originalUrl
  }

  return requestPromise( options )

}

function deleteCredentialSet(request, credId ) {
  let { headers, originalUrl, authid, parentid } = new RequestVariables( request )
  headers.addHeader( 'intuit_iddomain', ID_DOMAIN )
  let profileType = request.body.isRealmContext ? 'realms' : 'users'
  const authType = request.body.isRealmContext ? parentid : authid

  let path = url.format( {
    protocol: 'https',
    host: CREDENTIALS_ROOT_V2,
    pathname: profileType + '/' + authType + '/credentials/' + credId
  } )
  let options = {
    method: 'DELETE',
    url: path,
    rejectUnauthorized: false,
    headers: headers,
    serviceName: SERVICE_NAME,
    reqPath: originalUrl
  }

  return requestPromise( options )
}

function deleteAllProviderCredentials( request, providerId ) {
  let { headers, originalUrl, authid, parentid } = new RequestVariables( request )
  headers.addHeader( 'intuit_iddomain', ID_DOMAIN )
  let profileType = request.body.isRealmContext ? 'realms' : 'users'
  const authType = request.body.isRealmContext ? parentid : authid

  let path = url.format( {
    protocol: 'https',
    host: CREDENTIALS_ROOT_V2,
    pathname: profileType + '/' + authType + '/providers/' + providerId
  } )
  let options = {
    method: 'DELETE',
    url: path,
    rejectUnauthorized: false,
    headers: headers,
    serviceName: SERVICE_NAME,
    reqPath: originalUrl
  }

  return requestPromise( options )
}

function getProvidersByUserId( request ) {
  let { headers, originalUrl, authid, parentid } = new RequestVariables( request )
  headers.addHeader( 'intuit_iddomain', ID_DOMAIN )
  const isRealmContext = request.query && request.query.isRealmContext === 'true'
  let profileType = isRealmContext ? 'realms' : 'users'
  let authType = isRealmContext ? parentid : authid 

  let path = url.format( {
    protocol: 'https',
    host: CREDENTIALS_ROOT_V2,
    pathname: profileType + '/' + authType + '/providers'
  } )
  let options = {
    method: 'GET',
    url: path,
    rejectUnauthorized: false,
    headers: headers,
    serviceName: SERVICE_NAME,
    reqPath: originalUrl
  }

  return requestPromise( options )
}

function getCredentialSetByCredentialSetId(request, credId) {
  let { headers, originalUrl, authid, parentid } = new RequestVariables( request )
  headers.addHeader( 'intuit_iddomain', ID_DOMAIN )
  const isRealmContext = request.query && request.query.isRealmContext === 'true'
  let credPath = isRealmContext ?  REALM_GET_CREDENTIALSET : USERS_GET_CREDENTIALSET
  let authType = isRealmContext ? parentid : authid
  let pathname = credPath.replace(/{authId}/, authType ).replace(/{credentialSetId}/, credId)
  let path = url.format( {
    protocol: 'https',
    host: CREDENTIALS_ROOT_V2,
    pathname: pathname
  } )

  let options = {
    method: 'GET',
    url: path,
    rejectUnauthorized: false,
    headers: headers,
    serviceName: SERVICE_NAME,
    reqPath: originalUrl
  }

  return requestPromise( options )  
}

function getPrivateKeyByUserId(request) {
  let { headers, originalUrl, authid, parentid } = new RequestVariables( request )
  headers.addHeader( 'intuit_iddomain', ID_DOMAIN )
  const isRealmContext = request.query && request.query.isRealmContext === 'true'
  let credPath = isRealmContext ?  REALM_GET_PRIVATE_KEY : USERS_GET_PRIVATE_KEY
  let authType = isRealmContext ? parentid : authid
  let pathname = credPath.replace(/{authId}/, authType )
  let path = url.format( {
    protocol: 'https',
    host: CREDENTIALS_ROOT_V2,
    pathname: pathname
  } )

  let options = {
    method: 'GET',
    url: path,
    rejectUnauthorized: false,
    headers: headers,
    serviceName: SERVICE_NAME,
    reqPath: originalUrl
  }

  return requestPromise( options )  
}


exports.getCredentialSetDetail = getCredentialSetDetail
exports.getAllCredentials = getAllCredentials
exports.addCredentials = addCredentials
exports.updateCredentials = updateCredentials
exports.deleteCredentialSet = deleteCredentialSet
exports.deleteAllProviderCredentials = deleteAllProviderCredentials
exports.getProvidersByUserId = getProvidersByUserId
exports.getCredentialSetByCredentialSetId = getCredentialSetByCredentialSetId
exports.getPrivateKeyByUserId = getPrivateKeyByUserId
