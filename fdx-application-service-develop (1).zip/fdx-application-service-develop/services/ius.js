import url from 'url'
import requestPromise from '../lib/vault-request-promise'
import RequestVariables from '../lib/request-variables'
import config from '../lib/config'

const SERVICE_NAME = 'ius'
const IUS_ROOT = config.services.ius.root
const IUS_PATH = config.services.ius.path
const PROTOCAL = config.services.protocal


function iusUserData( request ) {
  let { headers, originalUrl, } = new RequestVariables( request )
  
  headers.stripAuthAttribute('intuit_realmid')
  
  let path = url.format( {
    protocol: PROTOCAL,
    host: IUS_ROOT,
    pathname: IUS_PATH
  } )

  let options = {
    method: 'GET',
    url: path,
    rejectUnauthorized: false,
    headers: headers,
    serviceName: SERVICE_NAME,
    reqPath: originalUrl
  }

  return requestPromise( options )

}

exports.iusUserData = iusUserData
