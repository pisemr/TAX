import url from 'url'
import requestPromise from '../lib/vault-request-promise'
import RequestVariables from '../lib/request-variables'
import RiskAssertionModel from '../models/riskscreening/RiskAssertionModel'
import config from '../lib/config'

const SERVICE_NAME = 'rss'
const RSS_ROOT = config.services.rss.root
const RSS_RISK_ASSESMENT_PATH = config.services.rss.path.riskAssesment
const RSS_RISK_ASSERTION_PATH = config.services.rss.path.assertion
const POLICY = config.services.rss.namespace
const PROTOCAL = config.services.protocal


function getRiskLevel( request, { providerId, userId } ) {
  let { headers, originalUrl, authid } = new RequestVariables( request )

  let path = url.format( {
    protocol: PROTOCAL,
    host: RSS_ROOT,
    pathname: `${RSS_RISK_ASSESMENT_PATH}`
  } )

  return requestPromise({
    method: 'POST',
    url: path,
    headers: headers,
    body: { 
      userId, 
      userAuthId: authid,
      riskAttributes: [ {   
        namespace: POLICY,
        key:'fiProviderId',
        values:[ providerId ]
      } ]
    },
    serviceName: SERVICE_NAME,
    reqPath: originalUrl
  })
}

function assertRiskDetail( request, { transaction, providerId, authid } ) {
  const { headers, originalUrl } = new RequestVariables( request )

  let path = url.format( {
    protocol: PROTOCAL,
    host: RSS_ROOT,
    pathname: RSS_RISK_ASSERTION_PATH
  } )

  return requestPromise({
    method: 'POST',
    url: path,
    headers: headers,
    body: new RiskAssertionModel({ transaction, providerId, authid }),
    serviceName: SERVICE_NAME,
    reqPath: originalUrl
  })

}

exports.getRiskLevel = getRiskLevel
exports.assertRiskDetail = assertRiskDetail