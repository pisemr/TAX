import url from 'url'
import requestPromise from '../lib/vault-request-promise'
import RequestVariables from '../lib/request-variables'
import config from '../lib/config'
import PostBody from '../models/post-body-model'

const SERVICE_NAME = 'interaction'
const AVS_ROOT = config.services.interaction.root
const PROTOCAL = config.services.protocal


function verfiyMFA( request ) {
  let { headers, originalUrl, authid } = new RequestVariables( request )

  let postBody = new PostBody( request.body )
  postBody.formatMfa()

  let path = url.format( {
    protocol: PROTOCAL,
    host: AVS_ROOT,
    pathname: `profiles/${authid}/providers`
  } )

  let options = {
    method: 'POST',
    url: path,
    headers: headers,
    body: postBody.bodyForRequest,
    serviceName: SERVICE_NAME,
    reqPath: originalUrl
  }

  return requestPromise( options )
}

function verifyAccount( request ) {
  let { headers, originalUrl, authid } = new RequestVariables( request )

  let postBody = new PostBody( request.body )
  postBody.formatForAccounts()

  let path = url.format( {
    protocol: PROTOCAL,
    host: AVS_ROOT,
    pathname: `profiles/${authid}/providers`
  } )

  let options = {
    method: 'POST',
    url: path,
    headers: headers,
    body: postBody.bodyForRequest,
    serviceName: SERVICE_NAME,
    reqPath: originalUrl
  }

  return requestPromise( options )

}

function listAccountsForProvider( request, providerId ) {
  const { headers, originalUrl, authid, parentid } = new RequestVariables( request )
  const isRealmContext = request.query && request.query.isRealmContext === 'true'
  const profileType =  isRealmContext ? 'realms' : 'users'
  const id = isRealmContext ? parentid : authid
  const postBody = new PostBody( request.body )
  postBody.formatAccountsSearch(providerId)

  const path = url.format( {
    protocol: PROTOCAL,
    host: AVS_ROOT,
    pathname: `${profileType}/${id}/accounts/search`
  } )

  const options = {
    method: 'POST',
    url: path,
    headers: headers,
    body: postBody.bodyForRequest,
    serviceName: SERVICE_NAME,
    reqPath: originalUrl
  }

  return requestPromise( options )
}

exports.verifyAccount = verifyAccount
exports.verfiyMFA = verfiyMFA
exports.listAccountsForProvider = listAccountsForProvider
