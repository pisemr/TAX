import url from 'url'
import requestPromise from '../lib/vault-request-promise'
import RequestVariables from '../lib/request-variables'
import config from '../lib/config'
import PostBody from '../models/post-body-model'

const SERVICE_NAME = 'profile'
const PROFILE_ROOT = config.services.profile.root
const PROTOCAL = config.services.protocal


function addCredentialSet( request, payload ) {
  let { headers, originalUrl } = new RequestVariables( request )

  let postBody = new PostBody()
  postBody.formatProfileService( payload )

  let path = url.format( {
    protocol: PROTOCAL,
    host: PROFILE_ROOT,
    pathname: 'profiles'
  } )
  let options = {
    method: 'PUT',
    url: path,
    rejectUnauthorized: false,
    headers: headers,
    body: postBody.bodyForRequest,
    serviceName: SERVICE_NAME,
    reqPath: originalUrl
  }

  return requestPromise( options )

}

function removeCredentialSet( request, providerId, credentialSetId ) {
  let { headers, originalUrl, userAuthId } = new RequestVariables( request )


  let path = url.format( {
    protocol: PROTOCAL,
    host: PROFILE_ROOT,
    pathname: `profiles/${userAuthId}/providers/${providerId}/credentials/${credentialSetId}`
  } )
  let options = {
    method: 'DELETE',
    url: path,
    rejectUnauthorized: false,
    headers: headers,
    serviceName: SERVICE_NAME,
    reqPath: originalUrl
  }

  return requestPromise( options )

}

function removeProviderProfile( request, providerId ) {
  let { headers, originalUrl, userAuthId } = new RequestVariables( request )

  let path = url.format( {
    protocol: PROTOCAL,
    host: PROFILE_ROOT,
    pathname: `profiles/${userAuthId}/providers/${providerId}`
  } )
  let options = {
    method: 'DELETE',
    url: path,
    rejectUnauthorized: false,
    headers: headers,
    serviceName: SERVICE_NAME,
    reqPath: originalUrl
  }

  return requestPromise( options )

}

function getProfile( request ) {
  let { headers, originalUrl  } = new RequestVariables( request )

  let path = url.format( {
    protocol: PROTOCAL,
    host: PROFILE_ROOT,
    pathname: 'profiles'
  } )

  let options = {
    method: 'GET',
    url: path,
    rejectUnauthorized: false,
    headers: headers,
    serviceName: SERVICE_NAME,
    reqPath: originalUrl
  }

  return requestPromise( options )

}

exports.getProfile = getProfile
exports.removeProviderProfile = removeProviderProfile
exports.removeCredentialSet = removeCredentialSet
exports.addCredentialSet = addCredentialSet
