import url from 'url'
import moment from 'moment'
import request from '../lib/vault-request'
import requestPromise from '../lib/vault-request-promise'
import RequestVariables from '../lib/request-variables'
import config from '../lib/config'
import Error from '../models/Error'

const SERVICE_NAME = 'document'
const DOCUMENT_ROOT = config.services.documents.root
const PROTOCAL = config.services.protocal

//takes whole request since we need to stream the request directly to the upstream service
function uploadDocumentToFolder( req, folderId ) {
  let path = url.format( {
    protocol: PROTOCAL,
    host: DOCUMENT_ROOT,
    pathname: `/folders/${folderId}/documents`
  } )

  return new Promise( ( resolve, reject ) => {
    let documentRequest = request( {
      method: 'PUT',
      url: path,
    }, ( innerError, response ) => {
      if ( response.statusCode === 201 && !!response.headers.location ) {
        let location = response.headers.location

        resolve( {
          location,
          documentId: location.replace( /.*\/documents\//, '' ),
          folderId: location.replace( /.*\/folders\//, '' ).replace( /\/documents.*/, '' )
        } )
      } else {
        reject( new Error( 'document', innerError, req.headers, response.statusCode ) )
      }
    } )

    req.pipe( documentRequest )
  } )
}

function uploadDocument( req, syncExtraction ) {

  let { headers, originalUrl, } = new RequestVariables( req )
  headers.addHeader('accept', req.headers['accept'])
  headers.contentType = req.headers['content-type']

  let path = url.format( {
    protocol: PROTOCAL,
    host: DOCUMENT_ROOT,
    pathname: '/documents'
  } )

  path = url.resolve(path, '?syncExtraction=' + syncExtraction)
  return new Promise( ( resolve, reject ) => {
    let documentRequest = request( {
      method: 'POST',
      url: path,
      headers: headers
    }, ( innerError, response ) => {
      if ( response.statusCode === 201 && !!response.headers.location ) {
        let location = response.headers.location

        resolve( {
          location,
          documentId: location.replace( /.*\/documents\//, '' ),
          folderId: location.replace( /.*\/folders\//, '' ).replace( /\/documents.*/, '' )
        } )
      } else {
        reject( new Error( 'document', innerError, req.headers, response.statusCode ) )
      }
    } )

    req.pipe( documentRequest )
  } )
}

function getDocuments( request, documentId ) {
  let { headers, originalUrl, } = new RequestVariables( request )
  let pathname = 'documents'
  let query

  if( documentId ) {
    pathname = `${pathname}/${documentId}`
    query = {
      includeSource: false
    }
  }

  let path = url.format( {
    protocol: PROTOCAL,
    host: DOCUMENT_ROOT,
    pathname: pathname,
    query: query
  } )

  let options = {
    method: 'GET',
    url: path,
    headers: headers,
    encoding: null,
    serviceName: SERVICE_NAME,
    reqPath: originalUrl
  }

  return requestPromise( options )

}

function updateDocument( request, documentId, payload) {

  let { headers, originalUrl, } = new RequestVariables( request )

  headers.addHeader('If-Unmodified-Since', moment.utc().add( 1, 'h' ).toDate().toUTCString())

  let path = url.format( {
    protocol: PROTOCAL,
    host: DOCUMENT_ROOT,
    pathname: 'documents/' + documentId
  } )

  let options = {
    method: 'PUT',
    url: path,
    headers: headers,
    json: payload,
    serviceName: SERVICE_NAME,
    reqPath: originalUrl
  }

  return requestPromise( options )

}


function getSource( request, documentId) {

  let { headers, originalUrl, } = new RequestVariables( request )

  let path = url.format( {
    protocol: PROTOCAL,
    host: DOCUMENT_ROOT,
    pathname: 'documents/' + documentId + '/sources/1'
  } )

  let options = {
    method: 'GET',
    url: path,
    headers: headers,
    encoding: null,
    serviceName: SERVICE_NAME,
    reqPath: originalUrl
  }

  return requestPromise( options )

}


function getAlternativeData( request, documentId ) {

  let { headers, originalUrl, } = new RequestVariables( request )

  let path = url.format( {
    protocol: PROTOCAL,
    host: DOCUMENT_ROOT,
    pathname: 'documents/' + documentId + '/alternateData/rawSemanticData',
    query: {
      format: 'pdf'
    }
  } )
  let options = {
    method: 'GET',
    url: path,
    headers: headers,
    encoding: null,
    serviceName: 'Sources',
    reqPath: originalUrl
  }

  return requestPromise( options )

}


function deleteDocument( request, documentId ) {

  let { headers, originalUrl } = new RequestVariables( request )

  headers.addHeader('If-Unmodified-Since', moment.utc().add( 1, 'h' ).toDate().toUTCString())

  let path = url.format( {
    protocol: PROTOCAL,
    host: DOCUMENT_ROOT,
    pathname: 'documents/' + documentId
  } )

  let options = {
    method: 'DELETE',
    url: path,
    headers: headers,
    serviceName: SERVICE_NAME,
    reqPath: originalUrl
  }

  return requestPromise( options )

}

function getDocumentsFrmFolder( req, folderId ) {
  let { headers, originalUrl, } = new RequestVariables( req )
  let pathname = '/folders'
  let query = {}

  if( folderId ) {
    pathname = `${pathname}/${folderId}`
    query = {
      includeLocators: true
    }
  }
  else {
    pathname = `${pathname}/`
    query = {
      ownership: 'owned'
    }
  }

  let path = url.format( {
    protocol: 'https',
    host: DOCUMENT_ROOT,
    pathname: pathname,
    query: query
  } )

  let options = {
    method: 'GET',
    url: path,
    headers: headers,
    encoding: null,
    serviceName: SERVICE_NAME,
    reqPath: originalUrl
  }
  return requestPromise( options )
}

function createFolder(req, folderName) {
  let { headers, originalUrl, } = new RequestVariables( req )
  let pathname = '/folders'

  let path = url.format( {
    protocol: 'https',
    host: DOCUMENT_ROOT,
    pathname: pathname,
  } )

  let options = {
    method: 'POST',
    url: path,
    headers: headers,
    params: {},
    serviceName: SERVICE_NAME,
    reqPath: originalUrl,
    body: {
      name: folderName,
      description: folderName,
      parentId: 'root'
    }
  }
  return requestPromise( options )
}
exports.getDocuments = getDocuments
exports.getSource = getSource
exports.getAlternativeData = getAlternativeData
exports.uploadDocument = uploadDocument
exports.uploadDocumentToFolder = uploadDocumentToFolder
exports.updateDocument = updateDocument
exports.deleteDocument = deleteDocument
exports.getDocumentsFrmFolder = getDocumentsFrmFolder
exports.createFolder = createFolder
