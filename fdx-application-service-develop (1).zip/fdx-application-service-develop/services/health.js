import url from 'url'
import async from 'async'
import _ from 'lodash'
import request from '../lib/vault-request'
import Headers from '../lib/intuit-headers'
import config from '../lib/config'
import pjson from '../package.json'

const PROTOCAL = config.services.protocal

function HealthCheckModel( req ) {
  this.headers = new Headers( req )
}
HealthCheckModel.prototype = {
  getBuild: function getBuild( callback ) {
    let data = {
      env: config.ENV,
      build: pjson && pjson.build ? pjson.build : 'unavailable',
    }

    callback( null, data )
  },

  getDependencies: function getDependencies( callback ) {
    let self = this

    let requestObjects = {}
    let dependencies = [ {
      service: 'providers'
    }, {
      service: 'credentials'
    }, {
      service: 'documents'
    }, {
      service: 'access'
    }, {
      service: 'interaction'
    }, {
      service: 'profile'
    }, {
      service: 'partnerAuth'
    } ]

    _.forEach( dependencies, function getDependenciesForEachDependencies( dependency ) {
      requestObjects[ dependency.service ] = function getDependenciesRequestObjects( asyncCallback ) {
        let path = url.format( {
          protocol: PROTOCAL,
          host: config.services[ dependency.service ].health
        } )
        let options = {
          method: 'GET',
          url: path,
          rejectUnauthorized: false,
          headers: self.headers,
          serviceName: dependency.service.replace( /\w\S*/g, function ( txt ) {
            return txt.charAt( 0 ).toUpperCase() + txt.substr( 1 ).toLowerCase()
          } )
        }
        request( options, function getDependenciesRequest( error, response, body ) {
          if ( !error && response.statusCode === 200 ) {
            let results = {}
            results.path = path
            results.statusCode = response.statusCode
            results.response = body
            return asyncCallback( null, results )
          } else {
            return asyncCallback( error )
          }
        } )
      }
    } )

    async.parallel( requestObjects,
      function getDependenciesAsyncParallel( err, data ) {
        if ( !err ) {
          return callback( null, data )
        } else {
          return callback( err )
        }
      } )

  }
}

module.exports = HealthCheckModel
