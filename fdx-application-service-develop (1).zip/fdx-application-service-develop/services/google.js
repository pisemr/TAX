import url from 'url'
import requestPromise from '../lib/vault-request-promise'
import RequestVariables from '../lib/request-variables'
import config from '../lib/config'

const SERVICE_NAME = 'google'
const PROTOCAL = config.services.protocal
const GOOGLE_ROOT = config.services.google.root
const GOOGLE_SITEVERIFY_PATH = config.services.google.path.siteverify
const GOOGLE_API_KEY = config.services.google.apiKey
const GOOGLE_TEST_API_KEY = config.services.google.testApiKey
const allowReCaptchaOverride = config.allowReCaptchaOverride


function verifyGoogleReCaptcha( request, value ) {
  let { originalUrl } = new RequestVariables( request )
  const KEY = allowReCaptchaOverride && request.query.isTestReCaptcha ? GOOGLE_TEST_API_KEY : GOOGLE_API_KEY

  let path = url.format( {
    protocol: PROTOCAL,
    host: GOOGLE_ROOT,
    pathname: GOOGLE_SITEVERIFY_PATH,
    query: {
      secret: KEY,
      response: value
    }
  } )

  let options = {
    method: 'GET',
    url: path,
    // headers: headers,
    serviceName: SERVICE_NAME,
    reqPath: originalUrl
  }

  return requestPromise( options )
}

exports.verifyGoogleReCaptcha = verifyGoogleReCaptcha
