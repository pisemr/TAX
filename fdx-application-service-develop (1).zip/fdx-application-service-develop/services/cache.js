import url from 'url'
import objectPath from 'object-path'
import requestPromise from '../lib/vault-request-promise'
import RequestVariables from '../lib/request-variables'
import config from '../lib/config'
import Headers from '../lib/intuit-headers'

const SERVICE_NAME = 'cache'
const CACHE_ROOT = config.services.cache.root
const TICKETLESS_PATH = config.services.cache.ticketlessPath
const PROTOCAL = config.services.protocal
const KEY_PREFIX = config.services.cache.entryPrefix
const TIME_TO_LIVE = config.services.cache.timeToLive

function addToCache( request, cacheEntry ) {

  let { originalUrl, authid } = new RequestVariables( request )
  let headers = new Headers( request )
  //The cache service needs text/plain as the content type
  headers.addHeader( 'Content-Type', 'text/plain' )
  headers.stripAuthAttribute('intuit_realmid')
  let pathname = KEY_PREFIX + cacheEntry.correlationId
  let authId = objectPath.get(request.headers, 'intuit_userid',  authid)
  let query = {
    ttl: TIME_TO_LIVE
  }

  if (config.services.cache.ticketless) {
    pathname = TICKETLESS_PATH + pathname
    query.owner = authId
    headers.stripAuthAttribute('intuit_token')
    headers.stripAuthAttribute('intuit_token_type')
    headers.stripAuthAttribute('intuit_userid')
  }

  let path = url.format( {
    protocol: PROTOCAL,
    host: CACHE_ROOT,
    pathname: pathname,
    query: query
  } )

  let options = {
    method: 'PUT',
    url: path,
    headers: headers,
    body: cacheEntry,
    serviceName: SERVICE_NAME,
    reqPath: originalUrl
  }

  return requestPromise( options )
}

function retrieveFromCache( request, correlationId ) {

  let { originalUrl, authid } = new RequestVariables( request )
  let headers = new Headers( request )

  //The cache service needs text/plain as the content type
  headers.addHeader( 'Content-Type', 'text/plain' )
  headers.stripAuthAttribute('intuit_realmid')
  let pathname = KEY_PREFIX + correlationId
  let query = {}
  let authId = objectPath.get(request.headers, 'intuit_userid',  authid)

  if (config.services.cache.ticketless) {
    pathname = TICKETLESS_PATH + pathname
    query.owner = authId
    headers.stripAuthAttribute('intuit_token')
    headers.stripAuthAttribute('intuit_token_type')
    headers.stripAuthAttribute('intuit_userid')
  }

  let path = url.format( {
    protocol: PROTOCAL,
    host: CACHE_ROOT,
    pathname: pathname,
    query: query
  } )

  let options = {
    method: 'GET',
    url: path,
    headers: headers,
    serviceName: SERVICE_NAME,
    reqPath: originalUrl
  }

  return requestPromise( options )
}


exports.addToCache = addToCache
exports.retrieveFromCache = retrieveFromCache
