import url from 'url'
import requestPromise from '../lib/vault-request-promise'
import RequestVariables from '../lib/request-variables'
import config from '../lib/config'

const PROTOCAL = config.services.protocal
const PROVIDERS_ROOT = config.services.suggestions.root
const PROVIDERS_PATH = config.services.suggestions.path.providers

function searchProviderSuggestions(request) {
  let { headers, originalUrl } = new RequestVariables( request )

  let path = url.format( {
    protocol: PROTOCAL,
    host: PROVIDERS_ROOT,
    pathname: PROVIDERS_PATH,
  } )

  let options = {
    method: 'GET',
    url: path,
    headers: headers,
    reqPath: originalUrl
  }

  return requestPromise( options )

}

exports.searchProviderSuggestions = searchProviderSuggestions
