import url from 'url'
import crypto from 'crypto'
import requestPromise from '../lib/vault-request-promise'
import RequestVariables from '../lib/request-variables'
import config from '../lib/config'
import { HttpsAgent } from 'agentkeepalive'

const SERVICE_NAME = 'sts'
const STS_ROOT = config.services.sts.root
const STS_PATH = config.services.sts.path
const STS_AUTH_METHOD = config.services.sts.AuthMethod
const STS_PARTNER_ACCESS_ID = config.services.sts.PartnerAccessId
const STS_SECRET = config.services.sts.Secret
const PROTOCAL = config.services.protocal
const KEEPALIVE_DEFAULTS = config.keepAliveDefaults

let keepaliveAgent = new HttpsAgent(KEEPALIVE_DEFAULTS)

class STSHeaders {
  constructor() {
    const TIMESTAMP = new Date().getTime()
    this['X-SSP-AuthMethod'] = STS_AUTH_METHOD
    this['X-SSP-Timestamp']	= TIMESTAMP
    this['X-SSP-PartnerAccessId']	= STS_PARTNER_ACCESS_ID
    this['X-SSP-Signature'] = crypto.createHmac('sha1', STS_SECRET).update(`${STS_PATH}${TIMESTAMP}${STS_PARTNER_ACCESS_ID}`, 'binary').digest('base64')
    this.sts_tid = this.intuit_tid
    this.Connection = 'Keep-Alive'
  }
}

function searchProviders(req, {
  prefix='',
  zip='',
  rows=0,
  start=0,
  lang='en',
  intent=null,
  template=null,
  country_code=US,
  models=null,
  pretty=true,
  action=null }) {

  let { headers, originalUrl, } = new RequestVariables( req )
  headers.tid = headers.intuit_tid.split('.')[0]

  let path = url.format( {
    protocol: PROTOCAL,
    host: `${STS_ROOT}${STS_PATH}`,
    query: {
      action: action,
      encapjson: true,
      pretty: pretty,
      models: models,
      template: template,
      'context.region.country': country_code,
      intent: intent,
      prefix: prefix,
      zip: zip,
      start: start,
      rows: rows,
      lang: lang
    }
  } )

  let options = {
    method: 'GET',
    url: path,
    headers: Object.assign({}, headers, new STSHeaders()),
    // proxy: config.proxyServer,
    serviceName: SERVICE_NAME,
    reqPath: originalUrl,
    agent: keepaliveAgent
  }

  return requestPromise( options )

}

exports.searchProviders = searchProviders
