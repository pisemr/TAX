import url from 'url'
import config from '../lib/config'
import RequestVariables from '../lib/request-variables'
import requestPromise from '../lib/vault-request-promise'

const SERVICE_NAME = 'crm'
const CRM_ROOT = config.services.crm.root
const PATH_NAME = config.services.crm.path
const PROTOCOL = config.services.protocal


const formatBody = ({
  product,
  firstName,
  lastName,
  email,
  financialInstitutionId,
  financialInstitutionName,
  errorCode,
  timeOfError
}, accountId) => {
  return {
    caseOrigin: 'In-Product',
    subject:'Customer ticket',
    product,
    description: 'Customer Escalation',
    caseOwner: 'IFIG_Customer_Central_Error_Escalation',
    contact: {
      firstName,
      lastName,
      email,
      accountId,
      type : ''
    },
    caseDetail: {
      customerCentralId: '',
      providerId: financialInstitutionId,
      providerName: financialInstitutionName,
      errorCode,
      timeOfError
    }
  }
}

function createCRMCase( request, userData ) {
  const { parentid } = new RequestVariables( request )

  let { headers, originalURL } = new RequestVariables( request )
  let path = url.format( {
    protocol: PROTOCOL, 
    host: CRM_ROOT, 
    pathname: PATH_NAME
  })

  let options = {
    method: 'POST', 
    url: path,
    headers: headers,
    serviceName: SERVICE_NAME,
    body: formatBody(userData, parentid),
    reqPath: originalURL
  }

  return requestPromise( options )
} 

exports.createCRMCase = createCRMCase