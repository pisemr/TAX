import url from 'url'
import config from '../lib/config'
import crypt from '@fdx/common/encryption/crypt'
import { generateUuid } from '../lib/uuid'
import requestPromise from '../lib/vault-request-promise'
import RequestVariables from '../lib/request-variables'

const SERVICE_NAME = 'partnerauth'
const PARTNERAUTH_ROOT = config.services.partnerAuth.root
const PARTNERAUTH_PATH = config.services.partnerAuth.path.initiate
const PARTNERAUTH_TOKEN = config.services.partnerAuth.path.token
const PROTOCAL = config.services.protocal

function getAuthUri( req ) {
  let { headers, originalUrl, ticket, intuit_property, partner_uid, offering_redirect_uri, oauth2_scopes } = new RequestVariables( req )

  headers.addHeader('intuit_ticket', ticket)
  // headers.stripAuthAttribute('intuit_realmid')

  let path = url.format( {
    protocol: PROTOCAL,
    host: PARTNERAUTH_ROOT,
    pathname: PARTNERAUTH_PATH,
    query: {
      intuit_property: intuit_property,
      partner_uid: partner_uid,
      offering_redirect_uri: offering_redirect_uri,
      oauth2_scopes: oauth2_scopes
    }
  } )

  let options = {
    method: 'GET',
    url: path,
    headers: headers,
    serviceName: SERVICE_NAME,
    reqPath: originalUrl
  }

  return requestPromise( options )


  // request( options, ( error, response, body )=> {
  //   callback( error, response, body )
  // } )
}

function getAccessToken( req ) {
  let { headers, originalUrl, ticket } = new RequestVariables( req )

  headers.addHeader('intuit_ticket', ticket)

  let path = url.format({
    protocol: PROTOCAL,
    host: PARTNERAUTH_ROOT,
    pathname: PARTNERAUTH_TOKEN,
    query: {
      response_token: req.body.credentials
    }
  })

  let options = {
    method: 'GET',
    url: path,
    headers: headers,
    serviceName: SERVICE_NAME,
    reqPath: originalUrl
  }

  return requestPromise( options )
}

function getAuthHeaders(req) {
  let { headers, originalUrl, ticket } = new RequestVariables( req )

  headers.addHeader('intuit_ticket', ticket)

  let path = url.format({
    protocol: PROTOCAL,
    host: PARTNERAUTH_ROOT,
    pathname: `/pa_tokens/${req.body.partnerAuthToken}/auth_headers`
  })

  let options = {
    method: 'POST',
    url: path,
    headers: headers,
    serviceName: SERVICE_NAME,
    reqPath: originalUrl
  }

  return requestPromise( options )
}

function buildCredentialArrayFromResponseToken(tokenId) {
  const ENCRYPTION_CERT_VERSION = config.crypto.certVersion
  const ENCRYPTION_KEY = config.crypto.encryptionKey

  return [
    {
      encrypted: true,
      authenticationFieldType: 'OAuthProxyToken',
      id: generateUuid(config.services.partnerAuth.uuidSource),
      value: crypt(tokenId, { key: ENCRYPTION_KEY }),
      type: 'secret',
      certVersion: ENCRYPTION_CERT_VERSION
    }
  ]
}

exports.getAuthUri = getAuthUri
exports.getAccessToken = getAccessToken
exports.getAuthHeaders = getAuthHeaders
exports.buildCredentialArrayFromResponseToken = buildCredentialArrayFromResponseToken
