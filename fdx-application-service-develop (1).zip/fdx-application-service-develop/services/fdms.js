import url from 'url'
import requestPromise from '../lib/vault-request-promise'
import RequestVariables from '../lib/request-variables'
import config from '../lib/config'

const SERVICE_NAME = 'fdms'
const FDMS_ROOT = config.services.fdms.root
const FDMS_MIGRATIONS_PATH = config.services.fdms.path.getMigrations
const FDMS_WAVE_PATH = config.services.fdms.path.getWaveById
const FDMS_PROJECT_PATH = config.services.fdms.path.getProjectById
const FDMS_MIGRATE_PATH = config.services.fdms.path.migrate
const PROTOCAL = config.services.protocal

function getMigrations(req, sourceCredentialSetId, sourceAccountId) {
  let { headers, originalUrl, authid, parentid } = new RequestVariables( req )
  const query = {
    source_credentialset_id: sourceCredentialSetId,
    source_account_id: sourceAccountId
  }
  const isRealmContext = req.query && req.query.isRealmContext === 'true'

  if(isRealmContext) {
    query.realm_id = parentid
  } else {
    query.user_id = authid
  }

  let path = url.format( {
    protocol: PROTOCAL,
    host: FDMS_ROOT,
    pathname: FDMS_MIGRATIONS_PATH,
    query
  } )

  let options = {
    method: 'GET',
    url: path,
    headers: headers,
    serviceName: SERVICE_NAME,
    reqPath: originalUrl
  }

  return requestPromise( options )  
}

function getProjectById(req, projectId) {
  let { headers, originalUrl } = new RequestVariables( req )
  let pathname = FDMS_PROJECT_PATH.replace(/{project_id}/, projectId)


  let path = url.format( {
    protocol: PROTOCAL,
    host: FDMS_ROOT,
    pathname
  } )

  let options = {
    method: 'GET',
    url: path,
    headers: headers,
    serviceName: SERVICE_NAME,
    reqPath: originalUrl
  }

  return requestPromise( options )  
}


function getWaveById(req, waveId) {
  let { headers, originalUrl } = new RequestVariables( req )
  let pathname = FDMS_WAVE_PATH.replace(/{wave_id}/, waveId)


  let path = url.format( {
    protocol: PROTOCAL,
    host: FDMS_ROOT,
    pathname
  } )

  let options = {
    method: 'GET',
    url: path,
    headers: headers,
    serviceName: SERVICE_NAME,
    reqPath: originalUrl
  }

  return requestPromise( options )    
}

function migrate(req, migrationId, model) {
  let { headers, originalUrl } = new RequestVariables( req )
  let pathname = FDMS_MIGRATE_PATH.replace(/{migration_id}/, migrationId)


  let path = url.format( {
    protocol: PROTOCAL,
    host: FDMS_ROOT,
    pathname
  } )

  let options = {
    method: 'POST', 
    url: path,
    headers: headers,
    serviceName: SERVICE_NAME,
    body: model,
    reqPath: originalUrl
  }

  return requestPromise( options )  
}

exports.getMigrations = getMigrations
exports.getWaveById = getWaveById
exports.getProjectById = getProjectById
exports.migrate = migrate