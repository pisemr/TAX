import url from 'url'
import requestPromise from '../lib/vault-request-promise'
import RequestVariables from '../lib/request-variables'
import config from '../lib/config'

const SERVICE_NAME = 'providers'
const PROVIDERS_ROOT = config.services.providers.root
const PROVIDERS_PATH = config.services.providers.path.default
const PROVIDERS_FILTER = config.services.providers.query.allDocTypes
const PROTOCAL = config.services.protocal

function getAllProviders( request ) {
  let { headers, originalUrl, type } = new RequestVariables( request )

  let path = url.format( {
    protocol: PROTOCAL,
    host: PROVIDERS_ROOT,
    pathname: PROVIDERS_PATH,
    search: type ? `service=${type.toUpperCase()}` : PROVIDERS_FILTER
  } )

  let options = {
    method: 'GET',
    url: path,
    headers: headers,
    serviceName: SERVICE_NAME,
    reqPath: originalUrl
  }

  return requestPromise( options )

}
function getAllProviderId( request, providerId ) {
  let { headers, originalUrl } = new RequestVariables( request )

  let path = url.format( {
    protocol: PROTOCAL,
    host: PROVIDERS_ROOT,
    pathname: `${PROVIDERS_PATH}${providerId}`
  } )

  let options = {
    method: 'GET',
    url: path,
    headers: headers,
    serviceName: SERVICE_NAME,
    reqPath: originalUrl
  }

  return requestPromise( options )

}

function getproviderByEIN( request, ein ) {
  let { headers, originalUrl } = new RequestVariables( request )

  let path = url.format( {
    protocol: PROTOCAL,
    host: PROVIDERS_ROOT,
    pathname: PROVIDERS_PATH,
    query: {
      ein: ein
    }
  } )
  let options = {
    method: 'GET',
    url: path,
    headers: headers,
    serviceName: SERVICE_NAME,
    reqPath: originalUrl
  }

  return requestPromise( options )

}

exports.getAllProviders = getAllProviders
exports.getAllProviderId = getAllProviderId
exports.getproviderByEIN = getproviderByEIN
