import url from 'url'
import requestPromise from '../lib/vault-request-promise'
import RequestVariables from '../lib/request-variables'
import config from '../lib/config'

const SERVICE_NAME = 'fpo'
const FPO_ROOT = config.services.fpo.root
const USER_ACQUIRE_PATH = config.services.fpo.path.userAcquire
const USER_REFRESH_PATH = config.services.fpo.path.userRefresh
const EDIT_CREDENTIALS_PATH = config.services.fpo.path.editCredentials
const REALM_ACQUIRE_PATH = config.services.fpo.path.realmAcquire
const REALM_REFRESH_PATH = config.services.fpo.path.realmRefresh
const REALM_EDIT_CREDENTIALS_PATH = config.services.fpo.path.realmEditCredentials
const USER_AVM_GET = config.services.fpo.path.userAvmGet
const REALM_AVM_GET = config.services.fpo.path.realmAvmGet
const ID_DOMAIN = config.services.fpo.iddomain
const FPO_ACQUIRE_MODE = config.services.fpo.fpoAcquireMode
const PROTOCAL = config.services.protocal


function acquire( request, payload ) {
  let { authid, parentid } = new RequestVariables( request )
  let fpoPathName = request.body.isRealmContext ? REALM_ACQUIRE_PATH : USER_ACQUIRE_PATH
  let authType = request.body.isRealmContext ? parentid : authid
  let pathname = fpoPathName.replace(/{authid}/, authType )
  return _makeRequest(request, 'POST', pathname,  payload)
}

function refresh( request, payload ) {
  let { authid, parentid } = new RequestVariables( request )
  let fpoPathName = request.body.isRealmContext ? REALM_REFRESH_PATH : USER_REFRESH_PATH
  let authType = request.body.isRealmContext ? parentid : authid
  let pathname = fpoPathName.replace(/{authid}/, authType )
  return _makeRequest(request, 'POST', pathname,  payload)
}

function editCredentials( request, payload ) {
  let { authid, parentid } = new RequestVariables( request )
  let fpoPathName = request.body.isRealmContext ? REALM_EDIT_CREDENTIALS_PATH : EDIT_CREDENTIALS_PATH
  let authType = request.body.isRealmContext ? parentid : authid
  let pathname = fpoPathName.replace(/{authid}/, authType).replace(/{providerId}/, payload.providers[0].providerId).replace(/{credentialSetId}/, payload.credentialSetId)
  // Payload to FDI does not need credentialSetId
  delete payload.credentialSetId
  return _makeRequest(request, 'PUT', pathname,  payload)
}

function avmGet(request, viewName ) {
  const { authid, parentid } = new RequestVariables( request )
  const fpoPathName = request.body.isRealmContext ? REALM_AVM_GET : USER_AVM_GET
  const authType = request.body.isRealmContext ? parentid : authid
  const avmViewName =  viewName
  const pathname = fpoPathName.replace(/{authid}/, authType).replace(/{viewName}/, avmViewName)

  return _makeRequest(request, 'GET', pathname)
}

function customerAuthorizationForm(request, formData, providerId) {
  let { parentid } = new RequestVariables( request )
  let pathname = `/realms/${parentid }/providers/${providerId}/customerAuthorizationForm`
  return _makeRequest(request, 'POST', pathname,  formData)
}

function _makeRequest( request, method, pathname, payload, PROTOCAL_OVERRIDE ) {
  let { headers, originalUrl } = new RequestVariables( request )

  //Extra header for FPO
  headers.addHeader( 'intuit_iddomain', ID_DOMAIN )
  headers.addHeader( 'fdp_acquire_mode', FPO_ACQUIRE_MODE )
  headers.addHeader( 'fdp_callback_url', `https://${config.hostInternal}/v2/accounts/async` )
  headers.addHeader( 'realtime', true )

  let path = url.format( {
    protocol: PROTOCAL_OVERRIDE ? PROTOCAL_OVERRIDE : PROTOCAL,
    host: FPO_ROOT,
    pathname: pathname
  } )

  let options = {
    method: method,
    proxy: config.proxyServer,
    url: path,
    headers: headers,
    serviceName: SERVICE_NAME,
    reqPath: originalUrl
  }

  if(payload) {
    options.body = payload
  }

  return requestPromise( options )
}


exports.acquire = acquire
exports.refresh = refresh
exports.editCredentials = editCredentials
exports.avmGet = avmGet
exports.customerAuthorizationForm = customerAuthorizationForm
