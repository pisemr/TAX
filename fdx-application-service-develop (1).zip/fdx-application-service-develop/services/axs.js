import url from 'url'
import requestPromise from '../lib/vault-request-promise'
import RequestVariables from '../lib/request-variables'
import config from '../lib/config'

const SERVICE_NAME = 'axs'
const AXS_ROOT = config.services.axs.root
const AXS_PATH = config.services.axs.path
const PROTOCAL = config.services.protocal


function verifyTicket( request ) {
  let { headers, originalUrl, } = new RequestVariables( request )
  // let intuitUserid = request.cookies[ config.ius.authid ] || ''
  // let intuitToken = request.cookies[ config.ius.ticket ] || ''
  // headers.authorization = `Intuit_IAM_Authentication intuit_appid=Intuit.platform.vaultux.vaultapplicationservice, intuit_app_secret=${config.apiGatewayConfig.appSecret}, intuit_token=${intuitToken}, intuit_userid=${intuitUserid}, intuit_token_type=IAM-Ticket`
  headers.stripAuthAttribute('intuit_realmid')
  
  let path = url.format( {
    protocol: PROTOCAL,
    host: AXS_ROOT,
    pathname: AXS_PATH
  } )

  let options = {
    method: 'GET',
    url: path,
    rejectUnauthorized: false,
    headers: headers,
    serviceName: SERVICE_NAME,
    reqPath: originalUrl
  }

  return requestPromise( options )

}

exports.verifyTicket = verifyTicket
