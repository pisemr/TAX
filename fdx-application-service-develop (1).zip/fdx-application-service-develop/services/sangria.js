import url from 'url'
import requestPromise from '../lib/vault-request-promise'
import RequestVariables from '../lib/request-variables'
import config from '../lib/config'

const SERVICE_NAME = 'sangria'
const SANGRIA_ROOT = config.services.sangria.root
const SANGRIA_PATH = config.services.sangria.path.default
const CUSTOMER_KEY = config.services.sangria.oauth.consumerKey
const CUSTOMER_SECRET = config.services.sangria.oauth.consumerSecret
const TOKEN = config.services.sangria.oauth.token
const TOKEN_SECRET = config.services.sangria.oauth.tokenSecret
const PROTOCAL = config.services.protocal


function getEmployerByEIN( request, ein ) {
  let { headers, originalUrl } = new RequestVariables( request )

  let path = url.format( {
    protocol: PROTOCAL,
    host: SANGRIA_ROOT,
    pathname: SANGRIA_PATH,
    query: {
      employerIdNumber: ein
    }
  } )

  let oauth = {
    consumer_key: CUSTOMER_KEY,
    consumer_secret: CUSTOMER_SECRET,
    token: TOKEN,
    token_secret: TOKEN_SECRET
  }

  let options = {
    method: 'GET',
    url: path,
    headers: headers,
    oauth: oauth,
    proxy: config.proxyServer,
    serviceName: SERVICE_NAME,
    reqPath: originalUrl
  }

  return requestPromise( options )

}

exports.getEmployerByEIN = getEmployerByEIN
