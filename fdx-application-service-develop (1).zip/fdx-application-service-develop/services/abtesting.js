import url from 'url'
import requestPromise from '../lib/vault-request-promise'
import RequestVariables from '../lib/request-variables'
import Headers from '../lib/intuit-headers'
import config from '../lib/config'

const SERVICE_NAME = 'abtesting'
const JABBA_ROOT = config.services.ab.root
const JABBA_PATH = 'applications/VAULT/experiments'
const JABBA_APPLICATION_NAME = 'FDX'
const PROTOCAL = config.services.protocal

class JabbaBrowserAuthHeaders extends Headers {
  constructor(request, cookies) {
    super(request)
    this.removeHeader('Authorization')
    this.cookie = cookies
  }
}

function getAllExperiments( request ) {
  let { originalUrl, cookies } = new RequestVariables( request )

  let path = url.format( {
    protocol: PROTOCAL,
    host: JABBA_ROOT,
    pathname: `/applications/${JABBA_APPLICATION_NAME}/experiments`
  } )

  let options = {
    method: 'GET',
    url: path,
    rejectUnauthorized: false,
    headers: new JabbaBrowserAuthHeaders(request, cookies),
    proxy: config.proxyServer,
    serviceName: SERVICE_NAME,
    reqPath: originalUrl
  }
  return requestPromise( options )
}

function getBucketDetail( request, experimentId ) {
  const { originalUrl, cookies, } = new RequestVariables( request )
  const path = url.format( {
    protocol: PROTOCAL,
    host: JABBA_ROOT,
    pathname: `/experiments/${experimentId}/buckets`
  } )

  const options = {
    method: 'GET',
    url: path,
    rejectUnauthorized: false,
    headers: new JabbaBrowserAuthHeaders(request, cookies),
    proxy: config.proxyServer,
    serviceName: SERVICE_NAME,
    reqPath: originalUrl
  }
  return requestPromise( options )
}

function getUserBucketsForExperiment( request, experiment ) {
  let { originalUrl, userAuthId, cookies, } = new RequestVariables( request )

  let path = url.format( {
    protocol: PROTOCAL,
    host: JABBA_ROOT,
    pathname: `/assignments/applications/${JABBA_APPLICATION_NAME}/experiments/${experiment}/users/${userAuthId}`,
    query: {
      createAssignment: true
    }
  } )

  let options = {
    method: 'GET',
    url: path,
    rejectUnauthorized: false,
    headers: new JabbaBrowserAuthHeaders(request, cookies),
    proxy: config.proxyServer,
    serviceName: SERVICE_NAME,
    reqPath: originalUrl
  }
  return requestPromise( options )
}

function assignUserBucket( request, experiment ) {
  let { headers, originalUrl, userAuthId, body } = new RequestVariables( request )

  let path = url.format( {
    protocol: PROTOCAL,
    host: JABBA_ROOT,
    pathname: `/assignments/${JABBA_PATH}/${experiment}/users/${userAuthId}`
  } )

  let options = {
    method: 'PUT',
    url: path,
    rejectUnauthorized: false,
    headers: headers,
    body: { assignment: body.bucket, overwrite: true },
    proxy: config.proxyServer,
    serviceName: SERVICE_NAME,
    reqPath: originalUrl
  }

  return requestPromise( options )
}

function createUserEvent( request ) {
  let { headers, originalUrl , userAuthId, experiment } = new RequestVariables( request )

  let path = url.format( {
    protocol: PROTOCAL,
    host: JABBA_ROOT,
    pathname: `/events/applications/${JABBA_APPLICATION_NAME}/experiments/${experiment}/users/${userAuthId}`
  } )

  let options = {
    method: 'POST',
    url: path,
    rejectUnauthorized: false,
    headers: headers,
    body: request.body,
    proxy: config.proxyServer,
    serviceName: SERVICE_NAME,
    reqPath: originalUrl
  }
  return requestPromise( options )
}

// /v1 Services
function getBucketAssignment( request ) {
  let { headers, originalUrl , userAuthId, experiment } = new RequestVariables( request )

  let path = url.format( {
    protocol: PROTOCAL,
    host: JABBA_ROOT,
    pathname: `/assignments/${JABBA_PATH}/${experiment}/users/${userAuthId}`
  } )

  let options = {
    method: 'GET',
    url: path,
    rejectUnauthorized: false,
    headers: headers,
    proxy: config.proxyServer,
    serviceName: SERVICE_NAME,
    reqPath: originalUrl
  }

  return requestPromise( options )
}

function assignBucket( request ) {
  let { headers, originalUrl , userAuthId, experiment } = new RequestVariables( request )

  let path = url.format( {
    protocol: PROTOCAL,
    host: JABBA_ROOT,
    pathname: `/assignments/${JABBA_PATH}/${experiment}/users/${userAuthId}`
  } )

  let options = {
    method: 'PUT',
    url: path,
    rejectUnauthorized: false,
    headers: headers,
    body: request.body,
    proxy: config.proxyServer,
    serviceName: SERVICE_NAME,
    reqPath: originalUrl
  }

  return requestPromise( options )
}

function createEvent( request ) {
  let { headers, originalUrl , userAuthId, experiment } = new RequestVariables( request )

  let path = url.format( {
    protocol: PROTOCAL,
    host: JABBA_ROOT,
    pathname: `/events/applications/${JABBA_APPLICATION_NAME}/experiments/${experiment}/users/${userAuthId}`
  } )

  let options = {
    method: 'POST',
    url: path,
    rejectUnauthorized: false,
    headers: headers,
    body: request.body,
    proxy: config.proxyServer,
    serviceName: SERVICE_NAME,
    reqPath: originalUrl
  }

  return requestPromise( options )
}

exports.getAllExperiments = getAllExperiments
exports.getBucketDetail = getBucketDetail
exports.getUserBucketsForExperiment = getUserBucketsForExperiment
exports.assignUserBucket = assignUserBucket
exports.createUserEvent = createUserEvent


exports.getBucketAssignment = getBucketAssignment
exports.assignBucket = assignBucket
exports.createEvent = createEvent
