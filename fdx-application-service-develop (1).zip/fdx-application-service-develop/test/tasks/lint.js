var plugins = require( 'gulp-load-plugins' )()
var gulp = require( 'gulp' )

gulp.task( 'lint', function () {
  return gulp.src( [ './lib/**/*.js', './controllers/**/*.js', './models/**/*.js', '!./lib/crypt.js' ] )
    .pipe( plugins.eslint() )
    .pipe( plugins.eslint.format() )
    .pipe( plugins.eslint.failOnError() )
} )
