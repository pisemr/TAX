var gulp = require( 'gulp' ),
  gulpIf = require( 'gulp-if' ),
  argv = require( 'yargs' )
  .option( 'test', {
    // alias: 's',
    describe: 'choose a route name',
    choices: [
      'abtesting',
      'authenticate',
      'connections',
      'credentials',
      'documents',
      'oauth',
      'profile',
      'providers'
    ]
  } )
  .argv,
  mocha = require( 'gulp-mocha' ),
  babel = require( 'babel-core/register' )

var tests = {
  abtesting: './test/functional/abtesting/**/*.spec.js',
  authenticate: './test/functional/authenticate/**/*.spec.js',
  connections: './test/functional/connections/**/*.spec.js',
  credentials: './test/functional/credentials/**/*.spec.js',
  documents: './test/functional/documents/**/*.spec.js',
  oauth: './test/functional/oauth/**/*.spec.js',
  profile: './test/functional/profile/**/*.spec.js',
  providers: './test/functional/providers/**/*.spec.js',
}

var test = tests[ argv.test ]

gulp.task( 'functional', [], function () {
  if ( !argv.test ) {
    console.log( 'please add --test <api route name> when using gulp functional' )
    process.exit( 1 )

  }
  return gulp.src( test, {
      read: false
    } )
    .pipe( mocha( {
      reporter: 'spec',
      timeout: '2543',
      compilers: {
        js: babel
      }
    } ) )
    .once( 'error', function ( err ) {
      console.log( err )
      process.exit( 1 )
    } )
    .once( 'end', function () {
      process.exit()
    } )
} )
