var gulp = require( 'gulp' ),
  gulpIf = require( 'gulp-if' ),
  argv = require( 'yargs' )
  .option( 'test', {
    // alias: 's',
    describe: 'choose a route name',
    choices: [
      'abtesting',
      'accounts',
      'authenticate',
      'connections',
      'credentials',
      'customerAuthorizationForm',
      'documents',
      'oauth',
      'fpo',
      'profile',
      'providers',
      'errorModel',
      'postBodyModel',
      'middleware',
      'modules',
      'typeahead',
      'models',
      'migrations',
      'notifications'
    ]
  } )
  .argv,
  mocha = require( 'gulp-mocha' ),
  babel = require( 'babel-core/register' )

var tests = {
  abtesting: './test/unit/abtesting/**/*.spec.js',
  accounts: './test/unit/accounts/**/*.spec.js',
  fpo: './test/unit/fpo/**/*.spec.js',
  authenticate: './test/unit/authenticate/**/*.spec.js',
  connections: './test/unit/connections/**/*.spec.js',
  credentials: './test/unit/credentials/**/*.spec.js',
  customerAuthorizationForm: './test/unit/customerAuthorizationForm/**/*.spec.js',
  documents: './test/unit/documents/**/*.spec.js',
  oauth: './test/unit/oauth/**/*.spec.js',
  profile: './test/unit/profile/**/*.spec.js',
  providers: './test/unit/providers/**/*.spec.js',
  errorModel: './test/unit/models/error-model.spec.js',
  postBodyModel: './test/unit/models/post-body-model.spec.js',
  middleware: './test/unit/middleware/**/*.spec.js',
  modules: './test/unit/modules/**/*.spec.js',
  typeahead: './test/unit/typeahead/**/*.spec.js',
  models: './test/unit/models/**/*.spec.js',
  notifications: './test/unit/notifications/**/*.spec.js',
  migrations : './test/unit/migrations/**/*.spec.js'
}

var test = tests[ argv.test ]

gulp.task( 'unit', [], function () {
  if ( !argv.test ) {
    console.log( 'please add --test <api route name> when using gulp api' )
    process.exit( 1 )

  }
  return gulp.src( test, {
    read: false
  } )
    .pipe( mocha( {
      reporter: 'spec',
      compilers: {
        js: babel
      }
    } ) )
    .once( 'error', function ( err ) {
      console.log( err )
      process.exit( 1 )
    } )
    .once( 'end', function () {
      process.exit()
    } )
} )
