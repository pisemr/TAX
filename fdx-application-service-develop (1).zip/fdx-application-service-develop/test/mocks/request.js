
export default class Request {
  constructor( options ) {
    options = options || {}
    this.baseUrl = options.baseUrl || '/'
    this.method = options.method || 'GET'
    this.params = options.params || {}
    this.query = options.query || {}
    this.headers = options.headers || {
      'x-forwarded-for': '199.16.140.24, 10.160.64.5, 10.160.66.199',
      'intuit_originalurl': 'https://vault-e2e.api.intuit.com/v1/headers',
      'intuit_tid': 'TEST-SERVICE-REQUEST',
      'intuit_assetalias': 'Intuit.tax.browserwidgets.browserwidgets',
      'content-type': 'application/json',
      'intuit_app_name': 'Intuit.tax.browserwidgets.browserwidgets',
      'intuit_apikey': "'Intuit_APIKey intuit_token_type=\'IAM-Ticket\',intuit_realmid=\'50000003\',intuit_token=\'V1-188-L3vfjtfxfpx0rlp6mlwhb6\',intuit_apikey=\'preprdakyresj2seWxR9pqWKZIAx7AaW5x2Mkpbu\',intuit_userid=\'193514366910437\'",
      'intuit_originating_assetid': '12345678900987654321',
      'intuit_offeringid': 'Fake.Intuit.OfferingID'
    }
    this.cookies = options.cookies || {
      'qbn.dtc.ticket': options.ticket || 'V1-196-Q008d9ksnw0ez7vxo273qj',
      'qbn.dtc.tkt': options.ticket ||'V1-196-Q008d9ksnw0ez7vxo273qj',
      'qbn.dtc.authid': options.authId || '2265507445',
      'qbn.dtc.gauthid': options.authId || '2265507445',
      'qbn.dtc.agentid': options.authId || '2265507445',
      'qbn.dtc.parentid': options.parentid || '50000003',
      'qbn.ticket': options.ticket ||'V1-196-Q008d9ksnw0ez7vxo273qj',
      'qbn.tkt': options.ticket ||'V1-196-Q008d9ksnw0ez7vxo273qj',
      'qbn.authid': options.authId || '2265507445',
      'qbn.gauthid': options.authId || '2265507445',
      'qbn.agentid': options.authId || '2265507445',
      'qbn.parentid': '50000003',
      'qbn.ptc.ticket': options.ticket ||'V1-196-Q008d9ksnw0ez7vxo273qj',
      'qbn.ptc.tkt': options.ticket ||'V1-196-Q008d9ksnw0ez7vxo273qj',
      'qbn.ptc.authid': options.authId || '2265507445',
      'qbn.ptc.gauthid': options.authId || '2265507445',
      'qbn.ptc.agentid': options.authId || '2265507445',
      'qbn.ptc.parentid': options.parentid || '50000003'
    }
    this.body = options.body || {}
    return this
  }
}
