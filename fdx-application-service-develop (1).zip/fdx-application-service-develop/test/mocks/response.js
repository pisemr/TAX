
export default class Response {
  constructor() {
    this.statusCode
    this.response
    this.headers = {}
  }
  status( code ) {
    this.statusCode = code
    return this
  }
  send( response ) {
    this.response = response
  }
  sendStatus( code ) {
    this.statusCode = code
  }
  header( name, value ) {
    this.headers[ name ] = value
    return this
  }

}
