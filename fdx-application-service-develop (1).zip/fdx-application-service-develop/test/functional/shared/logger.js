'use strict'

var logger = require( 'loglevel' );

// to turn off logging set env variable LOG_LEVEL=silent
var getLogger = function() {
  logger.setLevel( process.env.LOG_LEVEL || 'debug' );
  return logger;
};

module.exports = getLogger();
