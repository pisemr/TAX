// this is an experimental file used to work around the fact that in oder for istanbul
// to report coverage on server side code, it must be require-d in. This code grabs
// code we want coverage for and explicitly requires them.
var glob = require("multi-glob").glob;

// include for latest features
// require("babel-core/register");

// istanbul uses module loader hooks to instrument code on the fly. Even if a glob (source file) is passed to gulp and piped
// to istanbul, it will not show up in the reports unless it is actually required through the module loader hooks.
// multi-glob allows us to grab the sources we want coverage for and require them explicitly to force istanbul to instrument them.
glob(['../../../middleware/**/*.js', '../../../services/**/*.js', '../../../controllers/**/*.js'],
  {'ignore': ['./*.js']}, function (er, files) {
  // files is an array of filenames.
  // If the `nonull` option is set, and nothing
  // was found, then files is ["**/*.js"]
  // er is an error object or null.
  for (var i = 0; i < files.length; i++) {
    require(files[i]);
    console.log('require(' + files[i] + ')');
  }
  console.log(__dirname);
})
