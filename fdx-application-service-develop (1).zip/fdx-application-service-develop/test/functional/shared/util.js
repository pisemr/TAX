'use strict';

var supertest = require( 'supertest-as-promised' );
var config    = require( '../config/config' );
var os        = require( 'os' );

module.exports = {

  getTicket: function( username, password ) {
    var request = supertest( config.iusUrl );

    return request.post( '/v1/iamtickets/' )
      .set( 'Authorization', config.iusAuthHeader )
      .set( 'intuit_originatingip', '172.29.33.63' )
      .set( 'Accept', 'application/json' )
      .set( 'Content-Type', 'application/json' )
      .send( { 'username': config.iusUser,'password': config.iusPassword } )
      .expect( 200 )
      .then( function( res ) {
        return res.text;
      } );
  },

  // TODO: qbn.ptc.* for E2E, qbn.dtc.* for PRF and qbn.* for PRD
  getCookie: function( username, password ) {
    return this.getTicket( username, password )
      .then( function( cookie ) {
        var cookieObj = JSON.parse( cookie );
        return 'qbn.ptc.ticket=' + cookieObj.ticket + '; qbn.ptc.authid=' + cookieObj.userId + '; qbn.ptc.parentid=' + cookieObj.realmId;
    } );
  },

  // TODO: remove this code may not be needed
  getIpAddress: function() {
    var ip;
    var networkInterfaces = os.networkInterfaces();
    Object.keys(networkInterfaces).forEach(function (networkInterface) {
      // CAUTION: only tested on my local MAC_OSX machine and only for IPv4
      if(networkInterface == 'en0')
        networkInterfaces[networkInterface].forEach(function (iface) {
          if ('IPv4' == iface.family )
            ip = iface.address;
        });
    });
    return ip;
  },

  generateTID: function generateTID () {
    /* jshint ignore:start */
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
      var r = Math.random() * 16 | 0,
          v = c == 'x' ? r : (r & 0x3 | 0x8);
      return v.toString(16);
    });
    /* jshint ignore:end */
  }

};
