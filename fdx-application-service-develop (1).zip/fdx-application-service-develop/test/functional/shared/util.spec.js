var expect    = require( 'chai' ).expect
var util      = require( '../shared/util' )
var log       = require( '../shared/logger' )
var config    = require( '../config/config' )

describe( 'Util Methods', function() {
  it( 'should get cookie from iamtickets', function( done ) {
    util.getCookie()
    .then( function( auth ) {
      log.info( auth )
      expect( auth ).to.contain( 'qbn.ptc.ticket=' )
      expect( auth ).to.contain( 'qbn.ptc.authid=' )
      expect( auth ).to.contain( 'qbn.ptc.parentid=' )
      expect( auth ).to.have.length.above( 85 )
      done()
    } )
  } )

  it( 'should get env specific configuration', function( done ) {
    log.info( config.vaultUrl )
    expect( config.vaultUrl ).to.contain( 'http' )
    done()
  } )

  it( 'should get the local IP address', function( done ) {
    var net = require('net')
    var ip = util.getIpAddress()
    log.info( ip )
    expect( net.isIP( ip ) != 0 ).to.be.true
    done()
  } )

  it( 'should generate a TID', function( done ) {
    var tid = util.generateTID()
    log.info( tid )
    expect( tid ).not.to.be.null
    expect( tid ).to.have.length( 36 )
    done()
  } )
} )
