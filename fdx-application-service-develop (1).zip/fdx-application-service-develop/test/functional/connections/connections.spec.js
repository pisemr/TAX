'use strict';

var expect    = require( 'chai' ).expect;
var util      = require( '../shared/util' );
var log       = require( '../shared/logger' );
var config    = require( '../config/config' );
var supertest = require( 'supertest-as-promised' );
var request   = supertest( config.vaultUrl );

describe( 'Connections Route', function() {
  var cookie;
  before(function () {
    return util.getCookie().then( function( result ) {
      cookie = result;
    });
  });

  it( 'should return 200', function() {
    // return request.get( '/v1/oauth?partner_connection_id=VAULT&auth_id=1234567890&offering_redirect_uri=http://www.google.com&oauth2scopes=none' )
    // .set( 'Authorization', config.vaultAuthHeader )
    // .set( 'Cookie', cookie )
    // .expect( 200 )
    // .then( function( res ) {
    //   expect( res.text ).to.contain( 'assignment' );
    // } );
  } );

} );
