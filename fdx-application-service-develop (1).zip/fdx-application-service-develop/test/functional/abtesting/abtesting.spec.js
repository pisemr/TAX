'use strict';

var expect    = require( 'chai' ).expect;
var util      = require( '../shared/util' );
var log       = require( '../shared/logger' );
var config    = require( '../config/config' );
var supertest = require( 'supertest-as-promised' );
var request   = supertest( config.vaultUrl );

describe( 'AB Testing Route', function() {
  var cookie;
  before(function () {
    return util.getCookie().then( function( result ) {
      cookie = result;
    });
  });

  it( 'should return 200', function() {
    return request.get( '/v1/abtesting' )
    .set( 'Authorization', config.vaultAuthHeader )
    .set( 'Cookie', cookie )
    .expect( 200 )
    .then( function( res ) {
      log.info( res.text );
      expect( res.text ).to.contain( 'assignment' );
      expect( res.text ).to.contain( 'cache' );
      expect( res.text ).to.contain( 'status' );
      expect( res.text ).to.contain( 'context' );
      expect( res.text ).to.contain( 'payload' );
    } );
  } );

} );
