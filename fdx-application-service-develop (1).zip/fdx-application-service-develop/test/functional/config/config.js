'use strict';

var nconf = require( 'nconf' );
var path  = require( 'path' );

var getConfig = function() {

  var env = process.env.TEST_ENV || 'e2e';

  nconf.env()    // read from environment variables
       .argv();  // read from command line args

  // read from env specific config file if not found it will be empty
  nconf.file( 'environment', path.join( __dirname, env + '.json' ) );

  // read from the default config if not found in env specific it will default
  nconf.file( 'default', path.join( __dirname, 'default.json' ) );

  // return the consolidated config object
  return nconf.get();
};

module.exports = getConfig();
