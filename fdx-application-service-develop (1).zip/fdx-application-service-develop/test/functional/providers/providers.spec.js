'use strict';

var expect    = require( 'chai' ).expect;
var util      = require( '../shared/util' );
var log       = require( '../shared/logger' );
var config    = require( '../config/config' );
var supertest = require( 'supertest-as-promised' );
var request   = supertest( config.vaultUrl );

describe( 'Providers Route', function() {
  it( 'should return 200', function( done ) {
    request.get( '/v1/providers/' )
    .set( 'Authorization', config.vaultAuthHeader )
    .set( 'Cookie', 'qbn.ptc.ticket=does; qbn.ptc.authid=not; qbn.ptc.parentid=matter' )
    .expect( 200)
    .end( function( err, res ) {
      if( err )
        return done( err );
      done();
    } );
  } );

  it( 'should return 200', function( done ) {
    request.get( '/v1/providers/?ein=362712285' )
    .set( 'Authorization', config.vaultAuthHeader )
    .set( 'Cookie', 'qbn.ptc.ticket=only; qbn.ptc.authid=validates; qbn.ptc.parentid=presence' )
    .expect( 200 )
    .end( function( err, res ) {
      if( err )
        return done( err );
      done();
    } );
  } );

} );
