'use strict';

var expect    = require( 'chai' ).expect;
var util      = require( '../shared/util' );
var log       = require( '../shared/logger' );
var config    = require( '../config/config' );
var supertest = require( 'supertest-as-promised' );
var request   = supertest( config.vaultUrl );

describe( 'Documents Route', function() {
  var cookie;
  before(function () {
    return util.getCookie().then( function( result ) {
      cookie = result;
    });
  });

  it( 'should return 200', function() {
    return request.get( '/v1/documents/health/full' )
    .set( 'Authorization', config.vaultAuthHeader )
    .set( 'Cookie', cookie )
    .expect( 200 )
    .then( function( res ) {
      expect( res.text ).to.contain( 'Health Check Ok' );
    } );
  } );

} );
