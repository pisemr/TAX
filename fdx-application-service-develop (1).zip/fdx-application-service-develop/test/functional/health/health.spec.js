'use strict';

var expect    = require( 'chai' ).expect;
var util      = require( '../shared/util' );
var log       = require( '../shared/logger' );
var config    = require( '../config/config' );
var supertest = require( 'supertest-as-promised' );
var request   = supertest( config.vaultUrl );

describe( 'Health Route', function() {
  it( 'should return 200', function() {
    return request.get( '/health/full' )
    .expect( 200 )
    .then( function( res ) {
      expect( res.text ).to.contain( 'Health Check Ok' );
    } );
  } );

} );
