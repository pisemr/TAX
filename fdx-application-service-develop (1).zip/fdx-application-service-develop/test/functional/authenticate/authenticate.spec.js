'use strict';

var expect    = require( 'chai' ).expect;
var util      = require( '../shared/util' );
var log       = require( '../shared/logger' );
var config    = require( '../config/config' );
var supertest = require( 'supertest-as-promised' );
var request   = supertest( config.vaultUrl );

describe( 'Authenticate Route', function() {
  it( 'should return 500 with an invalid body', function( done ) {
    request.post( '/v1/authenticate/' )
    .set( 'Authorization', config.vaultAuthHeader )
    .set( 'Cookie', 'qbn.ptc.ticket=invalid; qbn.ptc.authid=on; qbn.ptc.parentid=purpose' )
    .send( { 'missing': 'authType, providerId, certVersion and credentials'} )
    .expect( 500 )
    .end( function( err, res ) {
      expect( res.text ).to.contain( 'authType is a required parameter' );
      expect( res.text ).to.contain( 'providerId is a required parameter' );
      expect( res.text ).to.contain( 'certVersion is a required parameter' );
      expect( res.text ).to.contain( 'credentials is a required parameter' );
      if( err )
        return done( err );
      done();
    } );
  } );

  it( 'should return 500 with an invalid ticket', function( done ) {
    request.post( '/v1/authenticate/' )
    .set( 'Authorization', config.vaultAuthHeader )
    .set( 'Cookie', 'qbn.ptc.ticket=invalid; qbn.ptc.authid=on; qbn.ptc.parentid=purpose' )
    .send( {"authType":"1099-INT","taxYear":2015,"is7216":true,"providerId":"4f5035d9-c31f-41da-b5bc-6da281b446ca","persistenceParams":{"folderId":"55ac07d8-e0c7-46f4-a1dc-d644d1f782a4","persistAsync":false,"persist":false},"offeringAttributes":[],"credentials":{"authFields":[{"type":"nonSecret","id":"USERID","value":"1099Variousv2"},{"type":"secret","id":"PASSWORD","value":"8fc52e57d71739e26dc4064a8227386116fa4ffd4af69c0cf1e0068464888a334bb7a69304978db52a6028abdb6b463724593f88768b75a0ef8e74e9ed68521653f92abb786816a93a8d15d0fe3eb897367d26a9d897731f7aec218d9f1bff75b65961ecc8b115a1e8e9b9c5df0130b54c35eb9c1f932eced4a36db84445a1de4eeea54d3ee3e74c0b971d1fb5b326fb5f95685a54cae9af522795dba043b1967efd63b533cd4166807a48e0e28a6796169f5d749a79706501481cac64173e81da81e8c33daa1ac18d0a2498375d92d3e44cc1107540d025654760c002857c6aeb028eab4db79eb3dea691a43731a36d536e4399e4a66a7136083d40bf63dd1d"}]},"certVersion":"v01_credential_service_cryption_nonprod_key.corp.intuit.net","entityTypes":["1099-B","1099-DIV","1099-INT","1099-MISC","1099-OID","1099-R"]} )
    .expect( 500 )
    .end( function( err, res ) {
      expect( res.text ).to.contain( 'Invalid IAM Ticket' );
      if( err )
        return done( err );
      done();
    } );
  } );


  it( 'should return 401 unauthorized', function( done ) {
    request.post( '/v1/authenticate/' )
    .set( 'Authorization', config.vaultAuthHeader )
    .set( 'Cookie', 'no.ticket=invalid; no.authid=on; no.parentid=purpose' )
    .send( {"authType":"1099-INT","taxYear":2015,"is7216":true,"providerId":"4f5035d9-c31f-41da-b5bc-6da281b446ca","persistenceParams":{"folderId":"55ac07d8-e0c7-46f4-a1dc-d644d1f782a4","persistAsync":false,"persist":false},"offeringAttributes":[],"credentials":{"authFields":[{"type":"nonSecret","id":"USERID","value":"1099Variousv2"},{"type":"secret","id":"PASSWORD","value":"8fc52e57d71739e26dc4064a8227386116fa4ffd4af69c0cf1e0068464888a334bb7a69304978db52a6028abdb6b463724593f88768b75a0ef8e74e9ed68521653f92abb786816a93a8d15d0fe3eb897367d26a9d897731f7aec218d9f1bff75b65961ecc8b115a1e8e9b9c5df0130b54c35eb9c1f932eced4a36db84445a1de4eeea54d3ee3e74c0b971d1fb5b326fb5f95685a54cae9af522795dba043b1967efd63b533cd4166807a48e0e28a6796169f5d749a79706501481cac64173e81da81e8c33daa1ac18d0a2498375d92d3e44cc1107540d025654760c002857c6aeb028eab4db79eb3dea691a43731a36d536e4399e4a66a7136083d40bf63dd1d"}]},"certVersion":"v01_credential_service_cryption_nonprod_key.corp.intuit.net","entityTypes":["1099-B","1099-DIV","1099-INT","1099-MISC","1099-OID","1099-R"]} )
    .expect( 401 )
    .end( function( err, res ) {
      expect( res.text ).to.contain( 'IUS qbn.ptc.authid and qbn.ptc.ticket must be present in request' );
      if( err )
        return done( err );
      done();
    } );
  } );

  // // need to get pre-req/set-up call(s) from justin (create user to get valid ticket?)
  // it( 'get should return 200', function( done ) {
  //   request.post( '/v1/authenticate/' )
  //   .set( 'Authorization', config.vaultAuthHeader )
  //   .set( 'Cookie', util.getCookie )
  //   .send( {"authType":"1099-INT","taxYear":2015,"is7216":true,"providerId":"4f5035d9-c31f-41da-b5bc-6da281b446ca",
  //           "persistenceParams":{
  //             "folderId":"55ac07d8-e0c7-46f4-a1dc-d644d1f782a4","persistAsync":false,"persist":false
  //           },
  //           "offeringAttributes":[],
  //           "credentials":{
  //             "authFields":[
  //               {"type":"nonSecret","id":"USERID","value":"1099Variousv2"},
  //               {"type":"secret","id":"PASSWORD","value":"8fc52e57d71739e26dc4064a8227386116fa4ffd4af69c0cf1e0068464888a334bb7a69304978db52a6028abdb6b463724593f88768b75a0ef8e74e9ed68521653f92abb786816a93a8d15d0fe3eb897367d26a9d897731f7aec218d9f1bff75b65961ecc8b115a1e8e9b9c5df0130b54c35eb9c1f932eced4a36db84445a1de4eeea54d3ee3e74c0b971d1fb5b326fb5f95685a54cae9af522795dba043b1967efd63b533cd4166807a48e0e28a6796169f5d749a79706501481cac64173e81da81e8c33daa1ac18d0a2498375d92d3e44cc1107540d025654760c002857c6aeb028eab4db79eb3dea691a43731a36d536e4399e4a66a7136083d40bf63dd1d"}
  //             ]},
  //          "certVersion":"v01_credential_service_cryption_nonprod_key.corp.intuit.net",
  //          "entityTypes":[
  //            "1099-B","1099-DIV","1099-INT","1099-MISC","1099-OID","1099-R"
  //          ]} )
  //   .expect( 200 )
  //   .end( function( err, res ) {
  //     if( err )
  //       return done( err );
  //     done();
  //   } );
  // } );
} );
