import { expect } from 'chai'
import nock from 'nock'
import convertQueryToHeader from '../../../middleware/convertQueryToHeader'
import { gateway, gatewayNoCookies, missingIntuitOfferingId } from './mocks/gateway-requests'
import Request from '../../mocks/request'
import Response from '../../mocks/response'
import config from '../../../lib/config'


describe( 'convertQueryToHeader Middleware', function () {


  describe( 'Conversion one', function () {
    let options = {
      query: {
        locale: 'en_fr',
        country_code: 'US', 
        intuit_tid: '123-123-123-123',
        flowId: '321-321-321-321'
      }
    }

    let req = new Request( options )
    let res = new Response()
    let middleware = convertQueryToHeader()
    let callNext
    middleware( req, res, function () {
      callNext = true
    } )
    it( 'should call next', function ( done ) {
      expect( callNext ).to.equal( true )
      done()
    } )
    it( 'should convert query string params to headers', function ( done ) {
      expect( req.headers.intuit_locale ).to.equal( options.query.locale )
      expect( req.headers.intuit_country ).to.equal( options.query.country_code )
      expect( req.headers.intuit_tid).to.equal( options.query.intuit_tid )
      expect( req.headers.intuit_flowid ).to.equal( options.query.flowId )
      done()
    } )
  } )

  describe( 'Conversion two', function () {
    let options = {
      query: {
        intuit_locale: 'en_fr',
        intuit_country: 'US', 
        intuit_tid: '123-123-123-123',
        intuit_flowid: '321-321-321-321'
      }
    }

    let req = new Request( options )
    let res = new Response()
    let middleware = convertQueryToHeader()
    let callNext
    middleware( req, res, function () {
      callNext = true
    } )
    it( 'should call next', function ( done ) {
      expect( callNext ).to.equal( true )
      done()
    } )
    it( 'should convert query string params to headers', function ( done ) {
      expect( req.headers.intuit_locale ).to.equal( options.query.intuit_locale )
      expect( req.headers.intuit_country ).to.equal( options.query.intuit_country )
      expect( req.headers.intuit_tid).to.equal( options.query.intuit_tid )
      expect( req.headers.intuit_flowid ).to.equal( options.query.intuit_flowid )
      done()
    } )
  } )
} )
