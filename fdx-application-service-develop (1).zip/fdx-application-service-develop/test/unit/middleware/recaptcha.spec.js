import { expect } from 'chai'
import nock from 'nock'
import recaptcha from '../../../middleware/validateReCaptcha'
import { gateway, gatewayNoCookies } from './mocks/gateway-requests'
import Request from '../../mocks/request'
import Response from '../../mocks/response'
import config from '../../../lib/config'

//https://github.intuit.com/CTO-Dev-FDS-FDX/fdx-application-service/wiki/ReCAPTCHA


const createGoogleSuccessMock = () => {
  nock( 'https://' + config.services.google.root )
    .get( `${config.services.google.path.siteverify}?secret=6LfesQ8UAAAAAMwet06vbsFTTImGNzQiItYD_wBo&response=success`)
    .reply( 200, {
      "success": true,
      "challenge_ts": "2017-01-19T17:48:42Z",
      "hostname": "pictureframe-local.intuit.com"
    } )
}

const createGoogleErrorMock = () => {
  nock( 'https://' + config.services.google.root )
    .get( `${config.services.google.path.siteverify}?secret=6LfesQ8UAAAAAMwet06vbsFTTImGNzQiItYD_wBo&response=success`)
    .reply( 200, {
      "success": false,
      "error-codes": [ "invalid-input-response" ]
    } )
}

const createGoogleAPIDown = () => {
  nock( 'https://' + config.services.google.root )
    .get( `${config.services.google.path.siteverify}?secret=6LfesQ8UAAAAAMwet06vbsFTTImGNzQiItYD_wBo&response=success`)
    .reply( 500, 'ERROR' )
}

const createRSSSuccessMock = () => {
  nock( 'https://' + config.services.rss.root)
    .post( config.services.rss.path.assertion)
    .reply( 200, {
      "timeStamp": new Date(),
      "description": "success",
      "elapsedTime": 0
    })
}

const createRSSErrorMock = () => {
  nock( 'https://' + config.services.rss.root)
    .post( config.services.rss.path.assertion)
    .reply( 422, {
      "requestId": "55265723-cd26-46c2-ad05-e4f37168c808",
      "description": "Namespace cannot be null and must contain a valid value.",
      "elapsedTime": 0
    })
}

describe( 'ReCaptcha Middleware', function () {

  describe( 'Query string validaton', function () {

    createGoogleSuccessMock()
    createRSSSuccessMock()

    let options = {
      headers: gateway.headers,
      query: {
        recaptcha: 'success'
      }
    }

    let req = new Request( options )
    let res = new Response()
    let nextCalled
    let userData
    let middleware = recaptcha()
    middleware( req, res, function () {
      userData = req.userData
      nextCalled = true
    } )

    it( 'should call next()', function ( done ) {
      expect( nextCalled ).to.equal( true )
      done()
    } )

    it( 'should add reCaptchaStatus to the userData object', function ( done ) {
      expect( userData.reCaptchaStatus ).to.equal( 'pass' )
      done()
    } )

  } )


  describe( 'Validaton fails', function () {

    createGoogleErrorMock()
    createRSSSuccessMock()


    let options = {
      headers: gateway.headers,
      method: 'POST',
      body: {
        recaptcha: 'success', 
        providerId: 'finn'
      }
    }

    let req = new Request( options )
    let res = new Response()
    let nextCalled
    let userData
    let body
    let middleware = recaptcha()

    middleware( req, res, function () {
      nextCalled = true
    } )

    it( 'should not call next()', function ( done ) {
      expect( nextCalled ).to.be.undefined
      done()
    } )

    it( 'should return a 400 with proper error', function ( done ) {
      expect( res.statusCode ).to.equal( 400 )
      expect( res.response.code ).to.equal( 'FDX-1001' )
      expect( res.response.message ).to.contain( 'google' )
      expect( res.response.detail.success ).to.equal( false )
      done()
    } )

  } )

  describe( 'Google API Down', function () {

    createGoogleAPIDown()
    createRSSSuccessMock()

    let options = {
      headers: gateway.headers,
      method: 'POST',
      body: {
        recaptcha: 'success', 
        providerId: 'finn'
      }
    }

    let req = new Request( options )
    let res = new Response()
    let nextCalled
    let body
    let userData
    let middleware = recaptcha()

    middleware( req, res, function () {
      userData = req.userData
      nextCalled = true
      body = req.body
    } )

    it( 'should call next()', function ( done ) {
      expect( nextCalled ).to.equal( true )
      done()
    } )

    it( 'should add not reCaptchaStatus to the userData object', function ( done ) {
      expect( userData ).to.be.undefined
      done()
    } )

    it( 'should add not reCaptchaStatus to the userData object', function ( done ) {
      expect( body.recaptcha ).to.be.undefined
      expect( body.providerId ).to.equal( options.body.providerId )
      done()
    } )

  } )
} )