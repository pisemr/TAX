import { expect } from 'chai'
import nock from 'nock'
import auth from '../../../middleware/validateRequestHeaders'
import { gateway, gatewayNoCookies, missingIntuitOfferingId } from './mocks/gateway-requests'
import Request from '../../mocks/request'
import Response from '../../mocks/response'
import config from '../../../lib/config'


describe( 'Auth Middleware', function () {


  describe( 'Error intuit_offeringid not set', function () {
    let options = {
      headers: missingIntuitOfferingId.headers
    }

    let req = new Request( options )
    let res = new Response()
    let middleware = auth()
    middleware( req, res, function () {} )
    it( 'should respond with error message asking for intuit_offeringid', function ( done ) {
      expect( res.response.message ).to.equal( 'intuit_offeringid, intuit_assetalias must be present in request header' )
      done()
    } )
    it( 'should include the intuit_tid in the response', function ( done ) {
      expect( res.response.intuit_tid ).to.equal( '83015--xx--xx--creds-err' )
      done()
    } )
  } )

  describe( 'Error oAuth request invalid ticket', function () {

    let options = {
      headers: missingIntuitOfferingId.headers,
      baseUrl: '/v1/oauth',
      query : {
        intuit_property: 'intuit',
        partner_uid: 'demo',
        offering_redirect_uri: decodeURIComponent( 'https%3A%2F%2Fvault-qal.api.intuit.com%2Fv1%2Foauth%2Fredirect%3Fredirect_url%3Dhttps%3A%2F%2Ffds-local.intuit.com%3A44300%2Ftarget%2Fdebug%2FpartnerAuthRedirectTarget.html%26txnId%3D84029e46-16f6-4a77-983a-e6b765e07079%26intuit_apikey%3Dpreprdakyresj2seWxR9pqWKZIAx7AaW5x2Mkpbu%26token_query%3D' ),
        oauth2_scopes: 'getAccounts'
      }
    }

    let req = new Request( options )
    let res = new Response()
    let middleware = auth()
    middleware( req, res, function () {} )
    it( 'should respond with statusCode 302', function ( done ) {
      expect( res.statusCode ).to.equal( 302 )
      done()
    } )
    it( 'should respond with header location error', function ( done ) {
      expect( res.headers.Location ).to.contain( 'errorCode=FDPAUTH-48' )
      expect( res.headers.Location ).to.contain( 'errorMessage=intuit_offeringid, intuit_assetalias must be present in request header' )
      done()
    } )
  } )
} )
