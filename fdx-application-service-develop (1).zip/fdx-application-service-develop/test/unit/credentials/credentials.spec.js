import {
  expect
} from 'chai'
import nock from 'nock'
import config from '../../../lib/config'
import Request from '../../mocks/request'
import Response from '../../mocks/response'
import {
  getCredentialsCtrl,
  addCrededentialsCtrl,
  updateCredentialsCtrl,
  deleteProviderCredentialsCtrl,
  deleteCredentialSetCtrl, 
  getPrivateKeyCtrl
} from '../../../controllers/credentials/credentials'

describe( 'Credentials Route', function () {

  describe( 'Getting all credentials for a user', function () {

    nock( 'https://' + config.services.credentials.root )
      .get( '/providers' )
      .reply( 200, {
        'userId': '193514366910437',
        'providers': [ {
          'providerId': '4f5035d9-c31f-41da-b5bc-6da281b446ca',
          'credentialSets': [ {
            'credentialSetId': '3373e103-9851-4c52-9cdb-d126d4d47853'
          } ]
        }, {
          'providerId': 'a00074d7-df15-49e1-8ade-f32a6ddfc8aa',
          'credentialSets': []
        }, {
          'providerId': '702b1ee5-caec-4ffa-ada5-1ad2ca006766',
          'credentialSets': [ {
            'credentialSetId': '7ebf1b36-ef15-4635-9c58-4cd566f32081'
          } ]
        }, {
          'providerId': 'afe0b32e-94e1-4176-8c09-66188a932e99',
          'credentialSets': [ {
            'credentialSetId': '515b833c-dea1-40f0-a9f9-0d204283218f'
          } ]
        } ]
      } )

    let mockResponse = new Response()
    let mockRequest = new Request()

    getCredentialsCtrl( mockRequest, mockResponse )
    it( 'should respond with 200', function ( done ) {
      expect( mockResponse.statusCode ).to.equal( 200 )
      done()
    } )

    it( 'should respond with a list of 4', function ( done ) {
      expect( mockResponse.response ).to.be.defined
      expect( mockResponse.response.providers ).to.have.length( 4 )
      done()
    } )

  } )

  describe( 'Getting credential set details', function () {

    let mockData = {
      'authId': '193514366910437',
      'providerId': '4f5035d9-c31f-41da-b5bc-6da281b446ca',
      'credentialSetId': '3373e103-9851-4c52-9cdb-d126d4d47853',
      // 'status': 'verified',
      'statusDetail': {
        'code': '0',
        'message': 'User is authenticated.',
        'providerMessage': ''
      },
      'credentials': [ {
        'type': 'nonSecret',
        'certVersion': 'v01_credential_service_cryption_nonprod_key.corp.intuit.net',
        'authenticationFieldId': 'ebd94c8e-7ae4-4573-9e79-cf0e48aba7c0',
        'authenticationFieldValue': '1099Variousv2',
        'mappingSourceText': 'USERID',
        'mappingSourceValue': '1099Variousv2',
        'masked': '*************'
      }, {
        'type': 'secret',
        'certVersion': 'v01_credential_service_cryption_nonprod_key.corp.intuit.net',
        'authenticationFieldId': '58e357ef-0bd9-4136-81d4-e2884ea9e093',
        'authenticationFieldValue': '*************',
        'mappingSourceText': 'PASSWORD',
        'mappingSourceValue': '*************',
        'masked': '*************'
      } ]
    }

    nock( 'https://' + config.services.credentials.root )
      .get( '/credentials/3373e103-9851-4c52-9cdb-d126d4d47853' )
      .reply( 200, mockData )

    let options = {
      params: {
        id: '3373e103-9851-4c52-9cdb-d126d4d47853'
      }
    }
    let mockResponse = new Response()
    let mockRequest = new Request( options )

    getCredentialsCtrl( mockRequest, mockResponse )
    it( 'should respond with 200', function ( done ) {
      expect( mockResponse.statusCode ).to.equal( 200 )
      done()
    } )

    it( 'should respond with a list credentials', function ( done ) {
      expect( mockResponse.response ).to.be.defined
      expect( mockResponse.response.credentials ).to.have.length( 2 )
      done()
    } )

    it( 'should set status to "verified" if statusDetail.code === 0 ', function ( done ) {
      expect( mockResponse.response ).to.be.defined
      expect( mockResponse.response.status ).to.equal( 'verified' )
      done()
    } )

  } )

  describe( 'When getting all credentials for a user fails', function () {

    nock( 'https://' + config.services.credentials.root )
      .get( '/providers' )
      .reply( 404, {
        'errors': {
          'error': [ {
            'code': 'not.found',
            'type': 'CLIENT',
            'message': 'The requested resource could not be found.',
            'detail': 'exceptionMessage="Unable to get Entity, Key:80b2513c-1619-419b-b1e1-c110e2fe9ff_masked DAP Error:NOT_FOUND Details:Caused by Not Found ", code="DAP-1006", type="SYSTEM", message="NOT_FOUND", detail="Caused by Not Found ", moreInfo="NOT_FOUND"'
          } ]
        }
      } )

    let mockResponse = new Response()
    let mockRequest = new Request()

    getCredentialsCtrl( mockRequest, mockResponse )

    it( 'should respond with 404', function ( done ) {
      expect( mockResponse.statusCode ).to.equal( 404 )
      done()
    } )

    it( 'should respond with downstram service error in detail', function ( done ) {
      expect( mockResponse.response.detail ).to.be.an( 'object' )
      done()
    } )

  } )

  describe( 'Removing credentials for a user', function () {

    nock( 'https://' + config.services.credentials.root_v2 )
      .delete( '/users/2265507445/providers/12345-12345-12345' )
      .reply( 204, '' )

    nock( 'https://' + config.services.profile.root )
      .delete( '/profiles/2265507445/providers/12345-12345-12345' )
      .reply( 204, '' )

    let options = {
      method: 'DELETE',
      params: {
        id: '12345-12345-12345'
      }
    }
    let mockResponse = new Response()
    let mockRequest = new Request( options )

    deleteProviderCredentialsCtrl( mockRequest, mockResponse )

    it( 'should respond with 204', function ( done ) {
      expect( mockResponse.statusCode ).to.equal( 204 )
      done()
    } )

  } )

  describe( 'Removing credentials for a user fails', function () {

    nock( 'https://' + config.services.credentials.root_v2 )
      .delete( '/users/2265507445/providers/12345-12345-12345' )
      .reply( 204, '' )

    nock( 'https://' + config.services.profile.root )
      .delete( '/profiles/2265507445/providers/12345-12345-12345' )
      .reply( 500, '' )

    let options = {
      method: 'DELETE',
      params: {
        id: '12345-12345-12345'
      }
    }
    let mockResponse = new Response()
    let mockRequest = new Request( options )

    deleteProviderCredentialsCtrl( mockRequest, mockResponse )

    it( 'should respond with 500', function ( done ) {
      expect( mockResponse.statusCode ).to.equal( 500 )
      done()
    } )

    it( 'should respond with message "credentials did not delete properly"', function ( done ) {
      expect( mockResponse.response ).to.equal( 'credentials did not delete properly' )
      done()
    } )

  } )

  describe( 'Removing a credentialSet for a user', function () {

    nock( 'https://' + config.services.credentials.root_v2 )
      .delete( '/users/2265507445/credentials/515b833c-dea1-40f0-a9f9-0d204283218f' )
      .reply( 204, '' )

    nock( 'https://' + config.services.profile.root )
      .delete( '/profiles/2265507445/providers/12345-12345-12345/credentials/515b833c-dea1-40f0-a9f9-0d204283218f' )
      .reply( 204, '' )

    let options = {
      method: 'DELETE',
      params: {
        id: '515b833c-dea1-40f0-a9f9-0d204283218f'
      },
      body: {
        providerId: '12345-12345-12345'
      }
    }
    let mockResponse = new Response()
    let mockRequest = new Request( options )

    deleteCredentialSetCtrl( mockRequest, mockResponse )

    it( 'should respond with 204', function ( done ) {
      expect( mockResponse.statusCode ).to.equal( 204 )
      done()
    } )

    it( 'should respond true if both profile and credential return 204', function ( done ) {
      expect( mockResponse.response ).to.be.true
      done()
    } )

  } )

  describe( 'Removing a credentialSet for a realm', function () {

    nock( 'https://' + config.services.credentials.root_v2 )
        .delete( '/realms/50000003/credentials/515b833c-dea1-40f0-a9f9-0d204283218f' )
        .reply( 204, '' )

    nock( 'https://' + config.services.profile.root )
        .delete( '/profiles/2265507445/providers/12345-12345-12345/credentials/515b833c-dea1-40f0-a9f9-0d204283218f' )
        .reply( 204, '' )

    let options = {
      method: 'DELETE',
      params: {
        id: '515b833c-dea1-40f0-a9f9-0d204283218f'
      },
      body: {
        providerId: '12345-12345-12345',
        isRealmContext: true
      }
    }
    let mockResponse = new Response()
    let mockRequest = new Request( options )

    deleteCredentialSetCtrl( mockRequest, mockResponse )

    it( 'should respond with 204', function ( done ) {
      expect( mockResponse.statusCode ).to.equal( 204 )
      done()
    } )

    it( 'should respond true if both profile and credential return 204', function ( done ) {
      expect( mockResponse.response ).to.be.true
      done()
    } )

  } )

  describe( 'Removing a credentialSet for a user fails', function () {

    nock( 'https://' + config.services.credentials.root )
      .delete( '/credentials/515b833c-dea1-40f0-a9f9-0d204283218f' )
      .reply( 204, '' )

    nock( 'https://' + config.services.profile.root )
      .delete( '/profiles/2265507445/providers/12345-12345-12345/credentials/515b833c-dea1-40f0-a9f9-0d204283218f' )
      .reply( 500, '' )

    let options = {
      method: 'DELETE',
      params: {
        id: '515b833c-dea1-40f0-a9f9-0d204283218f'
      },
      body: {
        providerId: '12345-12345-12345'
      }
    }
    let mockResponse = new Response()
    let mockRequest = new Request( options )

    deleteCredentialSetCtrl( mockRequest, mockResponse )

    it( 'should respond with 500', function ( done ) {
      expect( mockResponse.statusCode ).to.equal( 500 )
      done()
    } )

    it( 'should respond with message "credentials did not delete properly"', function ( done ) {
      expect( mockResponse.response ).to.equal( 'credentials did not delete properly' )
      done()
    } )

  } )

  describe( 'Adding a credentialSet for a user', function () {

    nock( 'https://' + config.services.credentials.root )
      .post( '/credentials' )
      .reply( 201, {
        credentialSetId: '1234567890'
      } )

    nock( 'https://' + config.services.profile.root )
      .put( '/profiles' )
      .reply( 201, '' )

    let options = {
      method: 'POST',
      body: {
        'providerId': 'a00074d7-df15-49e1-8ade-f32a6ddfc8aa',
        'folderId': '12324234-df15-34534534-8ade-234523452345',
        'status': 'verified',
        'statusDetail': {
          'code': '0'
        },
        'compliance': {
          '7216': {
            'is7216': true
          }
        },
        'credentials': [ {
          'type': 'secret',
          'certVersion': 'v01_credential_service_cryption_nonprod_key.corp.intuit.net',
          'mappingSourceText': 'USERID',
          'mappingSourceValue': 'a3bab7fc34a501ce46de829cd217bbcacc246e2d74d4c4e7969ed5e63f1524bdf69f7f0f43056c52b209ceefff2193741dc886e7dbee996a7140697b89c74a3fb4e456cabf01badc8a5e3790dedc0438be89d10abbdd84cafb72bcc9d783937ce47bf12d54f327d647c72994f28df550d24d52d2e1627971f097d8e868dc8f034e2fc0a12f0bcf161eeb7af2cc1daa8a7709f33cc5cb60b1955bca352d0a8b990da0cfe3c429ebc93b36f3c2658a996df452a400445a4b20911fef4391481ed052e8d5e037f77600ebee8ec607fe8e7405d6cc5e56728654a41442a69aebf9f509bbf7f30ba45e46556ad5b204b2d3ae745494b8a81dae4d6840ae2f846541b0',
          'masked': '*************',
          'authenticationFieldId': '311cfa01-d146-403f-80f6-9d6aad5c20f2',
          'authenticationFieldValue': 'a3bab7fc34a501ce46de829cd217bbcacc246e2d74d4c4e7969ed5e63f1524bdf69f7f0f43056c52b209ceefff2193741dc886e7dbee996a7140697b89c74a3fb4e456cabf01badc8a5e3790dedc0438be89d10abbdd84cafb72bcc9d783937ce47bf12d54f327d647c72994f28df550d24d52d2e1627971f097d8e868dc8f034e2fc0a12f0bcf161eeb7af2cc1daa8a7709f33cc5cb60b1955bca352d0a8b990da0cfe3c429ebc93b36f3c2658a996df452a400445a4b20911fef4391481ed052e8d5e037f77600ebee8ec607fe8e7405d6cc5e56728654a41442a69aebf9f509bbf7f30ba45e46556ad5b204b2d3ae745494b8a81dae4d6840ae2f846541b0'
        }, {
          'type': 'nonSecret',
          'certVersion': 'v01_credential_service_cryption_nonprod_key.corp.intuit.net',
          'mappingSourceText': 'PASSWORD',
          'mappingSourceValue': '1099Variousv2',
          'masked': '*************',
          'authenticationFieldId': '1b12c948-57ab-4742-8ec2-bc5afc4ccd5e',
          'authenticationFieldValue': '1099Variousv2'
        } ]
      }
    }
    let mockResponse = new Response()
    let mockRequest = new Request( options )

    addCrededentialsCtrl( mockRequest, mockResponse )

    it( 'should respond with 201', function ( done ) {
      expect( mockResponse.statusCode ).to.equal( 201 )
      done()
    } )

    it( 'should respond with a new credentialSetId', function ( done ) {
      expect( mockResponse.response.credentialSetId ).to.equal( '1234567890' )
      done()
    } )

  } )

  describe( 'Updating a credentialSet for a user', function () {

    nock( 'https://' + config.services.credentials.root )
      .put( '/credentials/515b833c-dea1-40f0-a9f9-0d204283218f' )
      .reply( 201, '' )

    nock( 'https://' + config.services.profile.root )
      .put( '/profiles' )
      .reply( 201, '' )

    let options = {
      method: 'PUT',
      params: {
        id: '515b833c-dea1-40f0-a9f9-0d204283218f'
      },
      body: {
        'providerId': 'a00074d7-df15-49e1-8ade-f32a6ddfc8aa',
        'folderId': '12324234-df15-34534534-8ade-234523452345',
        'status': 'verified',
        'statusDetail': {
          'code': '0'
        },
        'compliance': {
          '7216': {
            'is7216': true
          }
        },
        'credentials': [ {
          'type': 'secret',
          'certVersion': 'v01_credential_service_cryption_nonprod_key.corp.intuit.net',
          'mappingSourceText': 'USERID',
          'mappingSourceValue': 'a3bab7fc34a501ce46de829cd217bbcacc246e2d74d4c4e7969ed5e63f1524bdf69f7f0f43056c52b209ceefff2193741dc886e7dbee996a7140697b89c74a3fb4e456cabf01badc8a5e3790dedc0438be89d10abbdd84cafb72bcc9d783937ce47bf12d54f327d647c72994f28df550d24d52d2e1627971f097d8e868dc8f034e2fc0a12f0bcf161eeb7af2cc1daa8a7709f33cc5cb60b1955bca352d0a8b990da0cfe3c429ebc93b36f3c2658a996df452a400445a4b20911fef4391481ed052e8d5e037f77600ebee8ec607fe8e7405d6cc5e56728654a41442a69aebf9f509bbf7f30ba45e46556ad5b204b2d3ae745494b8a81dae4d6840ae2f846541b0',
          'masked': '*************',
          'authenticationFieldId': '311cfa01-d146-403f-80f6-9d6aad5c20f2',
          'authenticationFieldValue': 'a3bab7fc34a501ce46de829cd217bbcacc246e2d74d4c4e7969ed5e63f1524bdf69f7f0f43056c52b209ceefff2193741dc886e7dbee996a7140697b89c74a3fb4e456cabf01badc8a5e3790dedc0438be89d10abbdd84cafb72bcc9d783937ce47bf12d54f327d647c72994f28df550d24d52d2e1627971f097d8e868dc8f034e2fc0a12f0bcf161eeb7af2cc1daa8a7709f33cc5cb60b1955bca352d0a8b990da0cfe3c429ebc93b36f3c2658a996df452a400445a4b20911fef4391481ed052e8d5e037f77600ebee8ec607fe8e7405d6cc5e56728654a41442a69aebf9f509bbf7f30ba45e46556ad5b204b2d3ae745494b8a81dae4d6840ae2f846541b0'
        }, {
          'type': 'nonSecret',
          'certVersion': 'v01_credential_service_cryption_nonprod_key.corp.intuit.net',
          'mappingSourceText': 'PASSWORD',
          'mappingSourceValue': '1099Variousv2',
          'masked': '*************',
          'authenticationFieldId': '1b12c948-57ab-4742-8ec2-bc5afc4ccd5e',
          'authenticationFieldValue': '1099Variousv2'
        } ]
      }
    }
    let mockResponse = new Response()
    let mockRequest = new Request( options )

    updateCredentialsCtrl( mockRequest, mockResponse )

    it( 'should respond with 201', function ( done ) {
      expect( mockResponse.statusCode ).to.equal( 201 )
      done()
    } )

    it( 'should respond with with and empty body', function ( done ) {
      expect( mockResponse.response ).to.be.undefined
      done()
    } )

  } )

  describe( 'Getting a private key for encryption', function () {

    nock( 'https://' + config.services.credentials.root_v2 )
      .get( '/users/2265507445/keys/transportKeys' )
      .reply( 200, {
        "name": "v02.credserv.crypt.nonprod.key.corp.intuit.net",
        "version": "1",
        "certVersion": "v02.credserv.crypt.nonprod.key.corp.intuit.net",
        "creationTime": "2010-01-01T00:00:00",
        "algorithm": "RSA2048",
        "publicKey": "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAxbDh0C9M/68UHbRb+55TCtAuordczrEvueVzCfXt64FI0+KElFLaqP2J695NGL2SURgnAp2oaI5/GZPI3IszzmDrONV+0whYsxPnNfu/rr+PlfxlUDDMkLCXO+6nkzzf6dyXtzORl+l8DwqT4QTo/A1Mlr+EiLc/AxcEds/wigbm6FrKPFTRGSwr2cmKJXpQ78J72+L/rAjJDEo/7N6yuwqthcu2Q9RNoRM3r2IHV4eITS0gPlK5vGlYbzufPpfUIHvHFK0FGuFRBT76Up45HX3uZrbFaK+fNj0wQofc/qraDQuAuNlCoKkjbPeNCL1Eesqe0jrbF8MiR0i9iBzXCwIDAQAB",
        "additionalProperties": {}
    } )

    let options = {
      method: 'GET'
    }
    let mockResponse = new Response()
    let mockRequest = new Request( options )

    getPrivateKeyCtrl( mockRequest, mockResponse )

    it( 'should respond with 200', function ( done ) {
      expect( mockResponse.statusCode ).to.equal( 200 )
      done()
    } )

  } )

  describe( 'When things go wrong getting a private key for encryption', function () {

    nock( 'https://' + config.services.credentials.root_v2 )
      .get( '/users/2265507445/keys/transportKeys' )
      .reply( 500, {
        "code": "AuthenticationFailed",
        "type": "INPUT",
        "message": null,
        "detail": "",
        "moreInfo": null
    } )

    let options = {
      method: 'GET'
    }
    let mockResponse = new Response()
    let mockRequest = new Request( options )

    getPrivateKeyCtrl( mockRequest, mockResponse )    

    it( 'should respond with 500', function ( done ) {
      expect( mockResponse.statusCode ).to.equal( 500 )
      done()
    } )

  } )
} )
