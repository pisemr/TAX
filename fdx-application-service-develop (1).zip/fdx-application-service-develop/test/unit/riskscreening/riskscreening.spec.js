
import {
    expect
} from 'chai'
import nock from 'nock'
import config from '../../../lib/config'
import Request from '../../mocks/request'
import Response from '../../mocks/response'


import {
  validateClientToken,
  getUserRiskStatusCtrl,
  postRiskAssertion
} from '../../../routes/v2/riskscreening'

import riskAssesmentResonse from './mocks/riskassesment'
import riskAssesmentResonseBlock from './mocks/riskassesmentBlock'

const RSS_ROOT = config.services.rss.root
const RSS_RISK_ASSESMENT_PATH = config.services.rss.path.riskAssesment
const RSS_RISK_ASSERTION_PATH = config.services.rss.path.assertion
const PROTOCAL = config.services.protocal


describe('Riskscreening Route', function() {

    describe('Assesment: get recommendation success', function() {

      nock(`${PROTOCAL}://${RSS_ROOT}`)
        .post(RSS_RISK_ASSESMENT_PATH)
        .reply(200, riskAssesmentResonse)

      const options = {
        body: {
          providerId: '1234'
        }
      }

      let mockResponse = new Response()
      let mockRequest = new Request(options)

      getUserRiskStatusCtrl(mockRequest, mockResponse)

      it('should respond with 200 ok', function(done) {
        expect(mockResponse.statusCode).to.equal(200)
        done()
      })

      it('should respond with recommendation === review', function(done) {
        expect(mockResponse.response.recommendation).to.equal('review')
        done()
      })
    })

    describe('Assesment: get recommendation fail', function() {

      nock(`${PROTOCAL}://${RSS_ROOT}`)
        .post(RSS_RISK_ASSESMENT_PATH)
        .reply(500, {error:'error'})

      const options = {
        body: {
          providerId: '1234'
        }
      }

      let mockResponse = new Response()
      let mockRequest = new Request(options)

      getUserRiskStatusCtrl(mockRequest, mockResponse)

      it('should respond with 200 ok', function(done) {
        expect(mockResponse.statusCode).to.equal(200)
        done()
      })

      it('should respond with recommendation === review', function(done) {
        expect(mockResponse.response.recommendation).to.equal('pass')
        done()
      })
    })

    describe('Assertion/Feedback: post transaction success', function() {

      nock(`${PROTOCAL}://${RSS_ROOT}`)
        .post(RSS_RISK_ASSERTION_PATH)
        .reply(200, {})

      const options = {
        body: {
          providerId:'1234-1234-1234',
          transaction:'captcha_initiated'
        }
      }

      let mockResponse = new Response()
      let mockRequest = new Request(options)

      postRiskAssertion(mockRequest, mockResponse)

      it('should respond with 204 no content', function(done) {
        expect(mockResponse.statusCode).to.equal(204)
        done()
      })
    })
})
