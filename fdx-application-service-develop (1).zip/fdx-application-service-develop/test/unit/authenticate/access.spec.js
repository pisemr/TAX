import { expect } from 'chai'
import nock from 'nock'
import config from '../../../lib/config'
import Request from '../../mocks/request'
import Response from '../../mocks/response'
import { authenticateCtrl, authenticateDocumentsCtrl } from '../../../controllers/authenticate/authenticate'

//Mocks
import { Success1099, Success1098, w2Success, Error, ErrorMixedTypes, ErrorEmptyEntity, SuccessCommonAttr } from './mocks/access'
import { oauth } from './mocks/oauth'

const SAMPLE_BODY = {
  'authType': '1099-INT',
  'taxYear': 2015,
  'is7216': true,
  'providerId': '4f5035d9-c31f-41da-b5bc-6da281b446ca',
  'persistenceParams': {
    'folderId': '203508b9-deeb-4fc4-ba82-363f87ec9e11',
    'persistAsync': false,
    'persist': false
  },
  'offeringAttributes': [],
  'credentials': {
    'authFields': [ {
      'type': 'nonSecret',
      'id': 'USERID',
      'value': '1099Variousv2'
    }, {
      'type': 'secret',
      'id': 'PASSWORD',
      'value': '6ac07c547b92884e4ce909b26eb7abd147cd4e1432fca93068c14af8dbeab89f8ff0548184d692941cbd7796489250be1c6cde61a096de910248f665a20a9f53bb2d365b7a27decbc716bcfe37e724720065c151b2f35c5e82607a91d81dce7bcf9f23ec3283b1c94426ad78a6b2e1a9525b93b52c95858f4e12577554f7d670254197678e9c86ce2e70fdd4f7382510c26d7a9077f741bc8d5751188660eb8fcf235000c981def757506917cbe9267116013649435c7d32af060030e9fa56d987c0cb1e612878cb79bba79c789c376ee48becadd6a021df7398979cfaa075078d604d69fe4f375e054ed265b966acb2220a175ff0bfe2f5dc1b1c8b91a2861f'
    } ]
  },
  'certVersion': 'v01_credential_service_cryption_nonprod_key.corp.intuit.net',
  'entityTypes': [ '1099-B', '1099-DIV', '1099-INT', '1099-MISC', '1099-OID', '1099-R' ]
}

const SAMPLE_BODY_OFFERINGATTRIBUTES = {
  'authType': '1099-INT',
  'taxYear': 2015,
  'is7216': true,
  'providerId': '4f5035d9-c31f-41da-b5bc-6da281b446ca',
  'persistenceParams': {
    'folderId': '203508b9-deeb-4fc4-ba82-363f87ec9e11',
    'persistAsync': false,
    'persist': false
  },
  'offeringAttributes': [ {
    'key' : 'value'
  } ],
  'credentials': {
    'authFields': [ {
      'type': 'nonSecret',
      'id': 'USERID',
      'value': '1099Variousv2'
    }, {
      'type': 'secret',
      'id': 'PASSWORD',
      'value': '6ac07c547b92884e4ce909b26eb7abd147cd4e1432fca93068c14af8dbeab89f8ff0548184d692941cbd7796489250be1c6cde61a096de910248f665a20a9f53bb2d365b7a27decbc716bcfe37e724720065c151b2f35c5e82607a91d81dce7bcf9f23ec3283b1c94426ad78a6b2e1a9525b93b52c95858f4e12577554f7d670254197678e9c86ce2e70fdd4f7382510c26d7a9077f741bc8d5751188660eb8fcf235000c981def757506917cbe9267116013649435c7d32af060030e9fa56d987c0cb1e612878cb79bba79c789c376ee48becadd6a021df7398979cfaa075078d604d69fe4f375e054ed265b966acb2220a175ff0bfe2f5dc1b1c8b91a2861f'
    } ]
  },
  'certVersion': 'v01_credential_service_cryption_nonprod_key.corp.intuit.net',
  'entityTypes': [ '1099-B', '1099-DIV', '1099-INT', '1099-MISC', '1099-OID', '1099-R' ]
}

const SAMPLE_BODY_SAVED_CREDS = {
  'authType': '1099-INT',
  'taxYear': 2015,
  'is7216': true,
  'providerId': '4f5035d9-c31f-41da-b5bc-6da281b446ca',
  'persistenceParams': {
    'folderId': '203508b9-deeb-4fc4-ba82-363f87ec9e11',
    'persistAsync': false,
    'persist': false
  },
  'offeringAttributes': [],
  'credentials': {
    'credentialSetId': 'eb060d61-6d31-4399-95df-664b8f20bd5a'
  },
  'certVersion': 'v01_credential_service_cryption_nonprod_key.corp.intuit.net',
  'entityTypes': [ '1099-B', '1099-DIV', '1099-INT', '1099-MISC', '1099-OID', '1099-R' ]
}

// const SAMPLE_DOCUMENT_BODY = {
//   'systemAttributes': {
//     'id': '08cfa5d0-421a-4ec3-aae4-ab831edbfb90',
//     'parentId': 'e8480a83-3b1a-4d02-b074-befe45961603',
//     'version': '',
//     'userCreateDate': '2016-02-25T16:34:18.212+0000',
//     'createDate': '2016-02-25T16:34:18.234+0000',
//     'modifyDate': '2016-02-25T16:44:47.154+0000',
//     'owner': {
//       'namespaceId': '',
//       'authId': '123145816013222'
//     },
//     'assetId': '721719432476880372',
//     'lastUpdatingAssetId': '939018114495168361',
//     'originatingAssetId': '7278960489929281245',
//     'offeringId': 'Intuit.tax.browserwidgets.browserwidgets',
//     'selfLocator': '/documents/08cfa5d0-421a-4ec3-aae4-ab831edbfb90',
//     'channel': 'import',
//     'alternateDataLocators': [
//       {
//         'contentType': 'ofxData',
//         'alternateDataType': 'ofxData',
//         'locator': '/documents/08cfa5d0-421a-4ec3-aae4-ab831edbfb90/alternateData?type=ofxData'
//       },
//       {
//         'contentType': 'rawSemanticData',
//         'alternateDataType': 'rawSemanticData',
//         'locator': '/documents/08cfa5d0-421a-4ec3-aae4-ab831edbfb90/alternateData?type=rawSemanticData'
//       }
//     ]
//   },
//   'commonAttributes': {
//     'name': '1099-DIV_Testprovider012',
//     'documentType': '1099-DIV',
//     'is7216': true,
//     'providerName': 'PAYER NAME 1',
//     'offeringAttributes': [
//       {
//         'offeringId': 'test.offering.id',
//         'externalAssociations': [
//           'test-externalAssociations'
//         ]
//       }
//     ]
//   }
// }


describe('Authenticate Route', function () {

  describe('Getting a list of documents for 1099-INT, and adding offeringAttributes', function () {

    nock('https://' + config.services.access.root)
      .post('/access')
      .reply(200, SuccessCommonAttr)

    nock('https://' + config.services.documents.root)
      .get('/documents/3663d1b4-1df3-434f-ad02-400fb95e9d61?includeSource=false')
      .reply(200, {
        'systemAttributes': {
          'id': '08cfa5d0-421a-4ec3-aae4-ab831edbfb90',
          'parentId': 'e8480a83-3b1a-4d02-b074-befe45961603',
          'version': '',
          'userCreateDate': '2016-02-25T16:34:18.212+0000',
          'createDate': '2016-02-25T16:34:18.234+0000',
          'modifyDate': '2016-02-25T16:44:47.154+0000',
          'owner': {
            'namespaceId': '',
            'authId': '123145816013222'
          },
          'assetId': '721719432476880372',
          'lastUpdatingAssetId': '939018114495168361',
          'originatingAssetId': '7278960489929281245',
          'offeringId': 'Intuit.tax.browserwidgets.browserwidgets',
          'selfLocator': '/documents/08cfa5d0-421a-4ec3-aae4-ab831edbfb90',
          'channel': 'import',
          'alternateDataLocators': [
            {
              'contentType': 'ofxData',
              'alternateDataType': 'ofxData',
              'locator': '/documents/08cfa5d0-421a-4ec3-aae4-ab831edbfb90/alternateData?type=ofxData'
            },
            {
              'contentType': 'rawSemanticData',
              'alternateDataType': 'rawSemanticData',
              'locator': '/documents/08cfa5d0-421a-4ec3-aae4-ab831edbfb90/alternateData?type=rawSemanticData'
            }
          ]
        },
        'commonAttributes': {
          'name': '1099-DIV_Testprovider012',
          'documentType': '1099-DIV',
          'is7216': true,
          'providerName': 'PAYER NAME 1',
        }
      })

    nock('https://' + config.services.documents.root)
      .put('/documents/3663d1b4-1df3-434f-ad02-400fb95e9d61')
      .reply(204, '')

    let options = {
      method: 'POST',
      params: {
        documentId: '3663d1b4-1df3-434f-ad02-400fb95e9d61'
      },
      body: SAMPLE_BODY_OFFERINGATTRIBUTES
    }

    let mockResponse = new Response()
    let mockRequest = new Request( options )

    authenticateCtrl( mockRequest, mockResponse )

    it('should have a defined response', function (done) {
      expect(mockResponse).to.be.defined
      done()
    })

    it('should respond with 200 ok', function (done) {
      expect(mockResponse.statusCode).to.equal(200)
      done()
    })

    it('should return a list of documents, 1 to be exact', function (done) {
      expect(mockResponse.response.documents).to.have.length( 1 )
      done()
    })

    it('should let us know what authenticate context we are in', function (done) {
      expect(mockResponse.response.authType).to.equal( 'document' )
      done()
    })

    it('should have normalized documents from the DocumentModel', function (done) {
      expect(mockResponse.response.documents[0]).to.have.all.keys( 'documentType', 'documentLocation', 'documentId', 'folderId', 'documentName', 'documentUrl' )
      expect(mockResponse.response.documents[0].documentType).to.contain( '1099' )
      expect(mockResponse.response.documents[0].documentUrl).to.equal('https://vault-dev.api.intuit.com/v1/documents/3663d1b4-1df3-434f-ad02-400fb95e9d61/?format=view&intuit_apikey=')
      done()
    })
  })

  describe('Getting a list of documents for 1099-INT', function () {

    nock('https://' + config.services.access.root)
      .post('/access')
      .reply(200, Success1099)

    let options = {
      method: 'POST',
      body: SAMPLE_BODY
    }

    let mockResponse = new Response()
    let mockRequest = new Request( options )

    authenticateCtrl( mockRequest, mockResponse )

    it('should respond with 200 ok', function (done) {
      expect(mockResponse.statusCode).to.equal(200)
      done()
    })

    it('should return a list of documents, 7 to be exact', function (done) {
      expect(mockResponse.response.documents).to.have.length( 7 )
      done()
    })

    it('should let us know what authenticate context we are in', function (done) {
      expect(mockResponse.response.authType).to.equal( 'document' )
      done()
    })

    it('should have normalized documents from the DocumentModel', function (done) {
      expect(mockResponse.response.documents[0]).to.have.all.keys( 'documentType', 'documentLocation', 'documentId', 'folderId', 'documentName', 'documentUrl' )
      expect(mockResponse.response.documents[0].documentType).to.contain( '1099' )
      expect(mockResponse.response.documents[0].documentUrl).to.equal('https://vault-dev.api.intuit.com/v1/documents/660a2e1d-2ff7-4836-afd8-14f653473b13/?format=view&intuit_apikey=')
      done()
    })
  })

  describe('Getting a list of documents for 1099-INT with saved credentials', function () {

    nock('https://' + config.services.access.root)
      .post('/access')
      .reply(200, Success1099)

    let options = {
      method: 'POST',
      body: SAMPLE_BODY_SAVED_CREDS
    }

    let mockResponse = new Response()
    let mockRequest = new Request( options )

    authenticateCtrl( mockRequest, mockResponse )

    it('should respond with 200 ok', function (done) {
      expect(mockResponse.statusCode).to.equal(200)
      done()
    })

    it('should return a list of documents, 7 to be exact', function (done) {
      expect(mockResponse.response.documents).to.have.length( 7 )
      done()
    })

    it('should let us know what authenticate context we are in', function (done) {
      expect(mockResponse.response.authType).to.equal( 'document' )
      done()
    })

    it('should have normalized documents from the DocumentModel', function (done) {
      expect(mockResponse.response.documents[0]).to.have.all.keys( 'documentType', 'documentLocation', 'documentId', 'folderId', 'documentName', 'documentUrl' )
      expect(mockResponse.response.documents[0].documentType).to.contain( '1099' )
      expect(mockResponse.response.documents[0].documentUrl).to.equal('https://vault-dev.api.intuit.com/v1/documents/660a2e1d-2ff7-4836-afd8-14f653473b13/?format=view&intuit_apikey=')
      done()
    })
  })

  describe('Getting a list of documents for 1098', function () {

    nock('https://' + config.services.access.root)
      .post('/access')
      .reply(200, Success1098)

    let options = {
      method: 'POST',
      body: SAMPLE_BODY
    }

    let mockResponse = new Response()
    let mockRequest = new Request( options )

    authenticateCtrl( mockRequest, mockResponse )

    it('should respond with 200 ok', function (done) {
      expect(mockResponse.statusCode).to.equal(200)
      done()
    })

    it('should return a list of documents, 1 to be exact', function (done) {
      expect(mockResponse.response.documents).to.have.length( 1 )
      done()
    })

    it('should let us know what authenticate context we are in', function (done) {
      expect(mockResponse.response.authType).to.equal( 'document' )
      done()
    })

    it('should have normalized documents from the DocumentModel', function (done) {
      expect(mockResponse.response.documents[0]).to.have.all.keys( 'documentType', 'documentLocation', 'documentId', 'folderId', 'documentName', 'documentUrl' )
      expect(mockResponse.response.documents[0].documentType).to.equal( '1098' )
      expect(mockResponse.response.documents[0].documentUrl).to.equal('https://vault-dev.api.intuit.com/v1/documents/f2603139-32d3-4b17-b76c-123456789012/?format=view&intuit_apikey=')
      done()
    })
  })

  describe('Getting a list of documents for W2', function () {

    nock('https://' + config.services.access.root)
      .post('/access')
      .reply(200, w2Success)

    let options = {
      method: 'POST',
      body: SAMPLE_BODY
    }

    let mockResponse = new Response()
    let mockRequest = new Request( options )

    authenticateCtrl( mockRequest, mockResponse )

    it('should respond with 200 ok', function (done) {
      expect(mockResponse.statusCode).to.equal(200)
      done()
    })

    it('should return a list of documents, 1 to be exact', function (done) {
      expect(mockResponse.response.documents).to.have.length( 1 )
      done()
    })

    it('should let us know what authenticate context we are in', function (done) {
      expect(mockResponse.response.authType).to.equal( 'document' )
      done()
    })

    it('should have normalized documents from the DocumentModel', function (done) {
      expect(mockResponse.response.documents[0]).to.have.all.keys( 'documentType', 'documentLocation', 'documentId', 'folderId', 'documentName', 'documentUrl' )
      expect(mockResponse.response.documents[0].documentType).to.equal( 'W-2' )
      expect(mockResponse.response.documents[0].documentUrl).to.equal('https://vault-dev.api.intuit.com/v1/documents/1ec9c38e-ce50-45bb-984d-30acdee7ed2b/?format=view&intuit_apikey=')
      done()
    })
  })

  describe('Getting a list of documents, but it fails', function () {

    nock('https://' + config.services.access.root)
      .post('/access')
      .reply( 500, Error )

    let options = {
      method: 'POST',
      body: SAMPLE_BODY
    }

    let mockResponse = new Response()
    let mockRequest = new Request( options )

    authenticateCtrl( mockRequest, mockResponse )

    it('should respond with 500', function (done) {
      expect(mockResponse.statusCode).to.equal(500)
      done()
    })

    it('should respond with error code "FDPVLT-3004"', function (done) {
      expect(mockResponse.response.code).to.equal('FDPVLT-3004')
      done()
    })

    it('should let us know what authenticate context we are in', function (done) {
      expect(mockResponse.response.detail.authType).to.equal( 'document' )
      done()
    })

    it('should respond with error detail', function (done) {
      expect(mockResponse.response.detail).to.have.all.keys('code', 'message', 'authType', 'canDisplay', 'providerInfo', 'errorType' )
      expect(mockResponse.response.detail.providerInfo).to.have.all.keys('detail', 'message', 'type' )
      done()
    })
  })

  describe('Getting a list of documents, but one document returns an error in its body', function () {

    nock('https://' + config.services.access.root)
      .post('/access')
      .reply( 200, ErrorMixedTypes )

    let options = {
      method: 'POST',
      body: SAMPLE_BODY
    }

    let mockResponse = new Response()
    let mockRequest = new Request( options )

    authenticateCtrl( mockRequest, mockResponse )

    it('should respond with 200', function (done) {
      expect(mockResponse.statusCode).to.equal(200)
      done()
    })

    it('should return a list of documents, 1 to be exact', function (done) {
      expect(mockResponse.response.documents).to.have.length( 1 )
      done()
    })

    it('should let us know what authenticate context we are in', function (done) {
      expect(mockResponse.response.authType).to.equal( 'document' )
      done()
    })

    it('should have normalized documents from the DocumentModel', function (done) {
      expect(mockResponse.response.documents[0]).to.have.all.keys( 'documentType', 'documentLocation', 'documentId', 'folderId', 'documentName', 'documentUrl' )
      expect(mockResponse.response.documents[0].documentType).to.equal( '1098' )
      expect(mockResponse.response.documents[0].documentUrl).to.equal('https://vault-dev.api.intuit.com/v1/documents/f2603139-32d3-4b17-b76c-123456789012/?format=view&intuit_apikey=')
      done()
    })
  })

  describe('Getting a list of documents, but one document is empty', function () {

    nock('https://' + config.services.access.root)
      .post('/access')
      .reply( 200, ErrorEmptyEntity )

    let options = {
      method: 'POST',
      body: SAMPLE_BODY
    }

    let mockResponse = new Response()
    let mockRequest = new Request( options )

    authenticateCtrl( mockRequest, mockResponse )

    it('should respond with 200', function (done) {
      expect(mockResponse.statusCode).to.equal(200)
      done()
    })

    it('should return a list of documents, 1 to be exact', function (done) {
      expect(mockResponse.response.documents).to.have.length( 1 )
      done()
    })

    it('should let us know what authenticate context we are in', function (done) {
      expect(mockResponse.response.authType).to.equal( 'document' )
      done()
    })

    it('should have normalized documents from the DocumentModel', function (done) {
      expect(mockResponse.response.documents[0]).to.have.all.keys( 'documentType', 'documentLocation', 'documentId', 'folderId', 'documentName', 'documentUrl' )
      expect(mockResponse.response.documents[0].documentType).to.equal( '1098' )
      expect(mockResponse.response.documents[0].documentUrl).to.equal('https://vault-dev.api.intuit.com/v1/documents/f2603139-32d3-4b17-b76c-123456789012/?format=view&intuit_apikey=')
      done()
    })
  })

  describe('Getting a list of documents using OAuth', function() {

    describe('Happy path', function () {

      nock('https://' + config.services.partnerAuth.root)
        .get(config.services.partnerAuth.path.token)
        .query(oauth.responseToken)
        .reply(200, oauth.successPartnerAuthToken)

      nock('https://' + config.services.access.root)
        .post('/access')
        .reply(200, oauth.successAccessService)

      let mockRequest = new Request( oauth.requestOptions )
      let mockResponse = new Response()

      authenticateDocumentsCtrl( mockRequest, mockResponse )

      it('should return documents', function (done) {
        expect(mockResponse.response.providerResponse).to.have.all.keys( 'hostResponse', 'fdp1099KV2S', 'fdp1099MiscV2S' )
        done()
      })
    })

    describe('Partner Auth error', function () {

      nock('https://' + config.services.partnerAuth.root)
        .get(config.services.partnerAuth.path.token)
        .query(oauth.responseToken)
        .reply(500, oauth.errorPartnerAuthToken)

      let mockRequest = new Request( oauth.requestOptions )
      let mockResponse = new Response()

      authenticateDocumentsCtrl( mockRequest, mockResponse )

      it('should return an error', function (done) {
        expect(mockResponse.response).to.contain.all.keys("statusCode", "code", "message", "detail")
        expect(mockResponse.response.message).to.contain("downstream service error")
        done()
      })
    })

    describe('Access Service error', function () {

      nock('https://' + config.services.partnerAuth.root)
        .get(config.services.partnerAuth.path.token)
        .query(oauth.responseToken)
        .reply(200, oauth.successPartnerAuthToken)

      nock('https://' + config.services.access.root)
        .post('/access')
        .reply(500, oauth.errorAccessService)

      let mockRequest = new Request( oauth.requestOptions )
      let mockResponse = new Response()

      authenticateDocumentsCtrl( mockRequest, mockResponse )

      it('should return an error', function (done) {
        expect(mockResponse.response).to.contain.all.keys("statusCode", "code", "message", "detail")
        expect(mockResponse.response.message).to.contain("downstream service error")
        done()
      })
    })
  })
})
