import { expect } from 'chai'
import nock from 'nock'
import config from '../../../lib/config'
import Request from '../../mocks/request'
import Response from '../../mocks/response'
import { authenticateMFACtrl, authenticateCtrl } from '../../../controllers/authenticate/authenticate'

const MFA_RESPONSE_FROM_AVS = require( './mocks/mfa' ).original
const MFA_RESPONSE_TO_MATCH = require( './mocks/mfa' ).normalized
const RESPONSE_FROM_AVS = require( './mocks/accounts' ).original
const RESPONSE_TO_MATCH = require( './mocks/accounts' ).normalized

const SAMPLE_BODY = {
  'authType': 'account',
  'taxYear': 2015,
  'is7216': true,
  'providerId': '254f9b91-e608-468c-a6a6-de5352f106cc',
  'persistenceParams': {
    'folderId': '',
    'persistAsync': false,
    'persist': false
  },
  'offeringAttributes': [],
  'encryption': {
    'key': 'MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAuioKK6BOykUfIkPJEnJRTx+TJ5Tb0mey/vqPMOlIwV/rgla+2FY9kr0e6CBuqO+LnhJCoUk9MSo5fTGtCI9enzR3FR/ZuDFftifkfntp5Wgc4ZhM/XxEkS339uK5XonzJoKceBvcR5nswXYxIAMTPtX7iCKnmy6h1IcaLwX4VRmrLbG5VN3JHBpFHMdL0t8FBa7Y/Nq4cVki572/ELz1dNERVLDpCeLgFNakQDcHVowA+Euu7OijWzvoFHCYJZ2rJyWkql/088CAIOrRGtbr/3KvPRcuHQkYEpZpfqcutaSNE1bpWi6zHGgwG7MYI0SdlUad8XtowzccEcZvZQz9hwIDAQAB',
    'keyVersion': 'v01.credserv.crypt.prod.key.corp.intuit.net'
  },
  'credentials': {
    'authFields': [ {
      'type': 'nonSecret',
      'id': 'userid',
      'value': 'avs_nmfa_ftcinacc_01'
    }, {
      'type': 'secret',
      'id': 'password',
      'value': '4eeb95b6578339e7a331674f35537182f1c3c967270c6b62741e8cc473073b44431fcf73a28bc17ca81181322c01daeede250c71ee1db2add0de6699687c4a1afab83f9f3e2638864f2616c7a4754021e54ee948169a9dce19e7009edbb5be970241ca94d426609bf5e0c9c10aab4ca414330911b26561091e21f08d1d2ff4179b13ffb731fbe2dd0460e874677798f489c99b95dea6af50ac6db421a8fab252f6363a2311de76c1471584ab10702b9e971a3d8026dc2a9c675fe86ac48e92ac2328ec2349e9c8e8d8637592e9e28fbd8e5125c5489af8777a9f44e315cb41446f85824a4e3302e0f0188086f67fa644f41b42f0f9e7f486330d22635b4821c5'
    } ]
  },
  'certVersion': 'v01_credential_service_cryption_nonprod_key.corp.intuit.net',
  'entityTypes': [ 'ACCOUNT' ]
}

const MFA_BODY = {
  'authType': 'account',
  'providerId': '254f9b91-e608-468c-a6a6-de5352f106cc',
  'persistenceParams': {
    'folderId': '',
    'persistAsync': false,
    'persist': false
  },
  'encryption': {
    'key': 'MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAuioKK6BOykUfIkPJEnJRTx+TJ5Tb0mey/vqPMOlIwV/rgla+2FY9kr0e6CBuqO+LnhJCoUk9MSo5fTGtCI9enzR3FR/ZuDFftifkfntp5Wgc4ZhM/XxEkS339uK5XonzJoKceBvcR5nswXYxIAMTPtX7iCKnmy6h1IcaLwX4VRmrLbG5VN3JHBpFHMdL0t8FBa7Y/Nq4cVki572/ELz1dNERVLDpCeLgFNakQDcHVowA+Euu7OijWzvoFHCYJZ2rJyWkql/088CAIOrRGtbr/3KvPRcuHQkYEpZpfqcutaSNE1bpWi6zHGgwG7MYI0SdlUad8XtowzccEcZvZQz9hwIDAQAB',
    'keyVersion': 'v01.credserv.crypt.prod.key.corp.intuit.net'
  },
  'credentials': {
    'authFields': [ {
      'type': 'MFAText',
      'id': 'x1xcJTd42aDK4DLeCS+EFtOy2mU+b2ZK7fQwgUWaRw8=',
      'value': '0371d6f6cf22e9d90e0ffc4b531354a6350fec89d8741429c1b760aa4cff68b145f3cdbcbcafb9a69ebd410d3ada13a98744615e1a66769c686a3e0cc3e0df74cabb284a7ff67233ae1b2299167df4e74fed559fc713fe1599508c92a1efd51865a7a9795c932475ac6c69142dd661d64a3d1343d3b3abfc2c02998595f4784430715432a77f426c9d3775a6897c5b6650faabc101a6866d12de907dcd9372f0cedf173b4c0e87be4f0c6fd2503c27a4bbe6ceefd9962e6b0555347cbe89f724c813e1f7a2dcd10d6c9d2f837961945601ec08105658e79b10e36e79f322062b570a440b542d5327e6c0017c7ad1c5f7c2da758b3f13eb1a098b9c4b66f122d3',
      'text': 'Who is your favorite sportsman?'
    }, {
      'type': 'MFAText',
      'id': 'bmlt24IHL+83gSJTEf28u45xnVUXrTDk255sOaOOdr0=',
      'value': '99ef66df91d3967737304950b49996f8665dcbdc2e2c9debdf79cecc95999e182a7631f8ccf054359e5f26e93d6c0bd6811eedf60110b133ed4c8c07cd113e7d33a462ab06b0a129dbf822d4c8bcdaaedaf8eb7d653da081f583c46b91424992f56aac154cb7d03572c03d012418680359fc7871c2844b3cf2ef75528ea3fb682ea4db28b8ed45059ba32ce3f007ac6da7394fd6c81956002a356e059411cca5387a2411249f4268db1f94a8b4b13fa9cd9837e7cef8b31febf4788abf4e521315ad6d4ea431fcb48c8f2087a6f53f1261f72ff08252ab47150f8aa582d22fd1c7959cdda86228ceb6d162713f60e651168eac98f26803d939805dba383da718',
      'text': 'What was your first car?'
    }, {
      'type': 'MFAText',
      'id': '9Cm+zeAmVsSXP82vEicXFxo/pNcG2BcnZ74ockeUvho=',
      'value': '0fbc9944d5a0e72ab0ff8c52043d170ca254bbf311689d1825a1a45183c019292bf2f73e96649d1d03b9dfcd6b77d9e3419f222c5d5abc76e6aae4985d3860422102d688236287d46f26dd2e67ace75f7217cd14ad980c9c95ed0b7d77b4139bfa7b585e5fc2ce5fd29ec61374757e06a3ace073cc3ffb34ea2d24348cf0a3535d1ccd93ebbca1ef974aa3226132aa4cecc525cbfdfe4dcc76b28337c62bffe8f16f1fab32921f83442411bd790e31907023d8335ed5d80c487b1a9409ac91a7ba21ef25018e3466da5a2893741adaad9ca013f32db78fa7bc2201b24ce785d08f8e1417b37145a58c63b701db21713100b61b9e33dc21d152b215c87a47983e',
      'text': 'Enter your car number'
    } ]
  },
  'mfaSession': 'TlRRMVl6WmpOV1V0WmpZNFl5MDBPV0UxTFdJMk5EY3ROMlk1WWpjMFlqSXlNREkzT2s5U2VuTmpMMFlyU1ZjNFlYbG9lSFpqYkRSVGNUQldTVlo0YTJsNWJDc3hjVW8yT1ZCcmFFMXdjVWs5',
  'certVersion': 'v01_credential_service_cryption_nonprod_key.corp.intuit.net'
}


describe( 'Authenticate Route', function () {

  describe( 'Getting a list of accounts', function () {

    nock( 'https://' + config.services.interaction.root )
      .post( '/profiles/2265507445/providers' )
      .reply( 200, RESPONSE_FROM_AVS )

    let options = {
      method: 'POST',
      body: SAMPLE_BODY
    }

    let mockResponse = new Response()
    let mockRequest = new Request( options )

    authenticateCtrl( mockRequest, mockResponse )

    it( 'should respond with 200 ok', function ( done ) {
      expect( mockResponse.statusCode ).to.equal( 200 )
      done()
    } )

    it( 'should match old response', function ( done ) {
      expect( mockResponse.response ).to.have.all.keys( 'providerId', 'accounts', 'accountEncrypted', 'mfaRequired', 'authType' )
      expect( mockResponse.response.providerId ).to.equal( RESPONSE_TO_MATCH.providerId )
      expect( mockResponse.response.mfaRequired ).to.equal( RESPONSE_TO_MATCH.mfaRequired )
      expect( mockResponse.response.authType ).to.equal( RESPONSE_TO_MATCH.authType )
      done()
    } )
  } )

  describe( 'Getting a list of accounts but the authType is not provided', function () {

    let options = {
      method: 'POST',
      body: {
        'taxYear': 2015,
        'is7216': true,
        'providerId': '254f9b91-e608-468c-a6a6-de5352f106cc',
        'persistenceParams': {
          'folderId': '',
          'persistAsync': false,
          'persist': false
        },
        'offeringAttributes': [],
        'encryption': {
          'key': 'MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAuioKK6BOykUfIkPJEnJRTx+TJ5Tb0mey/vqPMOlIwV/rgla+2FY9kr0e6CBuqO+LnhJCoUk9MSo5fTGtCI9enzR3FR/ZuDFftifkfntp5Wgc4ZhM/XxEkS339uK5XonzJoKceBvcR5nswXYxIAMTPtX7iCKnmy6h1IcaLwX4VRmrLbG5VN3JHBpFHMdL0t8FBa7Y/Nq4cVki572/ELz1dNERVLDpCeLgFNakQDcHVowA+Euu7OijWzvoFHCYJZ2rJyWkql/088CAIOrRGtbr/3KvPRcuHQkYEpZpfqcutaSNE1bpWi6zHGgwG7MYI0SdlUad8XtowzccEcZvZQz9hwIDAQAB',
          'keyVersion': 'v01.credserv.crypt.prod.key.corp.intuit.net'
        },
        'credentials': {
          'authFields': [ {
            'type': 'nonSecret',
            'id': 'userid',
            'value': 'avs_nmfa_ftcinacc_01'
          }, {
            'type': 'secret',
            'id': 'password',
            'value': '4eeb95b6578339e7a331674f35537182f1c3c967270c6b62741e8cc473073b44431fcf73a28bc17ca81181322c01daeede250c71ee1db2add0de6699687c4a1afab83f9f3e2638864f2616c7a4754021e54ee948169a9dce19e7009edbb5be970241ca94d426609bf5e0c9c10aab4ca414330911b26561091e21f08d1d2ff4179b13ffb731fbe2dd0460e874677798f489c99b95dea6af50ac6db421a8fab252f6363a2311de76c1471584ab10702b9e971a3d8026dc2a9c675fe86ac48e92ac2328ec2349e9c8e8d8637592e9e28fbd8e5125c5489af8777a9f44e315cb41446f85824a4e3302e0f0188086f67fa644f41b42f0f9e7f486330d22635b4821c5'
          } ]
        },
        'certVersion': 'v01_credential_service_cryption_nonprod_key.corp.intuit.net',
        'entityTypes': [ 'ACCOUNT' ]
      }
    }

    let mockResponse = new Response()
    let mockRequest = new Request( options )

    authenticateCtrl( mockRequest, mockResponse )

    it( 'should respond with 400', function ( done ) {
      expect( mockResponse.statusCode ).to.equal( 400 )
      done()
    } )

    it( 'should be a client error with FDPVLT-1000 error', function ( done ) {
      expect( mockResponse.response.type ).to.equal( 'CLIENT' )
      expect( mockResponse.response.code ).to.equal( 'FDPVLT-1000' )
      done()
    } )

    it('should have a correlationId',function ( done ) {
      expect( mockResponse.response.correlationId ).to.be.defined
      done()
    } )

  } )

  describe( 'Getting a list of accounts but AVS send a CLIENT error', function () {

    nock( 'https://' + config.services.interaction.root )
      .post( '/profiles/0987654321/providers' )
      .reply( 400, {
        'errors': [ {
          'code': 'AVS-1022',
          'type': 'CLIENT',
          'message': 'Error decrypting credentials',
          'detail': 'Fail while decrypting the text'
        } ]
      } )

    let options = {
      method: 'POST',
      body: SAMPLE_BODY,
      authId: '0987654321'
    }

    let mockResponse = new Response()
    let mockRequest = new Request( options )

    authenticateCtrl( mockRequest, mockResponse )

    it( 'should respond with 400', function ( done ) {
      expect( mockResponse.statusCode ).to.equal( 400 )
      done()
    } )

    it( 'should be a client error with FFDPVLT-4003 error', function ( done ) {
      expect( mockResponse.response.type ).to.equal( 'CLIENT' )
      expect( mockResponse.response.code ).to.equal( 'FDPVLT-4003' )
      expect( mockResponse.response.detail ).to.have.all.keys( 'code', 'message', 'authType', 'errorType' )
      done()
    } )

    it('should have a correlationId',function ( done ) {
      expect( mockResponse.response.correlationId ).to.be.defined
      done()
    } )

  } )

  describe( 'Getting a list of accounts but AVS send a SERVER error', function () {

    nock( 'https://' + config.services.interaction.root )
      .post( '/profiles/1234567890/providers' )
      .reply( 500, {
        'errors': [ {
          'code': 'AVS-2000',
          'type': 'SERVER',
          'message': 'Error decrypting credentials',
          'detail': 'Fail while decrypting the text'
        } ]
      } )

    let options = {
      method: 'POST',
      body: SAMPLE_BODY,
      authId: '1234567890'
    }

    let mockResponse = new Response()
    let mockRequest = new Request( options )

    authenticateCtrl( mockRequest, mockResponse )

    it( 'should respond with 500', function ( done ) {
      expect( mockResponse.statusCode ).to.equal( 500 )
      done()
    } )

    it( 'should be a client error with FDPVLT-4003 error', function ( done ) {
      expect( mockResponse.response.type ).to.equal( 'SERVER' )
      expect( mockResponse.response.code ).to.equal( 'FDPVLT-4003' )
      expect( mockResponse.response.detail ).to.have.all.keys( 'code', 'message', 'authType', 'errorType' )
      done()
    } )

    it('should have a correlationId',function ( done ) {
      expect( mockResponse.response.correlationId ).to.be.defined
      done()
    } )

  } )

  describe( 'Getting a list of accounts but AVS send a request for MFA', function () {

    nock( 'https://' + config.services.interaction.root )
      .post( '/profiles/112233445566789900/providers' )
      .reply( 200, MFA_RESPONSE_FROM_AVS )

    let options = {
      method: 'POST',
      body: SAMPLE_BODY,
      authId: '112233445566789900'
    }

    let mockResponse = new Response()
    let mockRequest = new Request( options )

    authenticateCtrl( mockRequest, mockResponse )

    it( 'should respond with 200', function ( done ) {
      //expect( mockResponse.statusCode ).to.equal( 200 )
      done()
    } )

    it( 'should equal normalized response MFA_RESPONSE_TO_MATCH', function ( done ) {
      //expect( mockResponse.response ).to.deep.equal( MFA_RESPONSE_TO_MATCH )
      done()
    } )
  } )

  describe( 'Getting a list of accounts but AVS send a 200 with error body', function () {

    nock( 'https://' + config.services.interaction.root )
      .post( '/profiles/00998877665544332211/providers' )
      .reply( 200, {
        'errors': [ {
          'code': 'AVS-130',
          'type': 'CLIENT',
          'message': 'Need additional authentication information.',
          'detail': 'User need to provided more authentication information.'
        } ]
      } )

    let options = {
      method: 'POST',
      body: SAMPLE_BODY,
      authId: '00998877665544332211'
    }

    let mockResponse = new Response()
    let mockRequest = new Request( options )

    authenticateCtrl( mockRequest, mockResponse )

    it( 'should respond with 500', function ( done ) {
      // console.log('JRR-RESPONSE', mockResponse)
      expect( mockResponse.statusCode ).to.equal( 500 )
      done()
    } )

    it( 'should respond with a normalized error', function ( done ) {
      expect( mockResponse.response.type ).to.equal( 'CLIENT' )
      expect( mockResponse.response.code ).to.equal( 'FDPVLT-4000' )
      expect( mockResponse.response.detail ).to.have.all.keys( 'code', 'message', 'authType', 'errorType' )
      expect( mockResponse.response.detail.code ).to.equal( 'AVS-130' )
      done()
    } )

    it( 'should respond with a detailed error message', function ( done ) {
      expect( mockResponse.response.detail.message ).to.equal( 'Need additional authentication information. User need to provided more authentication information.' )
      done()
    } )

    it('should have a correlationId',function ( done ) {
      expect( mockResponse.response.correlationId ).to.be.defined
      done()
    } )    
  } )

  describe( 'Getting a list of accounts after answering MFA question(s)', function () {

    nock( 'https://' + config.services.interaction.root )
      .post( '/profiles/03071985/providers' )
      .reply( 200, RESPONSE_FROM_AVS )

    let options = {
      method: 'POST',
      body: MFA_BODY,
      authId: '03071985'
    }

    let mockResponse = new Response()
    let mockRequest = new Request( options )

    authenticateMFACtrl( mockRequest, mockResponse )

    it( 'should respond with 200 ok', function ( done ) {
      expect( mockResponse.statusCode ).to.equal( 200 )
      done()
    } )

    it( 'should match old response', function ( done ) {
      expect( mockResponse.response ).to.have.all.keys( 'providerId', 'accounts', 'accountEncrypted', 'mfaRequired', 'authType' )
      expect( mockResponse.response.providerId ).to.equal( RESPONSE_TO_MATCH.providerId )
      expect( mockResponse.response.mfaRequired ).to.equal( false )
      expect( mockResponse.response.authType ).to.equal( RESPONSE_TO_MATCH.authType )
      done()
    } )
  } )

  describe( 'Getting a list of accounts after answering MFA question(s) but it fails', function () {

    nock( 'https://' + config.services.interaction.root )
      .post( '/profiles/18950307/providers' )
      .reply( 200, {
        'errors': [ {
          'code': 'AVS-185',
          'type': 'SERVER',
          'message': 'User actionable error',
          'detail': 'MFA Answer is incorrect'
        } ]
      } )

    let options = {
      method: 'POST',
      body: MFA_BODY,
      authId: '18950307'
    }

    let mockResponse = new Response()
    let mockRequest = new Request( options )

    authenticateMFACtrl( mockRequest, mockResponse )

    it( 'should respond with 500', function ( done ) {
      expect( mockResponse.statusCode ).to.equal( 500 )
      done()
    } )

    it( 'should match old response', function ( done ) {
      expect( mockResponse.response.type ).to.equal( 'SERVER' )
      expect( mockResponse.response.code ).to.equal( 'FDPVLT-4006' )
      expect( mockResponse.response.detail ).to.have.all.keys( 'code', 'message', 'authType', 'errorType' )
      expect( mockResponse.response.detail.code ).to.equal( 'AVS-185' )
      expect( mockResponse.response.detail.message ).to.equal( 'User actionable error MFA Answer is incorrect' )
      done()
    } )

    it('should have a correlationId',function ( done ) {
      expect( mockResponse.response.correlationId ).to.be.defined
      done()
    } )    
  } )

} )
