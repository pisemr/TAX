import { expect } from 'chai'
import nock from 'nock'
import config from '../../../../lib/config'
import Request from '../../../mocks/request'
import Response from '../../../mocks/response'
import { authenticate, redirect } from '../../../../controllers/oauth'
import PAResponse from '../mocks/partner-auth-response'

const QUERY_TO_MATCH_NOCK = {
  intuit_property: 'intuit',
  partner_uid: 'demo',
  offering_redirect_uri: decodeURIComponent( 'https%3A%2F%2Fvault-qal.api.intuit.com%2Fv1%2Foauth%2Fredirect%3Fredirect_url%3Dhttps%3A%2F%2Ffds-local.intuit.com%3A44300%2Ftarget%2Fdebug%2FpartnerAuthRedirectTarget.html%26txnId%3D84029e46-16f6-4a77-983a-e6b765e07079%26intuit_apikey%3Dpreprdakyresj2seWxR9pqWKZIAx7AaW5x2Mkpbu%26token_query%3D' ),
  oauth2_scopes: 'getAccounts'
}

let REQUEST_QUERY = {
  partner_uid: 'demo',
  offering_redirect_uri: decodeURIComponent( 'https%3A%2F%2Fvault-qal.api.intuit.com%2Fv1%2Foauth%2Fredirect%3Fredirect_url%3Dhttps%3A%2F%2Ffds-local.intuit.com%3A44300%2Ftarget%2Fdebug%2FpartnerAuthRedirectTarget.html%26txnId%3D84029e46-16f6-4a77-983a-e6b765e07079%26intuit_apikey%3Dpreprdakyresj2seWxR9pqWKZIAx7AaW5x2Mkpbu%26token_query%3D' ),
  intuit_property: 'intuit',
  txnId: '8b0b8e74-b4cb-4739-801c-897f614e20e7',
  intuit_apikey: 'preprdakyresj2seWxR9pqWKZIAx7AaW5x2Mkpbu',
  oauth2_scopes: 'getAccounts'
}


describe( 'OAuth Route', function () {

  describe( 'Initiating oAuth expecting JSON response', function () {

    nock( 'https://' + config.services.partnerAuth.root )
      .get( config.services.partnerAuth.path.initiate )
      .query( QUERY_TO_MATCH_NOCK )
      .reply( 200, PAResponse )


    let options = {
      query: REQUEST_QUERY,
      headers: {
        'accept': 'application/json'
      }
    }
    let mockResponse = new Response()
    let mockRequest = new Request( options )

    authenticate( mockRequest, mockResponse )

    it( 'should respond with a 200', function ( done ) {
      expect( mockResponse.statusCode ).to.equal( 200 )
      done()
    } )

    it( 'should contain a JSON response', function ( done ) {
      expect( mockResponse.response ).to.include.keys( 'uri' )
      done()
    } )

    it( 'should not have a Location header defined', function ( done ) {
      expect( mockResponse.headers.Location ).to.be.undefined
      done()
    } )

  } )

  describe( 'Initiating oAuth expecting a redirect', function () {

    nock( 'https://' + config.services.partnerAuth.root )
      .get( config.services.partnerAuth.path.initiate )
      .query( QUERY_TO_MATCH_NOCK )
      .reply( 200, PAResponse )


    let options = {
      query: REQUEST_QUERY,
      headers: {}
    }
    let mockResponse = new Response()
    let mockRequest = new Request( options )

    authenticate( mockRequest, mockResponse )

    it( 'should respond with a 302', function ( done ) {
      expect( mockResponse.statusCode ).to.equal( 302 )
      done()
    } )

    it( 'should contain the partnerAuth Root URI for redirect', function ( done ) {
      expect( mockResponse.headers.Location ).to.contain( 'https://partnerauth-e2e.platform.intuit.com' )
      done()
    } )

    it( 'should contain the the request_token', function ( done ) {
      expect( mockResponse.headers.Location ).to.contain( 'request_token' )
      done()
    } )


  } )

  describe( 'Bank redirect to FDX when Offering expects JSON', function () {

    let options = {
      query: {
        error_code: undefined,
        token_query: 'token=IM-A-TOKEN',
        redirect_url: 'https://offering-redirect.intuit.com/resolve',
        txnId: '1234567890'
      },
      headers: {
        'accept': 'application/json'
      }
    }

    let mockResponse = new Response()
    let mockRequest = new Request( options )

    redirect( mockRequest, mockResponse )

    it( 'should respond with a 200', function ( done ) {
      expect( mockResponse.statusCode ).to.equal( 200 )
      done()
    } )

    it( 'should contain a JSON response', function ( done ) {
      expect( mockResponse.response ).to.include.keys( 'uri' )
      done()
    } )

    it( 'should not have a Location header defined', function ( done ) {
      expect( mockResponse.headers.Location ).to.be.undefined
      done()
    } )


    // it( 'should contain the redirect URI provider by ofering', function ( done ) {
    //   expect( mockResponse.headers.Location ).to.contain( 'https://offering-redirect.intuit.com/resolve' )
    //   done()
    // } )
    //
    // it( 'should equal https://offering-redirect.intuit.com/resolve?txnId=1234567890&response_token=IM-A-TOKEN&token=IM-A-TOKEN', function ( done ) {
    //   expect( mockResponse.headers.Location ).to.equal( 'https://offering-redirect.intuit.com/resolve?txnId=1234567890&response_token=IM-A-TOKEN&token=IM-A-TOKEN' )
    //   done()
    // } )

  } )
  //
  // describe( 'Initiating oAuth for a provider, but we get an error', function () {
  //
  //   nock( 'https://' + config.services.partnerAuth.root )
  //     .get( config.services.partnerAuth.path.initiate )
  //     .query( QUERY_TO_MATCH_NOCK )
  //     .reply( 400, {
  //       'errors': [ {
  //         'source': 'CLIENT',
  //         'code': 'invalid_input',
  //         'description': 'Invalid Partner UID: boa_fail'
  //       } ]
  //     } )
  //
  //   let options = {
  //     query: REQUEST_QUERY
  //   }
  //
  //   let mockResponse = new Response()
  //   let mockRequest = new Request( options )
  //
  //   authenticate( mockRequest, mockResponse )
  //
  //   it( 'should respond with a 302', function ( done ) {
  //     expect( mockResponse.statusCode ).to.equal( 302 )
  //     done()
  //   } )
  //
  //   it( 'should contain a error code FDPAUTH-572', function ( done ) {
  //     expect( mockResponse.headers.Location ).to.contain( 'errorCode=FDPAUTH-572' )
  //     done()
  //   } )
  //
  //   it( 'should contain a error message', function ( done ) {
  //     expect( mockResponse.headers.Location ).to.contain( 'errorMessage=Invalid Partner UID: boa_fail' )
  //     done()
  //   } )
  //
  //   it( 'should contain the the txnId', function ( done ) {
  //     expect( mockResponse.headers.Location ).to.contain( 'txnId=8b0b8e74-b4cb-4739-801c-897f614e20e7' )
  //     done()
  //   } )
  //
  // } )
  //
  // describe( 'Initiating oAuth for a provider, but we get a partnerAuth server error', function () {
  //
  //   nock( 'https://' + config.services.partnerAuth.root )
  //     .get( config.services.partnerAuth.path.initiate )
  //     .query( QUERY_TO_MATCH_NOCK )
  //     .reply( 500, {
  //       'errors': [ {
  //         'source': 'SERVER',
  //         'code': 'partner_server_error',
  //         'description': 'SERVER ERROR'
  //       } ]
  //     } )
  //
  //   let options = {
  //     query: REQUEST_QUERY
  //   }
  //
  //   let mockResponse = new Response()
  //   let mockRequest = new Request( options )
  //
  //   authenticate( mockRequest, mockResponse )
  //
  //   it( 'should respond with a 302', function ( done ) {
  //     expect( mockResponse.statusCode ).to.equal( 302 )
  //     done()
  //   } )
  //
  //   it( 'should contain a error code FDPAUTH-580', function ( done ) {
  //     expect( mockResponse.headers.Location ).to.contain( 'errorCode=FDPAUTH-580' )
  //     done()
  //   } )
  //
  //   it( 'should contain the the txnId', function ( done ) {
  //     expect( mockResponse.headers.Location ).to.contain( 'txnId=8b0b8e74-b4cb-4739-801c-897f614e20e7' )
  //     done()
  //   } )
  //
  // } )
  //
  // describe( 'Initiating oAuth for a provider, but we get connection error', function () {
  //
  //   nock( 'https://' + config.services.partnerAuth.root )
  //     .get( config.services.partnerAuth.path.initiate )
  //     .query( QUERY_TO_MATCH_NOCK )
  //     .replyWithError({
  //       code    : 'ENOTFOUND',
  //       errno   : 'ENOTFOUND',
  //       syscall : 'getaddrinfo',
  //       hostname: 'fake.host.com',
  //       host    : 'fake.host.com',
  //       port    : 443
  //     })
  //
  //   let options = {
  //     query: REQUEST_QUERY
  //   }
  //
  //   let mockResponse = new Response()
  //   let mockRequest = new Request( options )
  //
  //   authenticate( mockRequest, mockResponse )
  //
  //   it( 'should respond with a 302', function ( done ) {
  //     expect( mockResponse.statusCode ).to.equal( 302 )
  //     done()
  //   } )
  //
  //   it( 'should contain a error code FDPAUTH-580', function ( done ) {
  //     expect( mockResponse.headers.Location ).to.contain( 'errorCode=FDPAUTH-580' )
  //     done()
  //   } )
  //
  //   it( 'should contain a error message: downstream service not availalble', function ( done ) {
  //     expect( mockResponse.headers.Location ).to.contain( 'errorMessage=downstream service not availalble' )
  //     done()
  //   } )
  //
  //   it( 'should contain the the txnId', function ( done ) {
  //     expect( mockResponse.headers.Location ).to.contain( 'txnId=8b0b8e74-b4cb-4739-801c-897f614e20e7' )
  //     done()
  //   } )
  //
  // } )
  //
  //
  // describe( 'Redirect error from Bank: configuration_error', function () {
  //
  //   let options = {
  //     query: {
  //       error_code: 'configuration_error',
  //       error_description: 'clicked cancel',
  //       intuit_apikey: 'preprdakyresj2seWxR9pqWKZIAx7AaW5x2Mkpbu',
  //       redirect_url: 'https://fds-local.intuit.com:44300/target/debug/partnerAuthRedirectTarget.html',
  //       token_query: '?error_source=SERVER',
  //       txnId: '46743514-88be-4cf3-ba0a-535149f7f622'
  //     }
  //   }
  //
  //   let mockResponse = new Response()
  //   let mockRequest = new Request( options )
  //
  //   redirect( mockRequest, mockResponse )
  //
  //   it( 'should respond with a 302', function ( done ) {
  //     expect( mockResponse.statusCode ).to.equal( 302 )
  //     done()
  //   } )
  //
  //   it( 'should contain a error code FDPAUTH-573', function ( done ) {
  //     expect( mockResponse.headers.Location ).to.contain( 'errorCode=FDPAUTH-573' )
  //     done()
  //   } )
  //
  //   it( 'should contain a error message', function ( done ) {
  //     expect( mockResponse.headers.Location ).to.contain( 'errorMessage=clicked cancel' )
  //     done()
  //   } )
  //
  //   it( 'should contain the the txnId', function ( done ) {
  //     expect( mockResponse.headers.Location ).to.contain( 'txnId=46743514-88be-4cf3-ba0a-535149f7f622' )
  //     done()
  //   } )
  //
  // } )
  //
  //
  // describe( 'Redirect error from Bank: access_denied', function () {
  //
  //   let options = {
  //     query: {
  //       error_code: 'access_denied',
  //       error_description: 'access denied for user',
  //       intuit_apikey: 'preprdakyresj2seWxR9pqWKZIAx7AaW5x2Mkpbu',
  //       redirect_url: 'https://fds-local.intuit.com:44300/target/debug/partnerAuthRedirectTarget.html',
  //       token_query: '?error_source=SERVER',
  //       txnId: '46743514-88be-4cf3-ba0a-535149f7f622'
  //     }
  //   }
  //
  //   let mockResponse = new Response()
  //   let mockRequest = new Request( options )
  //
  //   redirect( mockRequest, mockResponse )
  //
  //   it( 'should respond with a 302', function ( done ) {
  //     expect( mockResponse.statusCode ).to.equal( 302 )
  //     done()
  //   } )
  //
  //   it( 'should contain a error code FDPAUTH-571', function ( done ) {
  //     expect( mockResponse.headers.Location ).to.contain( 'errorCode=FDPAUTH-571' )
  //     done()
  //   } )
  //
  //   it( 'should contain a error message', function ( done ) {
  //     expect( mockResponse.headers.Location ).to.contain( 'errorMessage=access denied for user' )
  //     done()
  //   } )
  //
  //   it( 'should contain the the txnId', function ( done ) {
  //     expect( mockResponse.headers.Location ).to.contain( 'txnId=46743514-88be-4cf3-ba0a-535149f7f622' )
  //     done()
  //   } )
  //
  // } )
  //
  // describe( 'Redirect error from Bank: invalid_grant', function () {
  //
  //   let options = {
  //     query: {
  //       error_code: 'invalid_grant',
  //       error_description: 'access denied for user',
  //       intuit_apikey: 'preprdakyresj2seWxR9pqWKZIAx7AaW5x2Mkpbu',
  //       redirect_url: 'https://fds-local.intuit.com:44300/target/debug/partnerAuthRedirectTarget.html',
  //       token_query: '?error_source=SERVER',
  //       txnId: '46743514-88be-4cf3-ba0a-535149f7f622'
  //     }
  //   }
  //
  //   let mockResponse = new Response()
  //   let mockRequest = new Request( options )
  //
  //   redirect( mockRequest, mockResponse )
  //
  //   it( 'should respond with a 302', function ( done ) {
  //     expect( mockResponse.statusCode ).to.equal( 302 )
  //     done()
  //   } )
  //
  //   it( 'should contain a error code FDPAUTH-570', function ( done ) {
  //     expect( mockResponse.headers.Location ).to.contain( 'errorCode=FDPAUTH-570' )
  //     done()
  //   } )
  //
  //   it( 'should contain a error message', function ( done ) {
  //     expect( mockResponse.headers.Location ).to.contain( 'errorMessage=access denied for user' )
  //     done()
  //   } )
  //
  //   it( 'should contain the the txnId', function ( done ) {
  //     expect( mockResponse.headers.Location ).to.contain( 'txnId=46743514-88be-4cf3-ba0a-535149f7f622' )
  //     done()
  //   } )
  //
  // } )
  //
  // describe( 'Redirect error from Bank: invalid_input', function () {
  //
  //   let options = {
  //     query: {
  //       error_code: 'invalid_input',
  //       error_description: 'access denied for user',
  //       intuit_apikey: 'preprdakyresj2seWxR9pqWKZIAx7AaW5x2Mkpbu',
  //       redirect_url: 'https://fds-local.intuit.com:44300/target/debug/partnerAuthRedirectTarget.html',
  //       token_query: '?error_source=SERVER',
  //       txnId: '46743514-88be-4cf3-ba0a-535149f7f622'
  //     }
  //   }
  //
  //   let mockResponse = new Response()
  //   let mockRequest = new Request( options )
  //
  //   redirect( mockRequest, mockResponse )
  //
  //   it( 'should respond with a 302', function ( done ) {
  //     expect( mockResponse.statusCode ).to.equal( 302 )
  //     done()
  //   } )
  //
  //   it( 'should contain a error code FDPAUTH-572', function ( done ) {
  //     expect( mockResponse.headers.Location ).to.contain( 'errorCode=FDPAUTH-572' )
  //     done()
  //   } )
  //
  //   it( 'should contain a error message', function ( done ) {
  //     expect( mockResponse.headers.Location ).to.contain( 'errorMessage=access denied for user' )
  //     done()
  //   } )
  //
  //   it( 'should contain the the txnId', function ( done ) {
  //     expect( mockResponse.headers.Location ).to.contain( 'txnId=46743514-88be-4cf3-ba0a-535149f7f622' )
  //     done()
  //   } )
  //
  // } )
  //
  //
  // describe( 'Redirect error from Bank: partner_server_error', function () {
  //
  //   let options = {
  //     query: {
  //       error_code: 'partner_server_error',
  //       error_description: 'SERVER ERROR',
  //       intuit_apikey: 'preprdakyresj2seWxR9pqWKZIAx7AaW5x2Mkpbu',
  //       redirect_url: 'https://fds-local.intuit.com:44300/target/debug/partnerAuthRedirectTarget.html',
  //       token_query: '?error_source=SERVER',
  //       txnId: '46743514-88be-4cf3-ba0a-535149f7f622'
  //     }
  //   }
  //
  //   let mockResponse = new Response()
  //   let mockRequest = new Request( options )
  //
  //   redirect( mockRequest, mockResponse )
  //
  //   it( 'should respond with a 302', function ( done ) {
  //     expect( mockResponse.statusCode ).to.equal( 302 )
  //     done()
  //   } )
  //
  //   it( 'should contain a error code FDPAUTH-580', function ( done ) {
  //     expect( mockResponse.headers.Location ).to.contain( 'errorCode=FDPAUTH-580' )
  //     done()
  //   } )
  //
  //   it( 'should contain a error message', function ( done ) {
  //     expect( mockResponse.headers.Location ).to.contain( 'errorMessage=SERVER ERROR' )
  //     done()
  //   } )
  //
  //   it( 'should contain the the txnId', function ( done ) {
  //     expect( mockResponse.headers.Location ).to.contain( 'txnId=46743514-88be-4cf3-ba0a-535149f7f622' )
  //     done()
  //   } )
  //
  // } )
  //
  // describe( 'Redirect error from Bank: server_error', function () {
  //
  //   let options = {
  //     query: {
  //       error_code: 'server_error',
  //       error_description: 'SERVER ERROR',
  //       intuit_apikey: 'preprdakyresj2seWxR9pqWKZIAx7AaW5x2Mkpbu',
  //       redirect_url: 'https://fds-local.intuit.com:44300/target/debug/partnerAuthRedirectTarget.html',
  //       token_query: '?error_source=SERVER',
  //       txnId: '46743514-88be-4cf3-ba0a-535149f7f622'
  //     }
  //   }
  //
  //   let mockResponse = new Response()
  //   let mockRequest = new Request( options )
  //
  //   redirect( mockRequest, mockResponse )
  //
  //   it( 'should respond with a 302', function ( done ) {
  //     expect( mockResponse.statusCode ).to.equal( 302 )
  //     done()
  //   } )
  //
  //   it( 'should contain a error code FDPAUTH-591', function ( done ) {
  //     expect( mockResponse.headers.Location ).to.contain( 'errorCode=FDPAUTH-591' )
  //     done()
  //   } )
  //
  //   it( 'should contain a error message', function ( done ) {
  //     expect( mockResponse.headers.Location ).to.contain( 'errorMessage=SERVER ERROR' )
  //     done()
  //   } )
  //
  //   it( 'should contain the the txnId', function ( done ) {
  //     expect( mockResponse.headers.Location ).to.contain( 'txnId=46743514-88be-4cf3-ba0a-535149f7f622' )
  //     done()
  //   } )
  //
  // } )
  //
  // describe( 'Redirect error from Bank: uncategorized_error', function () {
  //
  //   let options = {
  //     query: {
  //       error_code: 'uncategorized_error',
  //       error_description: 'uncategorized error',
  //       intuit_apikey: 'preprdakyresj2seWxR9pqWKZIAx7AaW5x2Mkpbu',
  //       redirect_url: 'https://fds-local.intuit.com:44300/target/debug/partnerAuthRedirectTarget.html',
  //       token_query: '?error_source=SERVER',
  //       txnId: '46743514-88be-4cf3-ba0a-535149f7f622'
  //     }
  //   }
  //
  //   let mockResponse = new Response()
  //   let mockRequest = new Request( options )
  //
  //   redirect( mockRequest, mockResponse )
  //
  //   it( 'should respond with a 302', function ( done ) {
  //     expect( mockResponse.statusCode ).to.equal( 302 )
  //     done()
  //   } )
  //
  //   it( 'should contain a error code FDPAUTH-590', function ( done ) {
  //     expect( mockResponse.headers.Location ).to.contain( 'errorCode=FDPAUTH-590' )
  //     done()
  //   } )
  //
  //   it( 'should contain a error message', function ( done ) {
  //     expect( mockResponse.headers.Location ).to.contain( 'errorMessage=uncategorized error' )
  //     done()
  //   } )
  //
  //   it( 'should contain the the txnId', function ( done ) {
  //     expect( mockResponse.headers.Location ).to.contain( 'txnId=46743514-88be-4cf3-ba0a-535149f7f622' )
  //     done()
  //   } )
  //
  // } )

} )
