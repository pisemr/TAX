import {
    expect
} from 'chai'
import nock from 'nock'
import config from '../../../lib/config'
import Request from '../../mocks/request'
import Response from '../../mocks/response'

import {
  getNotifications
} from '../../../controllers/notifications/notifications'
import { createNotificationModel } from '../../../models/notifications/notification-model'



const migrationMock = require('./mocks/migrations')
const credentialMock = require('./mocks/credential')
const migrationProjMock = require('./mocks/migrationProjectDetails')


describe('Notifications', function () {

  nock('https://' + config.services.credentials.root_v2)
      .get( '/realms/50000003/credentials/3373e103-9851-4c52-9cdb-d126d4d47853' )
      .query(true)  
      .reply(200, credentialMock)     

  nock('https://' + config.services.fdms.root)
      .get('/credential_migrations')
      .query(true)
      .reply(200, migrationMock)

  nock('https://' + config.services.fdms.root)
      .get(`/projects/${migrationMock[0].projectId}`)
      .query(true)
      .reply(200, migrationProjMock)      

 

  describe('Models', function () {
    const migration = migrationMock[0]
    const __model = createNotificationModel(migration, credentialMock)
    it('notification model', (done) => {
      expect(__model).to.be.defined
      done()
    })

    it('should have expected values', (done) => {
      expect(__model.notificationType).to.equal('migration')
      expect(__model.credentialType).to.equal('OAuth')
      expect(__model.severity).to.equal('ERROR')
      expect(__model.notificationStatusCode).to.equal('CREATED')
      done()
    })
  })

  describe('credentials', function () {
    const options2 = {
      query : {
        isRealmContext: 'true',
        sourceCredentialSetId: '3373e103-9851-4c52-9cdb-d126d4d47853'
      }
    }

    let mockResponse2 = new Response()
    let mockRequest2 = new Request(options2)

    getNotifications(mockRequest2, mockResponse2)     

    it('should respond with 200 ok', done => {
      expect(mockResponse2.statusCode).to.equal(200)
      done()
    })

    it('should have credential type', done => {
      expect(Array.isArray(mockResponse2.response)).to.equal(true)
      expect(mockResponse2.response[0].notificationType).to.equal('credential')
      expect(mockResponse2.response[0].credentialType).to.equal('OAuth')
      done()      
    })

  })

})