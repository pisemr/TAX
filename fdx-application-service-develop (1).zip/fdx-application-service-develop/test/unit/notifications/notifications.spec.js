import {
    expect
} from 'chai'
import nock from 'nock'
import config from '../../../lib/config'
import Request from '../../mocks/request'
import Response from '../../mocks/response'

import {
  getNotifications
} from '../../../controllers/notifications/notifications'
import { createNotificationModel } from '../../../models/notifications/notification-model'



const migrationMock = require('./mocks/migrations')
const credentialMock = require('./mocks/cafCredential')
const migrationProjMock = require('./mocks/migrationProjectDetails')


describe('Notifications', function () {

  nock('https://' + config.services.credentials.root_v2)
      .get( '/realms/50000003/credentials/3373e103-9851-4c52-9cdb-d126d4d47853' )
      .query(true)  
      .reply(200, credentialMock)     

  nock('https://' + config.services.fdms.root)
      .get('/credential_migrations')
      .query(true)
      .reply(200, migrationMock)

  nock('https://' + config.services.fdms.root)
      .get(`/projects/${migrationMock[0].projectId}`)
      .query(true)
      .reply(200, migrationProjMock)      

 

  describe('Models', function () {
    const migration = migrationMock[0]
    const __model = createNotificationModel(migration, credentialMock)
    it('notification model', (done) => {
      expect(__model).to.be.defined
      done()
    })

    it('should have expected values', (done) => {
      expect(__model.notificationType).to.equal('migration')
      expect(__model.credentialType).to.equal('CAF')
      expect(__model.notificationStatusCode).to.equal('CREATED')
      expect(__model.severity).to.equal('INFO')
      done()
    })
  })

  describe('migrations', function () {
    const options = {
      query : {
        isRealmContext: 'true',
        sourceCredentialSetId: '3373e103-9851-4c52-9cdb-d126d4d47853',
        sourceAccountId: 'String',        
      }
    }

    let mockResponse = new Response()
    let mockRequest = new Request(options)

    getNotifications(mockRequest, mockResponse)     

    xit('wait', done => {
      setTimeout(() => {done()}, 100)
    })

    it('should respond with 200 ok', done => {
      expect(mockResponse.statusCode).to.equal(200)
      done()
    })

    it('should have migration type', done => {
      expect(Array.isArray(mockResponse.response)).to.equal(true)
      expect(mockResponse.response[0].notificationType).to.equal('migration')
      expect(mockResponse.response[0].credentialType).to.equal('CAF')
      done()      
    })

  })


})