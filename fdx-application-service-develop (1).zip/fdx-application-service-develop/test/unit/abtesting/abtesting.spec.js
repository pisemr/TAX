import { expect } from 'chai'
import nock from 'nock'
import config from '../../../lib/config'
import Request from '../../mocks/request'
import Response from '../../mocks/response'
import {
  getBucketAssignmentCtrl,
  assignBucketCtrl,
  createEventCtrl
} from '../../../controllers/abtesting/abtesting'

describe( 'AB Testing Route', function () {

  describe( 'Getting a user bucket successfully', function () {

    nock( 'https://' + config.services.ab.root )
      .get( '/assignments/applications/VAULT/experiments/' + config.services.ab.experiment + '/users/2265507445' )
      .reply( 200, {
        'assignment': 'Bucket_H',
        'cache': true,
        'status': 'EXISTING_ASSIGNMENT',
        'context': 'PROD',
        'payload': null
      } )

    let mockResponse = new Response()
    let mockRequest = new Request()

    getBucketAssignmentCtrl( mockRequest, mockResponse )

    it( 'should respond with 200', function ( done ) {
      expect( mockResponse.statusCode ).to.equal( 200 )
      done()
    } )

    it( 'should respond with a bucket assignment', function ( done ) {
      expect( mockResponse.response ).to.be.defined
      expect( mockResponse.response.assignment ).to.equal( 'Bucket_H' )
      done()
    } )

  } )

  describe( 'Updating a users bucket', function () {

    nock( 'https://' + config.services.ab.root )
      .put( '/assignments/applications/VAULT/experiments/' + config.services.ab.experiment + '/users/2265507445' )
      .reply( 204, '' )

    let options = {
      method: 'PUT'
    }
    let mockResponse = new Response()
    let mockRequest = new Request( options )

    assignBucketCtrl( mockRequest, mockResponse )

    it( 'should respond with 204', function ( done ) {
      expect( mockResponse.statusCode ).to.equal( 204 )
      done()
    } )

    it( 'should respond with an empty body', function ( done ) {
      expect( mockResponse.response ).to.be.undefined
      done()
    } )

  } )

  describe( 'Creating an event to the dashboard', function () {

    nock( 'https://' + config.services.ab.root )
      .post( '/events/applications/FDX/experiments/' + config.services.ab.experiment + '/users/2265507445' )
      .reply( 204, '' )

    let options = {
      method: 'POST',
      body: {
        'events': [ {
          'name': 'IMPRESSION'
        } ]
      }
    }
    let mockResponse = new Response()
    let mockRequest = new Request( options )

    createEventCtrl( mockRequest, mockResponse )

    it( 'should respond with 204', function ( done ) {
      expect( mockResponse.statusCode ).to.equal( 204 )
      done()
    } )

    it( 'should respond with an empty body', function ( done ) {
      expect( mockResponse.response ).to.be.undefined
      done()
    } )

  } )
} )
