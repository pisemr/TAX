import { expect } from 'chai'


import {
  FpoRequestModel
} from '../../../models/fpo/FpoRequestModel'

import getRequest from './mocks/formatRequests'

const IS_ASYNC = true

const acquire = getRequest('acquire')
const refresh = getRequest('refresh')
const mfa = getRequest('mfa')

let acquireAccountsModel = new FpoRequestModel( acquire('accounts'), IS_ASYNC )
let acquireTransactionsModel = new FpoRequestModel( acquire('transactions'), IS_ASYNC )
let acquireDocumentsModel = new FpoRequestModel( acquire('documents'), IS_ASYNC )
let acquireBillsModel = new FpoRequestModel( acquire('bills'), IS_ASYNC )
let acquireBillsModelMfa = new FpoRequestModel( mfa('bills'), IS_ASYNC )
let refreshBillsModel = new FpoRequestModel( refresh('bills'), IS_ASYNC )


describe('Acquire Request Models:', function () {

  describe('Acquire Accounts Model', function () {
    it('should have the proper structure', function (done) {

      expect(acquireAccountsModel.providers).to.have.lengthOf(1)
      expect(acquireAccountsModel.providers[0].credentialSets).to.have.lengthOf(1)
      expect(acquireAccountsModel.providers[0].credentialSets[0].channelId).to.be.defined
      expect(acquireAccountsModel.providers[0].credentialSets[0].credentials).to.have.lengthOf(2)
      expect(acquireAccountsModel.requestParams.selectors).to.have.key('accountSelector')
      expect(acquireAccountsModel.requestParams.selectors).to.not.have.key('documentSelector')
      expect(acquireAccountsModel.requestParams.selectors).to.not.have.key('billSelector')
      expect(acquireAccountsModel.requestParams.selectors).to.not.have.key('transactionSelector')
      expect(acquireAccountsModel.requestParams.bypassAccountsValidation).to.be.undefined
      done()
    })
  })

  describe('Acquire Transactions Model', function () {
    it('should have the proper structure', function (done) {      
      expect(acquireTransactionsModel.providers).to.have.lengthOf(1)
      expect(acquireTransactionsModel.providers[0].credentialSets).to.have.lengthOf(1)
      expect(acquireTransactionsModel.providers[0].credentialSets[0].channelId).to.be.defined
      expect(acquireTransactionsModel.providers[0].credentialSets[0].credentials).to.have.lengthOf(2)
      expect(acquireTransactionsModel.requestParams.selectors).to.have.keys('accountSelector', 'transactionSelector')
      expect(acquireTransactionsModel.requestParams.selectors).to.not.have.key('documentSelector')
      expect(acquireTransactionsModel.requestParams.selectors).to.not.have.key('billSelector')
      expect(acquireTransactionsModel.requestParams.bypassAccountsValidation).to.be.undefined
      done()
    })
  })

  describe('Acquire Documents Model', function () {
    it('should have the proper structure', function (done) {      
      expect(acquireDocumentsModel.providers).to.have.lengthOf(1)
      expect(acquireDocumentsModel.providers[0].credentialSets).to.have.lengthOf(1)
      expect(acquireDocumentsModel.providers[0].credentialSets[0].channelId).to.be.defined
      expect(acquireDocumentsModel.providers[0].credentialSets[0].credentials).to.have.lengthOf(2)
      expect(acquireDocumentsModel.requestParams.selectors).to.have.key('documentSelector')
      expect(acquireDocumentsModel.requestParams.selectors).to.not.have.key('accountSelector')
      expect(acquireDocumentsModel.requestParams.selectors).to.not.have.key('transactionSelector')
      expect(acquireDocumentsModel.requestParams.selectors).to.not.have.key('billSelector')
      expect(acquireDocumentsModel.requestParams.bypassAccountsValidation).to.be.undefined
      done()
    })
  })

  describe('Acquire Bills Model', function () {
    it('should have the proper structure', function (done) {
      expect(acquireBillsModel.providers).to.have.lengthOf(1)
      expect(acquireBillsModel.providers[0].credentialSets).to.have.lengthOf(1)
      expect(acquireBillsModel.providers[0].credentialSets[0].channelId).to.be.defined
      expect(acquireBillsModel.providers[0].credentialSets[0].credentials).to.have.lengthOf(2)
      expect(acquireBillsModel.requestParams.selectors).to.have.keys('transactionSelector', 'accountSelector', 'billSelector')
      expect(acquireBillsModel.requestParams.selectors).to.not.have.key('documentSelector')
      expect(acquireBillsModel.requestParams.bypassAccountsValidation).to.be.undefined
      done()
    })
  })
  
  describe('Acquire Bills Model on MFA', function () {
    it('should have the proper structure', function (done) {
      expect(acquireBillsModelMfa.providers).to.have.lengthOf(1)
      expect(acquireBillsModelMfa.providers[0].credentialSets).to.have.lengthOf(1)
      expect(acquireBillsModelMfa.providers[0].credentialSets[0].channelId).to.be.undefind
      expect(acquireBillsModelMfa.providers[0].credentialSets[0].credentialSetId).to.be.defined
      expect(acquireBillsModelMfa.providers[0].credentialSets[0].credentials).to.have.lengthOf(1)
      expect(acquireBillsModelMfa.requestParams.selectors).to.have.keys('transactionSelector', 'accountSelector', 'billSelector')
      expect(acquireBillsModelMfa.requestParams.selectors).to.not.have.key('documentSelector')
      expect(acquireBillsModelMfa.requestParams.bypassAccountsValidation).to.be.undefined
      expect(acquireBillsModelMfa.requestParams.mfaSession).to.be.defined
      done()
    })
  })

  describe('Refresh Bills Model on Refresh', function () {
    it('should have the proper structure', function (done) {
      expect(refreshBillsModel.providers).to.have.lengthOf(1)
      expect(refreshBillsModel.providers[0].credentialSets).to.have.lengthOf(1)
      expect(refreshBillsModel.providers[0].credentialSets[0].channelId).to.be.undefind
      expect(refreshBillsModel.providers[0].credentialSets[0].credentialSetId).to.be.defined
      expect(refreshBillsModel.providers[0].credentialSets[0].credentials).to.be.undefind
      expect(refreshBillsModel.requestParams.selectors).to.have.keys('transactionSelector', 'accountSelector', 'billSelector')
      expect(refreshBillsModel.requestParams.selectors).to.not.have.key('documentSelector')
      expect(refreshBillsModel.requestParams.selectors.accountSelector).to.have.key('accountList')
      expect(refreshBillsModel.requestParams.bypassAccountsValidation).to.be.undefined
      expect(refreshBillsModel.requestParams.mfaSession).to.be.defined
      done()
    })
  })
  
})
