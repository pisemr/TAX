import { expect } from 'chai'
import nock from 'nock'
import { oauth } from '../authenticate/mocks/oauth'
import config from '../../../lib/config'
import Request from '../../mocks/request'
import Response from '../../mocks/response'
import {
  acquireAccountsCtrl,
  mfaSubmitCtrl,
  fpoPollingCtrl,
  fpoCallbackCtrl
} from '../../../controllers/accounts/accounts'

import {
  fpoCtrl,
  entityTypeMissinsgError
} from '../../../controllers/fpo/fpo'

import { VAULT_ROUTE_ERRORS } from '@fdx/common/errors/error-mapping'

import {
  SyncAcquireResponse,
  SyncMFAResponse,
  AsyncAcquireResponse,
  AcquireRequest,
  AccountsResponses
} from '../accounts/mocks'

import getRequest from './mocks/formatRequests'

import CacheModel, {
  CACHE_STATUS_MAP,
  CACHE_CONNECTION_STATUS_MAP
} from '../../../models/cache/CacheModel'

import { acquireAccounts, refreshAccounts } from '../models/mocks/fpo.js'


import FDIFinalResponse from '../../../controllers/accounts/mockFinalResponse'
import FDIMFAResponse from "../../../controllers/accounts/mockMfaResponse"

const {
  InitialAccountsResponse,
  PollingAccountsResponse,
  UpdatedAccountsResponse,
  FinalAccountsResponse
} = AccountsResponses

const {
  acquireRequest,
  mfaRequest,
  refreshRequest
} = AcquireRequest

const TEST_AUTH_ID = 2265507445

const createMockForCachePut = function( returnStatus, correlationId, response) {
  nock( `https://${config.services.cache.root}` )
    .put( `/${config.services.cache.ticketlessPath}${config.services.cache.entryPrefix}${correlationId}` )
    .query( { 'ttl': config.services.cache.timeToLive, 'owner': TEST_AUTH_ID } )
    .reply( returnStatus, response )
}

const createMockForCacheGet = function( returnStatus, correlationId, response ) {
  nock( `https://${config.services.cache.root}` )
    .get( `/${config.services.cache.ticketlessPath}${config.services.cache.entryPrefix}${correlationId}`)
    .query( { 'owner': TEST_AUTH_ID } )
    .reply( returnStatus, response )
}

const createMockForAcquire = function( returnStatus, response ) {
  nock( 'https://' + config.services.fpo.root )
    .post( config.services.fpo.path.userAcquire.replace( /{authid}/, TEST_AUTH_ID ) )
    .reply( returnStatus, response )
}



describe( 'Acquire Controller', function() {

  describe( 'Submitting using new model', function() {
    let testCorrelationId = '2345-2345'
  
    createMockForCachePut(200, testCorrelationId, '')
    createMockForCacheGet(200, testCorrelationId, new CacheModel({
      correlationId: testCorrelationId,
      cacheStatus: CACHE_STATUS_MAP.INITIAL,
      response: {
        "omsCorrelationId": testCorrelationId
      },
      connectionStatus: CACHE_CONNECTION_STATUS_MAP.PENDING
    }))
    createMockForAcquire(200, AsyncAcquireResponse)
  
    let options = {
      method: 'POST',
      body: {
        ...getRequest('acquire')('accounts')
      }
    }
  
    let mockResponse = new Response()
    let mockRequest = new Request( options )
  
    fpoCtrl( mockRequest, mockResponse )
      
    it( 'should respond with 200 ok', function ( done ) {
      expect( mockResponse.statusCode ).to.equal( 200 )
      done()
    } )
  
  } )

  describe( 'Submitting using new model w/o entityTypes', function() {
    let testCorrelationId = '2345-2345'
  
    createMockForCachePut(200, testCorrelationId, '')
    createMockForCacheGet(200, testCorrelationId, new CacheModel({
      correlationId: testCorrelationId,
      cacheStatus: CACHE_STATUS_MAP.INITIAL,
      response: {
        "omsCorrelationId": testCorrelationId
      },
      connectionStatus: CACHE_CONNECTION_STATUS_MAP.PENDING
    }))
    createMockForAcquire(200, AsyncAcquireResponse)
  
    let options = {
      method: 'POST',
      body: {
        ...getRequest('acquire')('accounts')
      }
    }

    delete options.body.entityTypes
  
    let mockResponse = new Response()
    let mockRequest = new Request( options )
  
    fpoCtrl( mockRequest, mockResponse )
      
    it( 'should respond with 200 ok', function ( done ) {
      expect( mockResponse.statusCode ).to.equal( 200 )
      done()
    } )

    it( 'should set entityTypes to ["ACCOUNT"] if entityTypes are not passed in', function ( done ) {
      expect( mockRequest.body.entityTypes[0] ).to.equal('ACCOUNT')
      done()
    } )
  
  } )

  describe( 'Submitting using new model w/ entityTypes as string', function() {
    let testCorrelationId = '2345-2345'
  
    createMockForCachePut(200, testCorrelationId, '')
    createMockForCacheGet(200, testCorrelationId, new CacheModel({
      correlationId: testCorrelationId,
      cacheStatus: CACHE_STATUS_MAP.INITIAL,
      response: {
        "omsCorrelationId": testCorrelationId
      },
      connectionStatus: CACHE_CONNECTION_STATUS_MAP.PENDING
    }))
    createMockForAcquire(200, AsyncAcquireResponse)
  
    let options = {
      method: 'POST',
      body: {
        ...getRequest('acquire')('accounts')
      }
    }

    options.body.entityTypes = 'A STRING'
  
    let mockResponse = new Response()
    let mockRequest = new Request( options )
  
    fpoCtrl( mockRequest, mockResponse )
      
    it( 'should respond with 200 ok', function ( done ) {
      expect( mockResponse.statusCode ).to.equal( 200 )
      done()
    } )

    it( 'should set entityTypes to ["ACCOUNT"] if entityTypes are not passed in', function ( done ) {
      expect( mockRequest.body.entityTypes[0] ).to.equal('ACCOUNT')
      done()
    } )
  
  } )

  describe( 'Submitting using new model w/ entityTypes as an empty array', function() {
    let testCorrelationId = '2345-2345'
  
    createMockForCachePut(200, testCorrelationId, '')
    createMockForCacheGet(200, testCorrelationId, new CacheModel({
      correlationId: testCorrelationId,
      cacheStatus: CACHE_STATUS_MAP.INITIAL,
      response: {
        "omsCorrelationId": testCorrelationId
      },
      connectionStatus: CACHE_CONNECTION_STATUS_MAP.PENDING
    }))
    createMockForAcquire(200, AsyncAcquireResponse)
  
    let options = {
      method: 'POST',
      body: {
        ...getRequest('acquire')('accounts')
      }
    }

    options.body.entityTypes = []
  
    let mockResponse = new Response()
    let mockRequest = new Request( options )
  
    fpoCtrl( mockRequest, mockResponse )
      
    it( 'should respond with 200 ok', function ( done ) {
      expect( mockResponse.statusCode ).to.equal( 200 )
      done()
    } )

    it( 'should set entityTypes to ["ACCOUNT"] if entityTypes are not passed in', function ( done ) {
      expect( mockRequest.body.entityTypes[0] ).to.equal('ACCOUNT')
      done()
    } )
  
  } )

  describe( 'Submitting MFA using new model w/ entityTypes', function() {
    let testCorrelationId = '2345-2345'
  
    createMockForCachePut(200, testCorrelationId, '')
    createMockForCacheGet(200, testCorrelationId, new CacheModel({
      correlationId: testCorrelationId,
      cacheStatus: CACHE_STATUS_MAP.INITIAL,
      response: {
        "omsCorrelationId": testCorrelationId
      },
      connectionStatus: CACHE_CONNECTION_STATUS_MAP.PENDING
    }))
    createMockForAcquire(200, AsyncAcquireResponse)
  
    let options = {
      method: 'POST',
      body: {
        ...getRequest('accounts')('mfa')
      }
    }
  
    let mockResponse = new Response()
    let mockRequest = new Request( options )
  
    fpoCtrl( mockRequest, mockResponse )
      
    it( 'should respond with 200 ok', function ( done ) {
      expect( mockResponse.statusCode ).to.equal( 200 )
      done()
    } )

    it( 'should set entityTypes to ["ACCOUNT"] if entityTypes are not passed in', function ( done ) {
      expect( mockRequest.body.entityTypes[0] ).to.equal('ACCOUNT')
      done()
    } )
  
  } )

  describe( 'Submitting using legacy model', function() {
    let testCorrelationId = '2345-2345'
  
    createMockForCachePut(200, testCorrelationId, '')
    createMockForCacheGet(200, testCorrelationId, new CacheModel({
      correlationId: testCorrelationId,
      cacheStatus: CACHE_STATUS_MAP.INITIAL,
      response: {
        "omsCorrelationId": testCorrelationId
      },
      connectionStatus: CACHE_CONNECTION_STATUS_MAP.PENDING
    }))
    createMockForAcquire(200, AsyncAcquireResponse)
  
    let options = {
      method: 'POST',
      body: {
        ...acquireAccounts()
      }
    }
  
    let mockResponse = new Response()
    let mockRequest = new Request( options )
  
    fpoCtrl( mockRequest, mockResponse )
      
    it( 'should respond with 200 ok', function ( done ) {
      expect( mockResponse.statusCode ).to.equal( 200 )
      done()
    } )
  
  } )

  describe( 'Submitting wiht credentialSetIds as an array', function() {
    let testCorrelationId = '2345-2345'
  
    createMockForCachePut(200, testCorrelationId, '')
    createMockForCacheGet(200, testCorrelationId, new CacheModel({
      correlationId: testCorrelationId,
      cacheStatus: CACHE_STATUS_MAP.INITIAL,
      response: {
        "omsCorrelationId": testCorrelationId
      },
      connectionStatus: CACHE_CONNECTION_STATUS_MAP.PENDING
    }))
    createMockForAcquire(200, AsyncAcquireResponse)
  
    let options = {
      method: 'POST',
      body: {
        ...refreshAccounts()
      }
    }
  
    let mockResponse = new Response()
    let mockRequest = new Request( options )
  
    fpoCtrl( mockRequest, mockResponse )
      
    it( 'should respond with 200 ok', function ( done ) {
      expect( mockResponse.statusCode ).to.equal( 200 )
      done()
    } )
  
  } )

  // describe( 'Submitting using new model w/o entityTypes', function() {
  //   let testCorrelationId = '2345-2345'
  
  //   createMockForCachePut(200, testCorrelationId, '')
  //   createMockForCacheGet(200, testCorrelationId, new CacheModel({
  //     correlationId: testCorrelationId,
  //     cacheStatus: CACHE_STATUS_MAP.INITIAL,
  //     response: {
  //       "omsCorrelationId": testCorrelationId
  //     },
  //     connectionStatus: CACHE_CONNECTION_STATUS_MAP.PENDING
  //   }))
  //   createMockForAcquire(200, AsyncAcquireResponse)
  
  //   let options = {
  //     method: 'POST',
  //     body: {
  //       ...getRequest('acquire')('accounts')
  //     }
  //   }

  //   delete options.body.entityTypes

    
  //   let mockResponse = new Response()
  //   let mockRequest = new Request( options )
    
  //   fpoCtrl( mockRequest, mockResponse )
    
  //   it( 'should respond with 400', function ( done ) {
  //     expect( mockResponse.statusCode ).to.equal( 400 )
  //     done()
  //   } )

  //   it( 'should respond entityType Missinsg Error', function ( done ) {
  //     expect( mockResponse.response.detail.message ).to.equal( entityTypeMissinsgError )
  //     expect( mockResponse.response).to.include.key( 'intuit_tid' )
  //     done()
  //   } )
  
  // } )
  

} )
