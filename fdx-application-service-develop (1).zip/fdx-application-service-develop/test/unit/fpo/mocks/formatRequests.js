

const ACCOUNT_SELECTOR_ENTITIES      = [ 'ACCOUNT' ]
const TRANSACTION_SELECTOR_ENTITIES  = [ 'ACCOUNT', 'TRANSACTION_DOWNLOAD' ]
const BILL_SELECTOR_ENTITIES         = [ 'ACCOUNT', 'TRANSACTION_DOWNLOAD', 'LINKED_BILL' ]
const DOCUMENT_SELECTOR_ENTITIES     = [ '1099-INT', '1099-DIV', '1099-OID', '1099-R', '1099-B', '1099-MISC' ]

const ACQUIRE_REQUEST = entityTypes => ({
  "sync": false,
  "providerId": "90aec3e4-0d85-45fa-8a1b-b2ce655d6705",
  "channelId": "fbb3afd9-ebe7-411c-a1b8-f9d2ea67a970",
  "compliance": {
    "is7216": true
  },
  "accountList": null,
  "credentials": [{
    "id": "2ef8bcbd-db65-46e0-9f6f-2227aff8faae",
    "value": "sdfsdfdsf",
    "hideChars": false,
    "encrypted": false,
    "text": "Login",
    "optional": false
  }, {
    "id": "0bbcd4c6-52e4-42a4-9e23-ceeb1dd6883b",
    "value": "qweghfhgkuhkhjjbjhr654543wqty5rtyjgkuyyt",
    "hideChars": true,
    "encrypted": true,
    "text": "Password",
    "optional": false,
    "certVersion": "v02.credserv.crypt.nonprod.key.corp.intuit.net"
  }],
  "isRealmContext": false,
  "addPiiToProfile": false,
  "entityTypes": entityTypes
})

const REFRESH_REQUEST = entityTypes => ({
	"sync": false,
	"providerId": "90aec3e4-0d85-45fa-8a1b-b2ce655d6705",
	"credentialSetId": "a14ccb31-ee05-415d-8b46-311a61c3cf85",
	"accountList": [{
		"accountId": "urn:account:fdp::accountid:6cf73d60-bb36-11e7-b1b6-061b934c2838"
	}],
  "isRealmContext": false,
  "addPiiToProfile": false,
  "entityTypes": entityTypes
})

const MFA_REQUEST = entityTypes => ({
  "sync": false,
  "mfaSession": "T0RVME1HSXdNMk10Tm1SbVlTMDBZV0kwTFRnNVpHWXRNalZqTUdWa09EZzJPVFUxT2xNdlJ6SllZMnhzV2tjclJVUnVaWHBKYTNoWmJEbGxjbVZzY2xJMlVYTXZSSGRuYWtSS1kyZEtOWE05",  
  "providerId": "90aec3e4-0d85-45fa-8a1b-b2ce655d6705",
  "compliance": {
    "is7216": true
  },
  "accountList": null,
  "credentialSetId": "dd0650c4-cb74-491e-bf68-92e82f4816ce",
	"credentials": [{
		"id": "uNtEbCb4tPHVOr4jHE+HayLoGTMSfdqav990ZhSLA7k=",
		"value": "XXXXXXXXXX",
		"type": "MFAText",
		"hideChars": false,
		"encrypted": true,
		"text": "whats your pet&#39;s name",
		"certVersion": "v02.credserv.crypt.nonprod.key.corp.intuit.net"
	}],
  "isRealmContext": false,
  "addPiiToProfile": false,
  "entityTypes": entityTypes
})

const getRequest = requestType => context => {

  let entityTypes = []

  switch(context){
    case 'accounts' : entityTypes = ACCOUNT_SELECTOR_ENTITIES
      break
    case 'transactions' : entityTypes = TRANSACTION_SELECTOR_ENTITIES
      break
    case 'documents' : entityTypes = DOCUMENT_SELECTOR_ENTITIES
      break
    case 'bills' : entityTypes = BILL_SELECTOR_ENTITIES
      break
  }

  switch(requestType){
    case 'acquire' : return ACQUIRE_REQUEST(entityTypes)
    case 'refresh' : return REFRESH_REQUEST(entityTypes)
    case 'mfa' : return MFA_REQUEST(entityTypes)
  }
}

export default getRequest