import {
    expect
} from 'chai'
import nock from 'nock'
import config from '../../../lib/config'
import Request from '../../mocks/request'
import Response from '../../mocks/response'

import {
  migrateCtrl
} from '../../../controllers/migrations/migrations'
import MigrateModel from '../../../models/migrations/migrate-req'



const migrationMock = require('./mocks/migration-response-mock')


describe('Migrations', function () {

  nock('https://' + config.services.fdms.root)
      .post('/credential_migrations/1/migrate')
      .query(true)
      .reply(200, migrationMock)

   

  const options = {
    query : {
      isRealmContext: 'true',
    },
    body : {
      'migrationId' : 1,
      'sourceCredentialSetId' : 'string',
      'targetCredentialSetId': 'string'
    }
  }

  let mockResponse = new Response()
  let mockRequest = new Request(options)

  migrateCtrl(mockRequest, mockResponse)  

  describe('Models', function () {
    const __model = new MigrateModel(options.body)
    it('migration model', (done) => {
      expect(__model).to.be.defined
      done()
    })

    it('should have expected values', (done) => {
      expect(__model.targetCredentialSetId).to.equal('string')
      expect(__model.force).to.equal(false)
      done()
    })
  })

  describe('Posting', function () {

    xit('wait', done => {
      setTimeout(() => {done()}, 100)
    })

    it('should respond with 200 ok', done => {
      expect(mockResponse.statusCode).to.equal(200)
      done()
    })

    it('should have id', done => {
      expect(mockResponse.response.id).to.equal(1)
      expect(mockResponse.response.targetCredentialSetId).to.equal('string')
      done()      
    })

  })
})