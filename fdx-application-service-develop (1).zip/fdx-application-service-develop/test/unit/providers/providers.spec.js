
import {
    expect
} from 'chai'
import nock from 'nock'
import config from '../../../lib/config'
import cache from '../../../lib/cache'
import Request from '../../mocks/request'
import Response from '../../mocks/response'
import {
    getAllProvidersCtrl,
    getProviderByEINCtrl,
    getProvidersCtrl
} from '../../../controllers/providers/providers'

import {
  getRecommendedProvidersCtrl,
  getTypeaehaedProvidersCtrl,
  getProviderByIdCtrl
} from '../../../controllers/providers/providers-v2'


let provResponse = require('./mocks/providers-tocache-success-response')
let provEinResponse = require('./mocks/provider-success-response')
let sangEinResponse = require('./mocks/sangria-success-response')
let typeaheadResponse = require('./mocks/sts-success-response')
let typeaheadMandAResponse = require('./mocks/sts-success-m-and-a')
let typeaheadSameConnectivityResponse = require('./mocks/sts-success-same-connectivity')
let parentProviderResponse = require('./mocks/get-provider-success-m-and-a')
let cachedProvider = require('./mocks/cached-recommended-provider')
let providerDetailResponse = require('./mocks/provider-detail-success-response')
let providerDetailPartnerAuthPreferredResponse = require('./mocks/provider-detail-partnerauth-preferred-success-response')

describe('Providers Route', function() {

    describe('Getting providers from STS', function() {

        nock('https://api-e2e-fps.preprodsts.a.intuit.com/action/v1')
            .get('/access')
            .query({
              action: 'selectsearch',
              encapjson: true,
              pretty: true,
              models: 'e_ce_fps_us_fi_na_provider_1',
              template: 'fi_typeahead',
              'context.region.country': 'US',
              intent: 'qbo_widget',
              prefix: 'bank',
              zip: '',
              start: 0,
              rows: 10,
              lang: 'en',
            })
            .reply(200, typeaheadResponse)

        let options = {
          query: {
            query: 'bank',
            limit: 10,
            recipe: 'qbo_widget'
          }
        }

        let mockResponse = new Response()
        let mockRequest = new Request(options)


        getTypeaehaedProvidersCtrl(mockRequest, mockResponse)

        it('should respond with 200 ok', function(done) {
            expect(mockResponse.statusCode).to.equal(200)
            done()
        })

        it('should have an array of results', function(done) {
            expect(mockResponse.response.results).to.be.an('array')
            done()
        })

        it('should have a status', function(done) {
            expect(mockResponse.response.status).to.not.be.null
            done()
        })

    })

    describe('Getting M&A providers from STS', function() {

        nock('https://api-e2e-fps.preprodsts.a.intuit.com/action/v1')
            .get('/access')
            .query({
              action: 'selectsearch',
              encapjson: true,
              pretty: true,
              models: 'e_ce_fps_us_fi_na_provider_1',
              template: 'fi_typeahead',
              'context.region.country': 'US',
              intent: 'qbo_widget',
              prefix: 'bank',
              zip: '',
              start: 0,
              rows: 10,
              lang: 'en',
            })
            .reply(200, typeaheadMandAResponse)

        let options = {
          query: {
            query: 'bank',
            limit: 10,
            recipe: 'qbo_widget'
          }
        }

        nock('https://financialprovider-e2e.platform.intuit.net/v1/providers/2d9c3c41-86cb-49d3-969d-03c45c2ebaaa')
            .get('')
            .reply(200, parentProviderResponse)



        let mockResponse = new Response()
        let mockRequest = new Request(options)


        getTypeaehaedProvidersCtrl(mockRequest, mockResponse)

        it('should respond with 200 ok', function(done) {
            expect(mockResponse.statusCode).to.equal(200)
            done()
        })

        it('should have an array of results', function(done) {
            expect(mockResponse.response.results).to.be.an('array')
            done()
        })

        it('should have a status', function(done) {
            expect(mockResponse.response.status).to.not.be.null
            done()
        })

        it('should have a property called "parent"', function(done) {
            expect(mockResponse.response.results[0]).to.have.property('parent')
            done()
        })

        describe('M&A Parent provider structure', function() {
          it('should be an object', function(done) {
              expect(mockResponse.response.results[0].parent).to.be.an('object')
              done()
          })

          it('should have association type', function(done) {
              expect(mockResponse.response.results[0].parent).to.have.property('type')
              expect(mockResponse.response.results[0].parent.type).to.be.a('string').equal('MERGER_OR_ACQUISITION')
              done()
          })

          it('should have provider id', function(done) {
              expect(mockResponse.response.results[0].parent).to.have.property('id')
              expect(mockResponse.response.results[0].parent.id).to.be.a('string').equal('2d9c3c41-86cb-49d3-969d-03c45c2ebaaa')
              expect(mockResponse.response.results[0].parent.id).to.not.be.null
              done()
          })

          it('should have provider name', function(done) {
              expect(mockResponse.response.results[0].parent).to.have.property('name')
              expect(mockResponse.response.results[0].parent.name).to.be.a('string').equal('First National Bank (CO)')
              expect(mockResponse.response.results[0].parent.name).to.not.be.null
              done()
          })

          it('should have provider logo', function(done) {
              expect(mockResponse.response.results[0].parent).to.have.property('logoUrl')
              expect(mockResponse.response.results[0].parent.logoUrl).to.be.a('string').equal('https://vault-dev.api.intuit.com/content/general/icon_placeholder.png')
              expect(mockResponse.response.results[0].parent.logoUrl).to.not.be.null
              done()
          })

          it('should have provider website URL', function(done) {
              expect(mockResponse.response.results[0].parent).to.have.property('homePageUrl')
              expect(mockResponse.response.results[0].parent.homePageUrl).to.be.a('string').equal('http://www.1stnationalbank.com/mark/')
              expect(mockResponse.response.results[0].parent.homePageUrl).to.not.be.null
              done()
          })
        })
    })

    describe('Getting Same Connectivity(Partnership) providers from STS', function() {

        nock('https://api-e2e-fps.preprodsts.a.intuit.com/action/v1')
            .get('/access')
            .query({
              action: 'selectsearch',
              encapjson: true,
              pretty: true,
              models: 'e_ce_fps_us_fi_na_provider_1',
              template: 'fi_typeahead',
              'context.region.country': 'US',
              intent: 'qbo_widget',
              prefix: 'bank',
              zip: '',
              start: 0,
              rows: 10,
              lang: 'en',
            })
            .reply(200, typeaheadSameConnectivityResponse)

        let options = {
          query: {
            query: 'bank',
            limit: 10,
            recipe: 'qbo_widget'
          }
        }

        nock('https://financialprovider-e2e.platform.intuit.net/v1/providers/2d9c3c41-86cb-49d3-969d-03c45c2ebaaa')
            .get('')
            .reply(200, parentProviderResponse)



        let mockResponse = new Response()
        let mockRequest = new Request(options)


        getTypeaehaedProvidersCtrl(mockRequest, mockResponse)

        it('should respond with 200 ok', function(done) {
            expect(mockResponse.statusCode).to.equal(200)
            done()
        })

        it('should have an array of results', function(done) {
            expect(mockResponse.response.results).to.be.an('array')
            done()
        })

        it('should have a status', function(done) {
            expect(mockResponse.response.status).to.not.be.null
            done()
        })

        it('should have a property called "parent"', function(done) {
            expect(mockResponse.response.results[0]).to.have.property('parent')
            done()
        })

        describe('Same Connectivity(Partnership) Parent provider structure', function() {
          it('should be an object', function(done) {
              expect(mockResponse.response.results[0].parent).to.be.an('object')
              done()
          })

          it('should have association type', function(done) {
              expect(mockResponse.response.results[0].parent).to.have.property('type')
              expect(mockResponse.response.results[0].parent.type).to.be.a('string').equal('SAME_CONNECTIVITY')
              done()
          })

          it('should have provider id', function(done) {
              expect(mockResponse.response.results[0].parent).to.have.property('id')
              expect(mockResponse.response.results[0].parent.id).to.be.a('string').equal('2d9c3c41-86cb-49d3-969d-03c45c2ebaaa')
              expect(mockResponse.response.results[0].parent.id).to.not.be.null
              done()
          })

          it('should have provider name', function(done) {
              expect(mockResponse.response.results[0].parent).to.have.property('name')
              expect(mockResponse.response.results[0].parent.name).to.be.a('string').equal('First National Bank (CO)')
              expect(mockResponse.response.results[0].parent.name).to.not.be.null
              done()
          })

          it('should have provider logo', function(done) {
              expect(mockResponse.response.results[0].parent).to.have.property('logoUrl')
              expect(mockResponse.response.results[0].parent.logoUrl).to.be.a('string').equal('https://vault-dev.api.intuit.com/content/general/icon_placeholder.png')
              expect(mockResponse.response.results[0].parent.logoUrl).to.not.be.null
              done()
          })

          it('should have provider website URL', function(done) {
              expect(mockResponse.response.results[0].parent).to.have.property('homePageUrl')
              expect(mockResponse.response.results[0].parent.homePageUrl).to.be.a('string').equal('http://www.1stnationalbank.com/mark/')
              expect(mockResponse.response.results[0].parent.homePageUrl).to.not.be.null
              done()
          })
        })
    })

    describe('Getting recommended providers', function() {

      nock('https://api-e2e-fps.preprodsts.a.intuit.com/action/v1')
          .get('/access')
          .query({
            action: 'selectsearch',
            encapjson: true,
            pretty: true,
            models: 'e_ce_fps_us_fi_na_provider_1',
            template: 'topN_providers',
            'context.region.country': 'US',
            intent: 'qbo_widget',
            prefix: '',
            zip: '',
            start: 0,
            rows: 8,
            lang: 'en',
          })
          .reply(200, typeaheadResponse)

      let options = {
        query: {
          query: '',
          limit: 8,
          recipe: 'qbo_widget'
        }
      }

      let mockResponse = new Response()
      let mockRequest = new Request(options)

        getRecommendedProvidersCtrl(mockRequest, mockResponse)
        it('should respond with 200 ok', function(done) {
            expect(mockResponse.statusCode).to.equal(200)
            done()
        })

        it('should return an array of provider objects', function(done) {
            expect(mockResponse.response.results).to.be.an.array
            expect(mockResponse.response.results[0]).to.be.an.object
            done()
        })
    })

    describe('Getting providers directly from service', function() {

        nock('https://' + config.services.providers.root)
          .get('/' + config.services.providers.path.default + '?' + config.services.providers.query.allDocTypes)
          .reply(200, provResponse.body)

        let mockResponse = new Response()
        let mockRequest = new Request()

        getAllProvidersCtrl(mockRequest, mockResponse)


        it('should respond with 200 ok', function(done) {
            expect(mockResponse.statusCode).to.equal(200)
            done()
        })

        it('should have an array of providers', function(done) {
            expect(mockResponse.response.providers).to.be.an('array')
            done()
        })

        it('should have a status', function(done) {
            expect(mockResponse.response.status).to.not.be.null
            done()
        })

        it('should have property lastRunTime:', function(done) {
            expect(mockResponse.response.status.lastRunTime).to.not.be.null
            done()
        })

        it('should not respond from cache', function(done) {
            expect(mockResponse.response.fromCache).to.equal(false)
            done()
        })

        it('should not have multiple channels with the same type', function(done) {
            const providerToTest = mockResponse.response.providers.find(provider=>provider.id === 'multiple-webIntegration-channels')
            expect(providerToTest.ofxAuthenticationFields.length).to.equal(2)
            done()
        })
    })

    describe('Getting providers from cache', function() {

        cache.set('cachedProviders', {
            providers: [],
            status: {
                date: new Date()
            }
        })

        let mockResponse = new Response()
        let mockRequest = new Request()

        getAllProvidersCtrl(mockRequest, mockResponse)

        it('should respond from cache', function(done) {
            expect(mockResponse.response.fromCache).to.equal(true)
            done()
        })

        it('should have an array of providers', function(done) {
            expect(mockResponse.response.providers).to.be.an('array')
            done()
        })

        cache.del('cachedProviders')
    })

    describe('Getting providers from cache, but its stale', function() {

        nock('https://' + config.services.providers.root)
          .get('/' + config.services.providers.path.default + '?' + config.services.providers.query.allDocTypes)
          .reply(200, provResponse.body)

        let d = new Date()
        cache.set('cachedProviders', {
            providers: [],
            status: {
                date: d.setDate(d.getDate() - 5)
            }
        })

        let mockResponse = new Response()
        let mockRequest = new Request()

        getAllProvidersCtrl(mockRequest, mockResponse)

        it('should not respond from cache and make a new call', function(done) {
            expect(mockResponse.response.fromCache).to.equal(false)
            done()
        })

        it('should have an array of providers', function(done) {
            expect(mockResponse.response.providers).to.be.an('array')
            done()
        })

        cache.del('cachedProviders')
    })

    describe('Getting provider detail from service', function() {
        let providerId = '867c4a38-0d75-46ff-a4c2-f44cb63be2c9'
        let url = '/' + config.services.providers.path.default + providerId

        nock('https://' + config.services.providers.root)
            .get(url)
            .reply(200, providerDetailResponse.body)

        let options = {
            params: {
                id: providerId
            }
        }
        let mockResponse = new Response()
        let mockRequest = new Request(options)

        getProviderByIdCtrl(mockRequest, mockResponse)

        it('should not respond from cache and make a new call', function(done) {
            expect(mockResponse.response.fromCache).to.equal(false)
            done()
        })

        it('should have provider detail', function(done) {
            expect(mockResponse.response.name).to.equal('Chase Bank')
            expect(mockResponse.response.partnerAuth).to.equal(undefined)
            done()
        })

        cache.del('provider_' + providerId)
    })

    describe('Getting provider detail with partner auth support', function () {
      before((done) => {
        cache.flushAll()
        done()
      })

      let providerId = '867c4a38-0d75-46ff-a4c2-f44cb63be2c9'
      let url = '/' + config.services.providers.path.default + providerId

      nock('https://' + config.services.providers.root)
          .get(url)
          .reply(200, providerDetailPartnerAuthPreferredResponse)

      let options = {
          params: {
              id: providerId
          }
      }
      let mockResponse = new Response()
      let mockRequest = new Request(options)

      getProviderByIdCtrl(mockRequest, mockResponse)

      it('should return a partnerAuth object in the response body', (done) => {
        expect(mockResponse.response.partnerAuth.partnerUID).to.equal('boa_qa')
        expect(mockResponse.response.partnerAuth.channelId).to.equal('184285c5-39ab-4e72-afa9-6b9ed73781c8')
        done()
      })
      it('should return partnerAuthPreferred as true if partner auth is priority 1', (done) => {
        expect(mockResponse.response.partnerAuth.partnerAuthPreferred).to.equal(true)
        done()
      })

      after((done) => {
        cache.flushAll()
        done()
      })
    })

    describe('Getting provider detail from cache', function() {
        let providerId = '867c4a38-0d75-46ff-a4c2-f44cb63be2c9'

        let cacheObject = {}
        cacheObject.provider = Object.assign({}, providerDetailResponse.body)
        cacheObject.ttl = 60
        cacheObject.timestamp = new Date()
        cache.set('provider_' + providerId, cacheObject)

        let options = {
            params: {
                id: providerId
            }
        }
        let mockResponse = new Response()
        let mockRequest = new Request(options)

        getProviderByIdCtrl(mockRequest, mockResponse)


        it('should respond from cache', function(done) {
            expect(mockResponse.response.fromCache).to.equal(true)
            expect(mockResponse.response.isExpired).to.equal(false)
            done()
        })

        it('should have provider detail', function(done) {
            expect(mockResponse.response.name).to.equal('Chase Bank')
            done()
        })

        cache.del('provider_' + providerId)

    })

    describe('Getting provider detail with stale cache', function() {
        let providerId = '867c4a38-0d75-46ff-a4c2-f44cb63be2c9'
        let url = '/' + config.services.providers.path.default + providerId

        nock('https://' + config.services.providers.root)
            .get(url)
            .reply(200, providerDetailResponse.body)

        let cacheObject = {}
        cacheObject.provider = Object.assign({}, providerDetailResponse.body)
        cacheObject.ttl = 60
        cacheObject.timeStamp = new Date()
        cacheObject.timeStamp.setMinutes(cacheObject.timeStamp.getMinutes() -2);
        cache.set('provider_' + providerId, cacheObject)

        let options = {
            params: {
                id: providerId
            }
        }
        let mockResponse = new Response()
        let mockRequest = new Request(options)

        getProviderByIdCtrl(mockRequest, mockResponse)


        it('should respond from cache', function(done) {
            expect(mockResponse.response.fromCache).to.equal(false)
            expect(mockResponse.response.isExpired).to.equal(false)
            done()
        })

        it('should have provider detail', function(done) {
            expect(mockResponse.response.name).to.equal('Chase Bank')
            done()
        })

        cache.del('provider_' + providerId)

    })


    describe('Getting provider detail with stale cache but dead providerId returns cache anyway', function() {
        let providerId = '867c4a38-0d75-46ff-a4c2-f44cb63be2c9'

        let cacheObject = {}
        cacheObject.provider = Object.assign({}, providerDetailResponse.body)
        cacheObject.ttl = 60
        cacheObject.timeStamp = new Date()
        cacheObject.timeStamp.setMinutes(cacheObject.timeStamp.getMinutes() -2);
        cache.set('provider_' + providerId, cacheObject)

        let options = {
            params: {
                id: providerId
            }
        }
        let mockResponse = new Response()
        let mockRequest = new Request(options)

        getProviderByIdCtrl(mockRequest, mockResponse)


        it('should respond from cache', function(done) {
            expect(mockResponse.response.fromCache).to.equal(true)
            expect(mockResponse.response.isExpired).to.equal(true)
            done()
        })

        it('should have provider detail', function(done) {
            expect(mockResponse.response.name).to.equal('Chase Bank')
            done()
        })

        cache.del('provider_' + providerId)

    })


    describe('Getting provider and employer data with v1', function() {

        nock('https://' + config.services.providers.root)
            .get('/' + config.services.providers.path.default+'?ein=123456789')
            .reply(200, provEinResponse.body)

        nock('https://' + config.services.sangria.root)
            .get('/' + config.services.sangria.path.default+'?employerIdNumber=123456789')
            .reply(200, sangEinResponse.body)

        let options = {
            query: {
                ein: '123456789'
            }
        }
        let mockResponse = new Response()
        let mockRequest = new Request(options)

        getProviderByEINCtrl(mockRequest, mockResponse)

        it('should respond with 200 ok', function(done) {
            expect(mockResponse.statusCode).to.equal(200)
            done()
        })

        it('should have an array providers', function(done) {
            expect(mockResponse.response.providers).to.be.an('array')
            done()
        })

        it('should have an array employers', function(done) {
            expect(mockResponse.response.employers).to.be.an('array')
            done()
        })

    })

    describe('Getting provider and employer data with v2', function() {

        nock('https://' + config.services.providers.root)
            .get('/' + config.services.providers.path.default+'?ein=123456789')
            .reply(200, provEinResponse.body)

        nock('https://' + config.services.sangria.root)
            .get('/' + config.services.sangria.path.default+'?employerIdNumber=123456789')
            .reply(200, sangEinResponse.body)

        let options = {
            params: {
                ein: '123456789'
            }
        }
        let mockResponse = new Response()
        let mockRequest = new Request(options)

        getProviderByEINCtrl(mockRequest, mockResponse)

        it('should respond with 200 ok', function(done) {
            expect(mockResponse.statusCode).to.equal(200)
            done()
        })

        it('should have an array providers', function(done) {
            expect(mockResponse.response.providers).to.be.an('array')
            done()
        })

        it('should have an array employers', function(done) {
            expect(mockResponse.response.employers).to.be.an('array')
            done()
        })

    })
})
