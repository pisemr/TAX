import { expect } from 'chai'
import nock from 'nock'
import config from '../../../lib/config'
import Request from '../../mocks/request'
import Response from '../../mocks/response'
import {
  getDocumentCtrl,
  deleteDocumentCtrl,
  createFolderCtrl,
  getDocumentsFrmFolderCtrl,
  getFolderByNameCtrl
 } from '../../../controllers/documents/documents'

import documentsList from './mocks/documents'
import docFromRoot from './mocks/folders'
import docFromFolder from './mocks/folderId'
import parentFolder from './mocks/parentFolder'
import folderByName from './mocks/folderByName'

const GET_DOCUMENT_RESPONSE = {
  'systemAttributes': {
    'id': '08cfa5d0-421a-4ec3-aae4-ab831edbfb90',
    'parentId': 'e8480a83-3b1a-4d02-b074-befe45961603',
    'version': '',
    'userCreateDate': '2016-02-25T16:34:18.212+0000',
    'createDate': '2016-02-25T16:34:18.234+0000',
    'modifyDate': '2016-02-25T16:44:47.154+0000',
    'owner': {
      'namespaceId': '',
      'authId': '123145816013222'
    },
    'assetId': '721719432476880372',
    'lastUpdatingAssetId': '939018114495168361',
    'originatingAssetId': '7278960489929281245',
    'offeringId': 'Intuit.tax.browserwidgets.browserwidgets',
    'selfLocator': '/documents/08cfa5d0-421a-4ec3-aae4-ab831edbfb90',
    'channel': 'import',
    'alternateDataLocators': [
      {
        'contentType': 'ofxData',
        'alternateDataType': 'ofxData',
        'locator': '/documents/08cfa5d0-421a-4ec3-aae4-ab831edbfb90/alternateData?type=ofxData'
      },
      {
        'contentType': 'rawSemanticData',
        'alternateDataType': 'rawSemanticData',
        'locator': '/documents/08cfa5d0-421a-4ec3-aae4-ab831edbfb90/alternateData?type=rawSemanticData'
      }
    ]
  },
  'commonAttributes': {
    'name': '1099-DIV_Testprovider012',
    'documentType': '1099-DIV',
    'is7216': true,
    'providerName': 'PAYER NAME 1',
  }
}
const CREATE_RESPONSE = {
  "name": "FDXTEST",
  "id": "7ddb3f5e-2b4c-46b4-beaa-58024f8658cd"
}

describe('Documents Route', function () {

  describe('Deleting a document was successful', function () {

    nock('https://' + config.services.documents.root)
      .delete('/documents/54374f7f-821c-4303-8d34-123456789098')
      .reply(204, '')

    let options = {
      method: 'DELETE',
      params: {
        documentId: '54374f7f-821c-4303-8d34-123456789098'
      }
    }

    let mockResponse = new Response()
    let mockRequest = new Request( options )

    deleteDocumentCtrl( mockRequest, mockResponse )

    it( 'should respond with 204', function ( done ) {
      expect( mockResponse.statusCode ).to.equal( 204 )
      done()
    } )
  })

  describe('Deleting a document, but it failed', function () {

    nock('https://' + config.services.documents.root)
      .delete('/documents/54374f7f-821c-4303-8d34-123456789098')
      .replyWithError({
        'code': 'PRECONDITION_REQUIRED',
        'type': 'CLIENT',
        'message': 'Pre Condition Required. header [ifUnmodifiedSince] is missing .'
      })

    let options = {
      method: 'DELETE',
      params: {
        documentId: '54374f7f-821c-4303-8d34-123456789098'
      }
    }

    let mockResponse = new Response()
    let mockRequest = new Request( options )

    deleteDocumentCtrl( mockRequest, mockResponse )

    it( 'should respond with 500', function ( done ) {
      expect( mockResponse.statusCode ).to.equal( 500 )
      done()
    } )

    it('should be in a standard error format', function (done) {
      expect(mockResponse.response).to.have.all.keys('code', 'type', 'category', 'message', 'detail', 'moreInfo', 'intuit_tid', 'statusCode')
      expect( mockResponse.response.code ).to.equal( 'FDPVLT-6000' )
      done()
    })
  })

  describe('Detting the deatil for a document', function () {

    nock('https://' + config.services.documents.root)
      .get('/documents/54374f7f-821c-4303-8d34-123456789098?includeSource=false')
      .reply(200, GET_DOCUMENT_RESPONSE)


    let options = {
      params: {
        documentId: '54374f7f-821c-4303-8d34-123456789098'
      }
    }

    let mockResponse = new Response()
    let mockRequest = new Request( options )

    getDocumentCtrl( mockRequest, mockResponse )

    it( 'should respond with 200', function ( done ) {
      expect( mockResponse.statusCode ).to.equal( 200 )
      done()
    } )

    it('should equal the exact response from document service', function (done) {
      expect(mockResponse.response).to.deep.equal(GET_DOCUMENT_RESPONSE)
      done()
    })
  })

  describe('Getting a list of documents with data', function () {

    nock('https://' + config.services.documents.root)
      .get('/documents')
      .reply(200, documentsList)

    let mockResponse = new Response()
    let mockRequest = new Request( )

    getDocumentCtrl( mockRequest, mockResponse )

    it( 'should respond with 200', function ( done ) {
      expect( mockResponse.statusCode ).to.equal( 200 )
      done()
    } )

    it('should return 4 documents', function (done) {
      expect(mockResponse.response.totalDocuments).to.equal( 4 )
      expect(mockResponse.response.documents).to.have.length( 4 )
      done()
    })

    it('should equal the exact response from document service', function (done) {
      expect(mockResponse.response).to.deep.equal(documentsList)
      done()
    })
  })

  describe('Create folder', function () {

    nock('https://' + config.services.documents.root)
      .post('/folders', {
        "name":"FDXTEST",
        "description":"FDXTEST",
        "parentId":"root"
      })
      .reply(201, '', {
        'location': 'https://financialdocument-e2e.platform.intuit.com/v2/folders/7ddb3f5e-2b4c-46b4-beaa-58024f8658cd'
      })

      let options = {
        params: {
          name: 'FDXTEST'
        }
      }

    let mockResponse = new Response()
    let mockRequest = new Request( options )

    createFolderCtrl( mockRequest, mockResponse )

    it( 'should respond with 201', function ( done ) {
      expect( mockResponse.statusCode ).to.equal( 201 )
      done()
    } )

    it('should return name and id', function (done) {
      expect(mockResponse.response).to.have.all.keys('name', 'id')
      done()
    })

    it('should equal the exact response from document service', function (done) {
      expect(mockResponse.response).to.deep.equal(CREATE_RESPONSE)
      done()
    })
  })

  describe('Getting documents from folder without folderId', function () {

    nock('https://' + config.services.documents.root)
      .get('/folders/?ownership=owned')
      .reply(200, docFromRoot)

    let mockResponse = new Response()
    let mockRequest = new Request( )

    getDocumentsFrmFolderCtrl( mockRequest, mockResponse )

    it( 'should respond with 200', function ( done ) {
      expect( mockResponse.statusCode ).to.equal( 200 )
      done()
    } )

    it( 'should be in root', function ( done ) {
      expect( mockResponse.response.name ).to.equal( 'root' )
      done()
    } )

    it('should return 1 document and 3 folder', function (done) {
      expect(mockResponse.response.folders).to.have.length( 3)
      expect(mockResponse.response.documents).to.have.length( 1)
      done()
    })

    it('should equal the exact response from document service', function (done) {
      expect(mockResponse.response).to.deep.equal(docFromRoot)
      done()
    })
  })

  describe('Getting documents from folder with folderId', function () {

    nock('https://' + config.services.documents.root)
      .get('/folders/c9a3ecd3-19f2-48fc-b2f7-352c31c9573e?includeLocators=true')
      .reply(200, docFromFolder)

    let options = {
      method: 'GET',
      params: {
        id: 'c9a3ecd3-19f2-48fc-b2f7-352c31c9573e'
      }
    }

    let mockResponse = new Response()
    let mockRequest = new Request( options )

    getDocumentsFrmFolderCtrl( mockRequest, mockResponse )

    it( 'should respond with 200', function ( done ) {
      expect( mockResponse.statusCode ).to.equal( 200 )
      done()
    } )

    it( 'should be in fdxPlayground', function ( done ) {
      expect( mockResponse.response.name ).to.equal( 'fdxPlayground' )
      done()
    } )

    it('should return 2 document', function (done) {
      expect(mockResponse.response.documents).to.have.length( 2)
      done()
    })

    it('should equal the exact response from document service', function (done) {
      expect(mockResponse.response).to.deep.equal(docFromFolder)
      done()
    })
  })

  describe('Getting documents from folder with invalid folderId', function () {

    nock('https://' + config.services.documents.root)
      .get('/folders/c9a3ecd3-19f2-48fc-b2f7-352c31c9573f?includeLocators=true')
      .reply(404, {
        "code": "RECORD_NOT_FOUND",
        "type": "CLIENT",
        "message": "Folder [c9a3ecd3-19f2-48fc-b2f7-352c31c9573f] not found."
      })

    let options = {
      method: 'GET',
      params: {
        id: 'c9a3ecd3-19f2-48fc-b2f7-352c31c9573f'
      }
    }

    let mockResponse = new Response()
    let mockRequest = new Request( options )

    getDocumentsFrmFolderCtrl( mockRequest, mockResponse )

    it( 'should respond with 404', function ( done ) {
      expect( mockResponse.statusCode ).to.equal( 404 )
      done()
    } )

    it('should be in a standard error format', function (done) {
      expect(mockResponse.response).to.have.all.keys('code', 'type', 'category', 'message', 'detail', 'moreInfo', 'intuit_tid', 'statusCode')
      expect( mockResponse.response.code ).to.equal( 'FDPVLT-6000' )
      done()
    })
  })

  describe('Getting folder by folder name without parentId', function () {

    nock('https://' + config.services.documents.root)
      .get('/folders/?ownership=owned')
      .reply(200, docFromRoot)

    let options = {
      method: 'GET',
      params: {
        name: 'fdxPlayground'
      }
    }

    let mockResponse = new Response()
    let mockRequest = new Request( options )

    getFolderByNameCtrl( mockRequest, mockResponse )

    it( 'should respond with 200', function ( done ) {
      expect( mockResponse.statusCode ).to.equal( 200 )
      done()
    } )

    it('should have name and id', function (done) {
      expect(mockResponse.response).to.have.all.keys('id', 'name')
      expect(mockResponse.response).to.deep.equal(folderByName)
      done()
    })
  })

  describe('Getting folder by folder name without parentId but invalid name', function () {

    nock('https://' + config.services.documents.root)
      .get('/folders/?ownership=owned')
      .reply(200, docFromRoot)

    let options = {
      method: 'GET',
      params: {
        name: 'fdxPlaygroun'
      }
    }

    let mockResponse = new Response()
    let mockRequest = new Request( options )

    getFolderByNameCtrl( mockRequest, mockResponse )

    it( 'should respond with 404', function ( done ) {
      expect( mockResponse.statusCode ).to.equal( 404 )
      done()
    } )

    it('should return Folder not found', function (done) {
      expect(mockResponse.response).to.deep.equal('Folder not found')
      done()
    })
  })

  describe('Getting folder by folder name with parentId', function () {

    nock('https://' + config.services.documents.root)
      .get('/folders/2a91f730-de17-488b-92a0-58ec6f4effdc?includeLocators=true')
      .reply(200, parentFolder)

    let options = {
      method: 'GET',
      params: {
        name: 'fdxPlayground',
        parentId: '2a91f730-de17-488b-92a0-58ec6f4effdc'
      }
    }

    let mockResponse = new Response()
    let mockRequest = new Request( options )

    getFolderByNameCtrl( mockRequest, mockResponse )

    it( 'should respond with 200', function ( done ) {
      expect( mockResponse.statusCode ).to.equal( 200 )
      done()
    } )

    it('should have name and id', function (done) {
      expect(mockResponse.response).to.have.all.keys('id', 'name')
      expect(mockResponse.response).to.deep.equal(folderByName)
      done()
    })
  })

  describe('Getting folder by invalid folder name with parentId', function () {

    nock('https://' + config.services.documents.root)
      .get('/folders/2a91f730-de17-488b-92a0-58ec6f4effdc?includeLocators=true')
      .reply(200, parentFolder)

    let options = {
      method: 'GET',
      params: {
        name: 'fdxPlaygroun',
        parentId: '2a91f730-de17-488b-92a0-58ec6f4effdc'
      }
    }

    let mockResponse = new Response()
    let mockRequest = new Request( options )

    getFolderByNameCtrl( mockRequest, mockResponse )

    it( 'should respond with 404', function ( done ) {
      expect( mockResponse.statusCode ).to.equal( 404 )
      done()
    } )

    it('should return Folder not found', function (done) {
      expect(mockResponse.response).to.deep.equal('Folder not found')
      done()
    })
  })

  describe('Getting folder by folder name with invalid parentId', function () {

    nock('https://' + config.services.documents.root)
      .get('/folders/c9a3ecd3-19f2-48fc-b2f7-352c31c9573f?includeLocators=true')
      .reply(404, {
        "code": "RECORD_NOT_FOUND",
        "type": "CLIENT",
        "message": "Folder [c9a3ecd3-19f2-48fc-b2f7-352c31c9573f] not found."
      })

    let options = {
      method: 'GET',
      params: {
        name: 'fdxPlayground',
        parentId: 'c9a3ecd3-19f2-48fc-b2f7-352c31c9573f'
      }
    }

    let mockResponse = new Response()
    let mockRequest = new Request( options )

    getFolderByNameCtrl( mockRequest, mockResponse )

    it( 'should respond with 404', function ( done ) {
      expect( mockResponse.statusCode ).to.equal( 404 )
      done()
    } )

    it('should be in a standard error format', function (done) {
      expect(mockResponse.response).to.have.all.keys('code', 'type', 'category', 'message', 'detail', 'moreInfo', 'intuit_tid', 'statusCode')
      expect( mockResponse.response.code ).to.equal( 'FDPVLT-6000' )
      done()
    })
  })

})
