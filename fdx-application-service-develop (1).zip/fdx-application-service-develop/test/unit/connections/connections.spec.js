import { expect } from 'chai'
import nock from 'nock'
import config from '../../../lib/config'
// import cache from '../../../../lib/cache'
import Request from '../../mocks/request'
import Response from '../../mocks/response'
import { getConnectionsCtrl, getConnectionDetailCtrl, saveConnectionCtrl, removeConnectionCtrl } from '../../../controllers/connections/connections'

//Mocks
// Responses
let successProfileResponse = require( './mocks/profile-success' )
let successCredentialsResponse = require( './mocks/credentials-success' )
let successCredentialResponse = require( './mocks/credentials-by-id-success' )

/*

Scenarios
	1. happy path
	2. first time user (no saved credentials)
	3. merging credentials (profile and credentials are out of sync)
	4. a provider has no saved credentials
	5. profile service fails
	6. credential service fails
	7. both credentials and profile fails

*/


describe( 'Connections Controller', function () {

  describe( 'Getting a list of connections for a user', function () {

    nock( 'https://' + config.services.profile.root )
      .get( '/profiles' )
      .reply( 200, successProfileResponse )

    nock( 'https://' + config.services.credentials.root )
      .get( '/providers' )
      .reply( 200, successCredentialsResponse )

    nock( 'https://' + config.services.credentials.root )
      .get( '/credentials/c7bedf2e-184a-4bdd-93aa-51b4f7563d9b' )
      .reply( 200, successCredentialResponse[ 'c7bedf2e-184a-4bdd-93aa-51b4f7563d9b' ].body )

    nock( 'https://' + config.services.credentials.root )
      .get( '/credentials/3373e103-9851-4c52-9cdb-d126d4d47853' )
      .reply( 200, successCredentialResponse[ '3373e103-9851-4c52-9cdb-d126d4d47853' ].body )

    nock( 'https://' + config.services.credentials.root )
      .get( '/credentials/7ebf1b36-ef15-4635-9c58-4cd566f32081' )
      .reply( 200, successCredentialResponse[ '7ebf1b36-ef15-4635-9c58-4cd566f32081' ].body )

    nock( 'https://' + config.services.credentials.root )
      .get( '/credentials/515b833c-dea1-40f0-a9f9-0d204283218f' )
      .reply( 200, successCredentialResponse[ '515b833c-dea1-40f0-a9f9-0d204283218f' ].body )

    nock( 'https://' + config.services.credentials.root )
      .get( '/credentials/515b833c-dea1-40f0-a9f9-error1234567' )
      .reply( 500, {
        'errors': {
          'error': [ {
            'code': 'not.found',
            'type': 'CLIENT',
            'message': 'The requested resource could not be found.',
            'detail': 'exceptionMessage="Unable to get Entity, Key:80b2513c-1619-419b-b1e1-c110e2fe9ff_masked DAP Error:NOT_FOUND Details:Caused by Not Found ", code="DAP-1006", type="SYSTEM", message="NOT_FOUND", detail="Caused by Not Found ", moreInfo="NOT_FOUND"'
          } ],
          'errorType': 'general',
          'intuit_tid': 'TEST-LOGGING-12345'
        }
      } )

    // 'providerId': '4f5035d9-c31f-41da-b5bc-6da281b446ca',
    //   'credentialSetId': 'c7bedf2e-184a-4bdd-93aa-51b4f7563d9b',

    // 'providerId': '4f5035d9-c31f-41da-b5bc-6da281b446ca',
    // 		'credentialSetId': '3373e103-9851-4c52-9cdb-d126d4d47853'
    //
    // 'providerId': 'a00074d7-df15-49e1-8ade-f32a6ddfc8aa',
    //   'credentialSets': []
    //
    // 'providerId': '702b1ee5-caec-4ffa-ada5-1ad2ca006766',
    //   'credentialSetId': '7ebf1b36-ef15-4635-9c58-4cd566f32081'
    //
    // 'providerId': 'afe0b32e-94e1-4176-8c09-66188a932e99',
    //   'credentialSetId': '515b833c-dea1-40f0-a9f9-0d204283218f'

    let mockResponse = new Response()
    let mockRequest = new Request()

    getConnectionsCtrl( mockRequest, mockResponse )

    it( 'should respond with a response object', function ( done ) {
      expect( mockResponse.response ).to.be.defined
      done()
    } )

    it( 'should respond with 200', function ( done ) {
      expect( mockResponse.statusCode ).to.equal( 200 )
      done()
    } )

    it( 'should have a providers array length of 5', function ( done ) {
      expect( mockResponse.response.providers ).to.be.an( 'array' )
      expect( mockResponse.response.providers ).to.have.length( 5 )
      done()
    } )

    it( 'should have provider array and each object with has credentialSets', function ( done ) {
      mockResponse.response.providers.forEach( function ( provider ) {
        expect( provider ).to.have.property( 'credentialSets' )
        expect( provider.credentialSets ).to.be.an( 'array' )
      } )
      done()
    } )

    it( 'should have provider array and each object with has a providerId', function ( done ) {
      mockResponse.response.providers.forEach( function ( provider ) {
        expect( provider ).to.have.property( 'providerId' )
        expect( provider.providerId ).to.be.a( 'string' )
      } )
      done()
    } )

    it( 'should have provider array and a00074d7-df15-49e1-8ade-f32a6ddfc8aa should have credentialSets lenght 0 ( keeping track of providers without credentials )', function ( done ) {
      mockResponse.response.providers.forEach( function ( provider ) {
        if ( provider.providerId === 'a00074d7-df15-49e1-8ade-f32a6ddfc8aa' ) {
          expect( provider.credentialSets ).to.have.length( 0 )
        }
      } )
      done()
    } )


    it( 'should have provider array and 702b1ee5-caec-4ffa-ada5-1ad2ca006766 should have credentialSets lenght 1 ( dedupe profile and credentialsSerivece )', function ( done ) {
      mockResponse.response.providers.forEach( function ( provider ) {
        if ( provider.providerId === '702b1ee5-caec-4ffa-ada5-1ad2ca006766' ) {
          expect( provider.credentialSets ).to.have.length( 1 )
        }
      } )
      done()
    } )

    it( 'should have provider array and 4f5035d9-c31f-41da-b5bc-6da281b446ca should have credentialSets lenght 2 ( merge profile and credentialsSerivece)', function ( done ) {
      mockResponse.response.providers.forEach( function ( provider ) {
        if ( provider.providerId === '4f5035d9-c31f-41da-b5bc-6da281b446ca' ) {
          expect( provider.credentialSets ).to.have.length( 2 )
        }
      } )
      done()
    } )

    it( 'should have provider array and 702b1ee5-caec-4ffa-ada5-error1234567 should have credentialSets with length 0 ( this provider has a credentialSet error )', function ( done ) {
      mockResponse.response.providers.forEach( function ( provider ) {
        if ( provider.providerId === '702b1ee5-caec-4ffa-ada5-error1234567' ) {
          expect( provider.credentialSets ).to.have.length( 0 )
        }
      } )
      done()
    } )

  } )

  describe( 'Get an list of connections for a user with saved credentials and no profile', function () {

    nock( 'https://' + config.services.profile.root )
      .get( '/profiles' )
      .reply( 404, {
        'code': 'USER_NOT_FOUND',
        'type': 'CLIENT',
        'message': 'User Profile not present for userId=[urn:profile:ius::userid:123145803490877].'
      } )

    nock( 'https://' + config.services.credentials.root )
      .get( '/providers' )
      .reply( 200, {
        'userId': '193514366910437',
        'providers': [ {
          'providerId': '4f5035d9-c31f-41da-b5bc-6da281b446ca',
          'credentialSets': [ {
            'credentialSetId': '3373e103-9851-4c52-9cdb-d126d4d47853'
          } ]
        } ]
      } )

    nock( 'https://' + config.services.credentials.root )
      .get( '/credentials/3373e103-9851-4c52-9cdb-d126d4d47853' )
      .reply( 200, successCredentialResponse[ '3373e103-9851-4c52-9cdb-d126d4d47853' ].body )

    let mockResponse = new Response()
    let mockRequest = new Request()

    getConnectionsCtrl( mockRequest, mockResponse )

    it( 'should respond', function ( done ) {
      expect( mockResponse.response ).to.be.defined
      done()
    } )
    it( 'should have a providers array', function ( done ) {
      expect( mockResponse.response.providers ).to.be.an( 'array' )
      done()
    } )
    it( 'should have a length of 1', function ( done ) {
      expect( mockResponse.response.providers ).to.have.length( 1 )
      done()
    } )
  } )

  describe( 'Get an list of connections for a with out a saved profile or credentials (probably first time)', function () {

    nock( 'https://' + config.services.profile.root )
      .get( '/profiles' )
      .reply( 200, {
        'code': 'USER_NOT_FOUND',
        'type': 'CLIENT',
        'message': 'User Profile not present for userId=[urn:profile:ius::userid:123145803490877].'
      } )

    nock( 'https://' + config.services.credentials.root )
      .get( '/providers' )
      .reply( 200, {
        'userId': '123145803490877',
        'providers': []
      } )

    let mockResponse = new Response()
    let mockRequest = new Request()

    getConnectionsCtrl( mockRequest, mockResponse )

    it( 'should respond', function ( done ) {
      expect( mockResponse.response ).to.be.defined
      done()
    } )
    it( 'should have an empty providers array', function ( done ) {
      expect( mockResponse.response.providers ).to.have.length( 0 )
      done()
    } )

  } )

  describe( 'Profile Service Success, Credentials Service Error', function () {

    nock( 'https://' + config.services.profile.root )
      .get( '/profiles' )
      .reply( 200, successProfileResponse )

    nock( 'https://' + config.services.credentials.root )
      .get( '/providers' )
      .reply( 500, {
        errors: [ {
          error: {
            code: 123,
            message: 'error message'
          }
        } ]
      } )

    nock( 'https://' + config.services.credentials.root )
      .get( '/credentials/c7bedf2e-184a-4bdd-93aa-51b4f7563d9b' )
      .reply( 200, successCredentialResponse[ 'c7bedf2e-184a-4bdd-93aa-51b4f7563d9b' ].body )

    nock( 'https://' + config.services.credentials.root )
      .get( '/credentials/7ebf1b36-ef15-4635-9c58-4cd566f32081' )
      .reply( 200, successCredentialResponse[ '7ebf1b36-ef15-4635-9c58-4cd566f32081' ].body )

    nock( 'https://' + config.services.credentials.root )
      .get( '/credentials/515b833c-dea1-40f0-a9f9-error1234567' )
      .reply( 500, {
        'errors': {
          'error': [ {
            'code': 'not.found',
            'type': 'CLIENT',
            'message': 'The requested resource could not be found.',
            'detail': 'exceptionMessage="Unable to get Entity, Key:80b2513c-1619-419b-b1e1-c110e2fe9ff_masked DAP Error:NOT_FOUND Details:Caused by Not Found ", code="DAP-1006", type="SYSTEM", message="NOT_FOUND", detail="Caused by Not Found ", moreInfo="NOT_FOUND"'
          } ],
          'errorType': 'general',
          'intuit_tid': 'TEST-LOGGING-12345'
        }
      } )

    let mockResponse = new Response()
    let mockRequest = new Request()

    getConnectionsCtrl( mockRequest, mockResponse )

    // 'providerId': '4f5035d9-c31f-41da-b5bc-6da281b446ca',
    //   'credentialSetId': 'c7bedf2e-184a-4bdd-93aa-51b4f7563d9b',

    // 'providerId': '702b1ee5-caec-4ffa-ada5-1ad2ca006766',
    // 		'credentialSetId': '7ebf1b36-ef15-4635-9c58-4cd566f32081',


    it( 'should respond', function ( done ) {
      expect( mockResponse.response ).to.be.defined
      done()
    } )

    it( 'should respond with providers array length of 3 ( only profile providers )', function ( done ) {
      expect( mockResponse.response.providers ).to.have.length( 3 )
      done()
    } )

  } )

  describe( 'Profile Service Error, Credentials Service Error ( Request Level ) ', function () {

    nock( 'https://' + config.services.profile.root )
      .get( '/profiles' )
      .replyWithError( {
        errors: [ {
          error: {
            code: 123,
            message: 'error message'
          }
        } ]
      } )

    nock( 'https://' + config.services.credentials.root )
      .get( '/providers' )
      .replyWithError( {
        errors: [ {
          error: {
            code: 123,
            message: 'error message'
          }
        } ]
      } )

    let mockResponse = new Response()
    let mockRequest = new Request()

    getConnectionsCtrl( mockRequest, mockResponse )

    it( 'should respond', function ( done ) {
      expect( mockResponse.response ).to.be.defined
      done()
    } )

    it( 'should respond with an error', function ( done ) {
      expect( mockResponse.response.error ).to.be.defined
      done()
    } )

  } )

  describe( 'Profile Service Error, Credentials Service Error ( service level )', function () {

    nock( 'https://' + config.services.profile.root )
      .get( '/profiles' )
      .reply( 401, {
        errors: [ {
          error: {
            code: 123,
            message: 'error message'
          }
        } ]
      } )

    nock( 'https://' + config.services.credentials.root )
      .get( '/providers' )
      .reply( 401, {
        errors: [ {
          error: {
            code: 123,
            message: 'error message'
          }
        } ]
      } )

    let mockResponse = new Response()
    let mockRequest = new Request()

    getConnectionsCtrl( mockRequest, mockResponse )

    it( 'should respond', function ( done ) {
      expect( mockResponse.response ).to.be.defined
      done()
    } )

    it( 'should respond with an error', function ( done ) {
      expect( mockResponse.response.error ).to.be.defined
      done()
    } )

  } )

  describe( 'Getting a list of connections for a user and Credential Service doesn\'t handle async call to get details', function () {

    nock( 'https://' + config.services.profile.root )
      .get( '/profiles' )
      .reply( 200, {
        'fdpProfileId': 'urn:profile:ius::userid:123145722548752',
        'providerPreferences': [
          {
            'providerId': 'fd0d1453-cfa1-407e-9cd1-6531303a448f',
            'credentialPreferences': [
              {
                'credentialSetId': '12345-test-credential-set-id-12345',
                'folderId': '75e3ccb8-3b28-46c7-bd83-76f271c770ed',
                'documentBatchEligible': true,
                'offeringPreferences': [
                  {
                    'offeringId': 'Intuit.tax.shoebox.browser',
                    'notificationAttributes': [
                      {
                        'key': 'firmRealmId',
                        'value': '123145722490732'
                      },
                      {
                        'key': 'acsClientId',
                        'value': '4df888c6-77b1-49e9-985e-afdebc6e235d'
                      },
                      {
                        'key': 'taxYear',
                        'value': '2015'
                      }
                    ]
                  }
                ]
              }
            ]
          }
        ],
        'documentBatchEligible': false,
        'createdDate': '2016-02-12T21:03:19.564+0000',
        'lastModifiedDate': '2016-03-10T09:57:11.281+0000'
      } )

    nock( 'https://' + config.services.credentials.root )
      .get( '/providers' )
      .reply( 200, {
        'userId': '123145722548752',
        'providers': [ {
          'providerId': 'fd0d1453-cfa1-407e-9cd1-6531303a448f',
          'credentialSets': [ {
            'credentialSetId': '12345-test-credential-set-id-12345'
          } ]
        } ]
      } )

    nock( 'https://' + config.services.credentials.root )
      .get( '/credentials/12345-test-credential-set-id-12345' )
      .reply( 500, undefined )


    let mockResponse = new Response()
    let mockRequest = new Request()

    getConnectionsCtrl( mockRequest, mockResponse )

    it( 'should respond with 200', function ( done ) {
      expect( mockResponse.statusCode ).to.equal( 200 )
      done()
    } )

    it( 'should have a list of providers: length 1', function ( done ) {
      expect( mockResponse.response.providers ).to.have.length( 1 )
      done()
    } )

    it( 'should have a providerId and empty credentials array', function ( done ) {
      expect( mockResponse.response.providers[0] ).to.have.all.keys( 'providerId', 'credentialSets' )
      expect( mockResponse.response.providers[0].credentialSets ).to.have.length( 0 )
      done()
    } )

  } )

  describe( 'Getting detail for a connections credentialsetId', function () {

    let mockData = {
      'authId': '193514366910437',
      'providerId': '4f5035d9-c31f-41da-b5bc-6da281b446ca',
      'credentialSetId': '3373e103-9851-4c52-9cdb-d126d4d47853',
      // 'status': 'verified',
      'statusDetail' : {
        'code' : '0',
        'message' : 'User is authenticated.',
        'providerMessage' : ''
      },
      'credentials': [
        {
          'type': 'nonSecret',
          'certVersion': 'v01_credential_service_cryption_nonprod_key.corp.intuit.net',
          'authenticationFieldId': 'ebd94c8e-7ae4-4573-9e79-cf0e48aba7c0',
          'authenticationFieldValue': '1099Variousv2',
          'mappingSourceText': 'USERID',
          'mappingSourceValue': '1099Variousv2',
          'masked': '*************'
        },
        {
          'type': 'secret',
          'certVersion': 'v01_credential_service_cryption_nonprod_key.corp.intuit.net',
          'authenticationFieldId': '58e357ef-0bd9-4136-81d4-e2884ea9e093',
          'authenticationFieldValue': '*************',
          'mappingSourceText': 'PASSWORD',
          'mappingSourceValue': '*************',
          'masked': '*************'
        }
      ]
    }

    nock('https://' + config.services.credentials.root)
      .get('/credentials/3373e103-9851-4c52-9cdb-d126d4d47853')
      .reply(200, mockData )

    let options = {
      params: {
        credentialSetId: '3373e103-9851-4c52-9cdb-d126d4d47853'
      }
    }
    let mockResponse = new Response()
    let mockRequest = new Request( options )

    getConnectionDetailCtrl( mockRequest, mockResponse )


    it('should respond with 200', function (done) {
      expect(mockResponse.statusCode).to.equal(200)
      done()
    })

    it('should respond with a list credentials', function (done) {
      expect(mockResponse.response).to.be.defined
      expect(mockResponse.response.credentials).to.have.length(2)
      done()
    })

    it('should set status to "verified" if statusDetail.code === 0 ', function (done) {
      expect(mockResponse.response).to.be.defined
      expect(mockResponse.response.status).to.equal('verified')
      done()
    })


  } )

  describe( 'Delete an entire connections for a user', function () {

    nock( 'https://' + config.services.profile.root )
      .delete( '/profiles/2265507445/providers/4f5035d9-c31f-41da-b5bc-6da281b446c9' )
      .reply( 200, '' )

    nock( 'https://' + config.services.credentials.root_v2 )
      .delete( '/users/2265507445/providers/4f5035d9-c31f-41da-b5bc-6da281b446c9' )
      .reply( 204, '' )

    let options = {
      method: 'DELETE',
      params: {
        providerId: '4f5035d9-c31f-41da-b5bc-6da281b446c9'
      }
    }

    let mockResponse = new Response()
    let mockRequest = new Request( options )

    removeConnectionCtrl( mockRequest, mockResponse )

    it( 'should respond with 204', function ( done ) {
      expect( mockResponse.statusCode ).to.equal( 204 )
      done()
    } )

    it( 'should respond', function ( done ) {
      expect( mockResponse.response ).to.be.defined
      done()
    } )
  } )

  describe( 'Delete a credentialSet form a connection', function () {

    nock( 'https://' + config.services.profile.root )
      .delete( '/profiles/2265507445/providers/4f5035d9-c31f-41da-b5bc-6da281b446c9/credentials/c7bedf2e-184a-4bdd-93aa-51b4f7563d9b' )
      .reply( 200, '' )

    nock( 'https://' + config.services.credentials.root_v2 )
      .delete( '/users/2265507445/credentials/c7bedf2e-184a-4bdd-93aa-51b4f7563d9b' )
      .reply( 204, '' )

    let options = {
      method: 'DELETE',
      params: {
        providerId: '4f5035d9-c31f-41da-b5bc-6da281b446c9',
        credentialSetId: 'c7bedf2e-184a-4bdd-93aa-51b4f7563d9b'
      }
    }

    let mockResponse = new Response()
    let mockRequest = new Request( options )

    removeConnectionCtrl( mockRequest, mockResponse )

    it( 'should respond with 204', function ( done ) {
      expect( mockResponse.statusCode ).to.equal( 204 )
      done()
    } )

    it( 'should respond', function ( done ) {
      expect( mockResponse.response ).to.be.defined
      done()
    } )
  } )

  describe( 'Delete a credentialSet form a connection and Credentials Fails to delete', function () {

    nock( 'https://' + config.services.profile.root )
      .delete( '/profiles/2265507445/providers/4f5035d9-c31f-41da-b5bc-6da281b446c9/credentials/c7bedf2e-184a-4bdd-93aa-51b4f7563d9b' )
      .reply( 200, '' )

    nock( 'https://' + config.services.credentials.root_v2 )
      .delete( '/users/2265507445/credentials/c7bedf2e-184a-4bdd-93aa-51b4f7563d9b' )
      .reply( 500, '' )

    let options = {
      method: 'DELETE',
      params: {
        providerId: '4f5035d9-c31f-41da-b5bc-6da281b446c9',
        credentialSetId: 'c7bedf2e-184a-4bdd-93aa-51b4f7563d9b'
      }
    }

    let mockResponse = new Response()
    let mockRequest = new Request( options )

    removeConnectionCtrl( mockRequest, mockResponse )

    it( 'should respond with 500', function ( done ) {
      expect( mockResponse.statusCode ).to.equal( 500 )
      done()
    } )

    it( 'should respond with vault error code: FDPVLT-1001', function ( done ) {
      expect( mockResponse.response.code ).to.equal( 'FDPVLT-1001' )
      done()
    } )

    it( 'should respond with a tid', function ( done ) {
      expect( mockResponse.response.intuit_tid ).to.equal( 'TEST-SERVICE-REQUEST' )
      done()
    } )
  } )

  describe( 'Delete a credentialSet for a connection and Credential Service doesn\'t have a saved credentialSetId', function () {

    nock( 'https://' + config.services.profile.root )
      .delete( '/profiles/2265507445/providers/4f5035d9-c31f-41da-b5bc-6da281b446c9/credentials/c7bedf2e-184a-4bdd-93aa-51b4f7563d9b' )
      .reply( 200, '' )

    nock( 'https://' + config.services.credentials.root_v2 )
      .delete( '/users/2265507445/credentials/c7bedf2e-184a-4bdd-93aa-51b4f7563d9b' )
      .reply( 404, '' )

    let options = {
      method: 'DELETE',
      params: {
        providerId: '4f5035d9-c31f-41da-b5bc-6da281b446c9',
        credentialSetId: 'c7bedf2e-184a-4bdd-93aa-51b4f7563d9b'
      }
    }

    let mockResponse = new Response()
    let mockRequest = new Request( options )

    removeConnectionCtrl( mockRequest, mockResponse )

    it( 'should respond with 204', function ( done ) {
      expect( mockResponse.statusCode ).to.equal( 204 )
      done()
    } )

    it( 'should respond', function ( done ) {
      expect( mockResponse.response ).to.be.defined
      done()
    } )
  } )


  describe( 'Updating a credentialSet', function () {

    nock( 'https://' + config.services.profile.root )
      .put( '/profiles' )
      .reply( 204, '' )

    nock( 'https://' + config.services.credentials.root )
      .put( '/credentials/c7bedf2e-184a-4bdd-93aa-51b4f7563d9b' )
      .reply( 204, '' )

    let options = {
      method: 'PUT',
      body: {
        isTransientProvider: false,
        providerId: '4f5035d9-c31f-41da-b5bc-6da281b446c9',
        folderId: '77c50297-0abb-4f47-9cbc-d62db4055285',
        credentialSetId: 'c7bedf2e-184a-4bdd-93aa-51b4f7563d9b',
        credentialSets: [
          {
            'type': 'nonSecret',
            'certVersion': 'v01_credential_service_cryption_nonprod_key.corp.intuit.net',
            'authenticationFieldId': 'ebd94c8e-7ae4-4573-9e79-cf0e48aba7c0',
            'authenticationFieldValue': '1099Variousv2',
            'mappingSourceText': 'USERID',
            'mappingSourceValue': '1099Variousv2',
            'masked': '*************'
          },
          {
            'type': 'secret',
            'certVersion': 'v01_credential_service_cryption_nonprod_key.corp.intuit.net',
            'authenticationFieldId': '58e357ef-0bd9-4136-81d4-e2884ea9e093',
            'authenticationFieldValue': '*************',
            'mappingSourceText': 'PASSWORD',
            'mappingSourceValue': '*************',
            'masked': '*************'
          }
        ],
        offeringPreferences : {},
        statusDetail: { code: '0' },
        compliance : {
          '7216': { 'is7216':true }
        },
        status: 'verified'
      }
    }

    let mockResponse = new Response()
    let mockRequest = new Request( options )

    saveConnectionCtrl( mockRequest, mockResponse )

    it( 'should respond with 204', function ( done ) {
      expect( mockResponse.statusCode ).to.equal( 204 )
      done()
    } )

    it( 'should respond', function ( done ) {
      expect( mockResponse.response ).to.be.true
      done()
    } )
  } )

  describe( 'Creating a credentialSet for the first time', function () {

    nock( 'https://' + config.services.profile.root )
      .put( '/profiles' )
      .reply( 204, '' )

    nock( 'https://' + config.services.credentials.root )
      .post( '/credentials' )
      .reply( 201, {
        credentialSetId: '1234567890'
      } )

    let options = {
      method: 'PUT',
      body: {
        isTransientProvider: false,
        providerId: '4f5035d9-c31f-41da-b5bc-6da281b446c9',
        folderId: '77c50297-0abb-4f47-9cbc-d62db4055285',
        credentialSets: [
          {
            'type': 'nonSecret',
            'certVersion': 'v01_credential_service_cryption_nonprod_key.corp.intuit.net',
            'authenticationFieldId': 'ebd94c8e-7ae4-4573-9e79-cf0e48aba7c0',
            'authenticationFieldValue': '1099Variousv2',
            'mappingSourceText': 'USERID',
            'mappingSourceValue': '1099Variousv2',
            'masked': '*************'
          },
          {
            'type': 'secret',
            'certVersion': 'v01_credential_service_cryption_nonprod_key.corp.intuit.net',
            'authenticationFieldId': '58e357ef-0bd9-4136-81d4-e2884ea9e093',
            'authenticationFieldValue': '*************',
            'mappingSourceText': 'PASSWORD',
            'mappingSourceValue': '*************',
            'masked': '*************'
          }
        ],
        offeringPreferences : {},
        statusDetail: { code: '0' },
        compliance : {
          '7216': { 'is7216':true }
        },
        status: 'verified'
      }
    }

    let mockResponse = new Response()
    let mockRequest = new Request( options )

    saveConnectionCtrl( mockRequest, mockResponse )

    it( 'should respond with 201', function ( done ) {
      expect( mockResponse.statusCode ).to.equal( 201 )
      done()
    } )

    it( 'should respond', function ( done ) {
      expect( mockResponse.response.credentialSetId ).to.equal('1234567890')
      done()
    } )
  } )

  describe( 'Updating a credentialSet', function () {

    nock( 'https://' + config.services.profile.root )
      .put( '/profiles' )
      .reply( 201, '' )

    nock( 'https://' + config.services.credentials.root )
      .put( '/credentials/c7bedf2e-184a-4bdd-93aa-51b4f7563d9b' )
      .reply( 201, '' )

    let options = {
      method: 'PUT',
      body: {
        isTransientProvider: false,
        providerId: '4f5035d9-c31f-41da-b5bc-6da281b446c9',
        folderId: '77c50297-0abb-4f47-9cbc-d62db4055285',
        credentialSetId: 'c7bedf2e-184a-4bdd-93aa-51b4f7563d9b',
        credentialSets: [ {
          'type': 'nonSecret',
          'certVersion': 'v01_credential_service_cryption_nonprod_key.corp.intuit.net',
          'authenticationFieldId': 'ebd94c8e-7ae4-4573-9e79-cf0e48aba7c0',
          'authenticationFieldValue': '1099Variousv2',
          'mappingSourceText': 'USERID',
          'mappingSourceValue': '1099Variousv2',
          'masked': '*************'
        }, {
          'type': 'secret',
          'certVersion': 'v01_credential_service_cryption_nonprod_key.corp.intuit.net',
          'authenticationFieldId': '58e357ef-0bd9-4136-81d4-e2884ea9e093',
          'authenticationFieldValue': '*************',
          'mappingSourceText': 'PASSWORD',
          'mappingSourceValue': '*************',
          'masked': '*************'
        } ],
        offeringPreferences: {},
        statusDetail: {
          code: '0'
        },
        compliance: {
          '7216': {
            'is7216': true
          }
        },
        status: 'verified'
      }
    }

    let mockResponse = new Response()
    let mockRequest = new Request( options )

    saveConnectionCtrl( mockRequest, mockResponse )

    it( 'should respond with 204', function ( done ) {
      expect( mockResponse.statusCode ).to.equal( 204 )
      done()
    } )

    it( 'should respond', function ( done ) {
      expect( mockResponse.response ).to.be.defined
      done()
    } )

  } )

  describe( 'Creating credentials when a transient provider is selected', function () {

    nock( 'https://' + config.services.profile.root )
      .put( '/profiles' )
      .reply( 201, '' )

    let options = {
      method: 'PUT',
      body: {
        isTransientProvider: true,
        providerId: '4f5035d9-c31f-41da-b5bc-6da281b446c9',
        folderId: '77c50297-0abb-4f47-9cbc-d62db4055285',
        credentialSets: [ {
          'type': 'nonSecret',
          'certVersion': 'v01_credential_service_cryption_nonprod_key.corp.intuit.net',
          'authenticationFieldId': 'ebd94c8e-7ae4-4573-9e79-cf0e48aba7c0',
          'authenticationFieldValue': '1099Variousv2',
          'mappingSourceText': 'USERID',
          'mappingSourceValue': '1099Variousv2',
          'masked': '*************'
        }, {
          'type': 'secret',
          'certVersion': 'v01_credential_service_cryption_nonprod_key.corp.intuit.net',
          'authenticationFieldId': '58e357ef-0bd9-4136-81d4-e2884ea9e093',
          'authenticationFieldValue': '*************',
          'mappingSourceText': 'PASSWORD',
          'mappingSourceValue': '*************',
          'masked': '*************'
        } ],
        offeringPreferences: {},
        statusDetail: {
          code: '0'
        },
        compliance: {
          '7216': {
            'is7216': true
          }
        },
        status: 'verified'
      }
    }

    let mockResponse = new Response()
    let mockRequest = new Request( options )

    saveConnectionCtrl( mockRequest, mockResponse )

    it( 'should respond with 200', function ( done ) {
      expect( mockResponse.statusCode ).to.equal( 200 )
      done()
    } )

    it( 'should respond with message "we can not save credentials for this provider"', function ( done ) {
      expect( mockResponse.response.message ).to.equal( 'we can not save credentials for this provider' )
      done()
    } )

  } )


  describe( 'Creating a user and services fail', function () {

    describe( 'Profile Service fails', function () {

      nock( 'https://' + config.services.profile.root )
        .put( '/profiles' )
        .reply( 500, {
          'code': 'INTERNAL_ERROR',
          'type': 'SERVER',
          'message': 'All host(s) tried for query failed (no host was tried)'
        } )

      nock( 'https://' + config.services.credentials.root )
        .post( '/credentials' )
        .reply( 201,  {
          credentialSetId: '1234567890'
        }  )

      let options = {
        method: 'PUT',
        body: {
          isTransientProvider: false,
          providerId: '4f5035d9-c31f-41da-b5bc-6da281b446c9',
          folderId: '77c50297-0abb-4f47-9cbc-d62db4055285',
          credentialSets: [ {
            'type': 'nonSecret',
            'certVersion': 'v01_credential_service_cryption_nonprod_key.corp.intuit.net',
            'authenticationFieldId': 'ebd94c8e-7ae4-4573-9e79-cf0e48aba7c0',
            'authenticationFieldValue': '1099Variousv2',
            'mappingSourceText': 'USERID',
            'mappingSourceValue': '1099Variousv2',
            'masked': '*************'
          }, {
            'type': 'secret',
            'certVersion': 'v01_credential_service_cryption_nonprod_key.corp.intuit.net',
            'authenticationFieldId': '58e357ef-0bd9-4136-81d4-e2884ea9e093',
            'authenticationFieldValue': '*************',
            'mappingSourceText': 'PASSWORD',
            'mappingSourceValue': '*************',
            'masked': '*************'
          } ],
          offeringPreferences: {},
          statusDetail: {
            code: '0'
          },
          compliance: {
            '7216': {
              'is7216': true
            }
          },
          status: 'verified'
        }
      }

      let mockResponse = new Response()
      let mockRequest = new Request( options )

      saveConnectionCtrl( mockRequest, mockResponse )

      it( 'should respond with 201', function ( done ) {
        expect( mockResponse.statusCode ).to.equal( 201 )
        done()
      } )

      it( 'should respond', function ( done ) {
        expect( mockResponse.response.credentialSetId ).to.equal( '1234567890' )
        done()
      } )

    } )

    describe( 'Credential Service fails', function () {

      nock( 'https://' + config.services.profile.root )
        .put( '/profiles' )
        .reply( 500, {
          'code': 'INTERNAL_ERROR',
          'type': 'SERVER',
          'message': 'All host(s) tried for query failed (no host was tried)'
        } )

      nock( 'https://' + config.services.credentials.root )
        .post( '/credentials' )
        .reply( 404,   {
          'errors': {
            'error': [
              {
                'code': 'not.found',
                'type': 'CLIENT',
                'message': 'The requested resource could not be found.',
                'detail': ''
              }
            ],
            'errorType': 'general',
            'intuit_tid': 'TEST-LOGGING-12345'
          }
        }  )

      let options = {
        method: 'PUT',
        body: {
          isTransientProvider: false,
          providerId: '4f5035d9-c31f-41da-b5bc-6da281b446c9',
          folderId: '77c50297-0abb-4f47-9cbc-d62db4055285',
          credentialSets: [ {
            'type': 'nonSecret',
            'certVersion': 'v01_credential_service_cryption_nonprod_key.corp.intuit.net',
            'authenticationFieldId': 'ebd94c8e-7ae4-4573-9e79-cf0e48aba7c0',
            'authenticationFieldValue': '1099Variousv2',
            'mappingSourceText': 'USERID',
            'mappingSourceValue': '1099Variousv2',
            'masked': '*************'
          }, {
            'type': 'secret',
            'certVersion': 'v01_credential_service_cryption_nonprod_key.corp.intuit.net',
            'authenticationFieldId': '58e357ef-0bd9-4136-81d4-e2884ea9e093',
            'authenticationFieldValue': '*************',
            'mappingSourceText': 'PASSWORD',
            'mappingSourceValue': '*************',
            'masked': '*************'
          } ],
          offeringPreferences: {},
          statusDetail: {
            code: '0'
          },
          compliance: {
            '7216': {
              'is7216': true
            }
          },
          status: 'verified'
        }
      }

      let mockResponse = new Response()
      let mockRequest = new Request( options )

      saveConnectionCtrl( mockRequest, mockResponse )

      it( 'should respond with 404', function ( done ) {
        expect( mockResponse.statusCode ).to.equal( 404 )
        done()
      } )

      it( 'should respond', function ( done ) {
        expect( mockResponse.response.detail.code ).to.equal( 'not.found' )
        done()
      } )

    } )

  } )

} )
