import {
  expect
} from 'chai'
import nock from 'nock'
import config from '../../../lib/config'
import cache from '../../../lib/cache'
import Request from '../../mocks/request'
import Response from '../../mocks/response'
import {
  getProvidersByUserIdCtrl,
  listCtrl
} from '../../../controllers/connections/connections-v2'

const TEST_AUTH_ID = '2265507445'
const providersMock = require('./mocks/Providers.mock.json')
const providerDetailMock = require('./mocks/ProviderDetail.mock.json')
const avmMock = require('./mocks/avm-get.json')
const accountsListMock = require('./mocks/accounts-list.json')

describe( 'Connections-V2 Route', function () {

  describe( 'Getting all providers for a user', function () {

    before((done) => {
      cache.flushAll()
      done()
    })

    const mockResponse = new Response()
    const mockRequest = new Request()

    nock( 'https://' + config.services.credentials.root_v2 )
      .get( `/users/${TEST_AUTH_ID}/providers` )
      .reply( 200,  providersMock)

    nock( 'https://' + config.services.providers.root )
      .get(`/${config.services.providers.path.default}${providersMock.providers[0].providerId}`)
      .reply( 200, providerDetailMock )      

    getProvidersByUserIdCtrl( mockRequest, mockResponse )


    it( 'should respond with 200', function ( done ) {
      expect( mockResponse.statusCode ).to.equal( 200 )
      done()
    } )

    it( 'should respond with a list of 1', function ( done ) {
      expect( mockResponse.response ).to.be.defined
      expect( mockResponse.response.results ).to.have.length( 1 )
      done()
    } )

    it( 'should respond with a list of credentialSets', function ( done ) {
      expect( mockResponse.response.results[0].credentialSets ).to.be.defined
      done()
    } )    

    it( 'should respond with an object that has name', function ( done ) {
      expect( mockResponse.response.results[0].name ).to.be.defined
      done()
    } )   

    after((done) => {
      cache.flushAll()
      done()
    })

  } )

  describe( 'Getting all accounts for a provider', function () {

    const mockResponse = new Response()
    const mockRequest = new Request({
      params: { providerId: '90aec3e4-0d85-45fa-8a1b-b2ce655d6705' },
      query: { credentialSetIds: 'daa96f08-bfaf-47bc-acd4-5a59d7c8e7d5', accountTypes: 'SAVINGS' , viewName: 'AVM_ViewName' }
    })

    nock( 'https://' + config.services.fpo.root )
      .get( /users.*\/accounts\/visible.*/ )
      .query(true)
      .reply( 200,  avmMock)



    nock( 'https://' + config.services.interaction.root )
      .post(`/users/${TEST_AUTH_ID}/accounts/search`, function (body) {
        return Array.isArray(body.requestParams.filters)
      })
      .reply( 200, accountsListMock )      

    listCtrl( mockRequest, mockResponse )

    it( 'should respond with 200', function ( done ) {
      expect( mockResponse.statusCode ).to.equal( 200 )
      done()
    } )

    it( 'should respond with a list of 1', function ( done ) {
      expect( mockResponse.response ).to.be.defined
      expect( mockResponse.response.results ).to.have.length( 1 )
      done()
    } )

    it( 'should have isSelected field in account', function ( done ) {
      expect( mockResponse.response ).to.be.defined
      expect( mockResponse.response.results[0].isSelected ).to.be.defined
      done()
    } )

    it ('should have isSelected true for AVM Selection', function (done) {
      expect( mockResponse.response ).to.be.defined
      const avmAccount = avmMock.accountIds[0]
      const found = mockResponse.response.results.find(account => account.accountId === avmAccount)
      expect( found ).to.be.defined
      expect( found.isSelected).to.be.true
      done()
    })
 


  } )  

})