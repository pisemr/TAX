// import { expect } from 'chai'
// import nock from 'nock'
// import config from '../../../lib/config'
// import Request from '../../mocks/request'
// import Response from '../../mocks/response'
// import {
//   acquireAccountsCtrl,
//   fpoPollingCtrl,
//   fpoCallbackCtrl
// } from '../../../controllers/accounts/accounts'
//
// import { VAULT_ROUTE_ERRORS } from '../../../constants/error-mapping'
//
// //Mocks
// import { InitialAccountsResponse, PollingAccountsResponse, UpdatedAccountsResponse, FinalAccountsResponse } from './mocks/accountsResponses'
// import CacheEntries from './mocks/cacheEntries'
// import SyncAcquireResponse from './mocks/syncAcquireResponse'
// import SyncMFAResponse from './mocks/syncMFAResponse'
// import AsyncAcquireResponse from './mocks/asyncAcquireResponse'
// import AcquireRequest from './mocks/acquireRequest'
// import FDIFinalResponse from '../../../controllers/accounts/mockFinalResponse'
// import FDIMFAResponse from "../../../controllers/accounts/mockMfaResponse"
//
// /*
// Scenarios
//   1. posting an initial accounts request (async and sync)
//   2. polling for an updated accounts response
//   3. updating the cache entry
//   4. polling for the updated entry
//   5. all cache error situations
// */
//
// const TEST_AUTH_ID = 2265507445
// // const TEST_ASYNC_AUTH_ID = 987654321
// // const TEST_MFA_AUTH_ID = 456789123
//
//
// //Helper functions for verification/setup
// const commonErrorVerification = function( mockResponse, cacheError ) {
//   it( 'should respond with a response object', function( done ) {
//     expect( mockResponse.response )
//       .to.be.defined
//     done()
//   } )
//
//   it( 'should respond with 400', function( done ) {
//     expect( mockResponse.statusCode )
//       .to.equal( 400 )
//     done()
//   } )
//
//   it( 'should have the right vault error code', function( done ) {
//     if ( cacheError ) {
//       expect( mockResponse.response.code )
//         .to.equal( VAULT_ROUTE_ERRORS.cache )
//     } else {
//       expect( mockResponse.response.code )
//         .to.equal( VAULT_ROUTE_ERRORS.fpo.default.code )
//     }
//     done()
//   } )
// }
//
// const common200ResponseVerification = function( mockResponse ) {
//   it( 'should respond with a response object', function( done ) {
//     expect( mockResponse.response )
//       .to.be.defined
//     done()
//   } )
//
//   it( 'should respond with 200', function( done ) {
//     expect( mockResponse.statusCode )
//       .to.equal( 200 )
//     done()
//   } )
// }
//
// const createMockForCachePut = function( correlationId, returnStatus) {
//   nock( `https://${config.services.cache.root}` )
//     .put( `/${config.services.cache.ticketlessPath}${config.services.cache.entryPrefix}${correlationId}` )
//     .query( { 'ttl': config.services.cache.timeToLive, 'owner': TEST_AUTH_ID } )
//     .reply( returnStatus, '' )
// }
//
// const createMockForCacheGet = function( correlationId, returnStatus, cacheBody ) {
//   nock( `https://${config.services.cache.root}` )
//     .get( `/${config.services.cache.ticketlessPath}${config.services.cache.entryPrefix}${correlationId}`)
//     .query( { 'owner': TEST_AUTH_ID } )
//     .reply( returnStatus, cacheBody )
// }
//
// const createMockForAcquire = function( returnStatus, asyncCorrelationId, mfaResonse ) {
//   let resp, authid
//   if ( asyncCorrelationId ) {
//     AsyncAcquireResponse.omsCorrelationId = asyncCorrelationId
//     resp = AsyncAcquireResponse
//     authid = TEST_AUTH_ID
//   } else {
//     resp = mfaResonse ? SyncMFAResponse : SyncAcquireResponse
//     authid = TEST_AUTH_ID
//   }
//   nock( 'https://' + config.services.fpo.root )
//     .post( config.services.fpo.path.userAcquire.replace( /{authid}/, authid ) )
//     .reply( returnStatus, resp )
// }
//
// const getOptionsForInitialAccounts = function( correlationId, sync, mfaResponse ) {
//   AcquireRequest.sync = sync
//   return {
//     method: 'POST',
//     query: {
//       forceCorrelationId: correlationId
//     },
//     cookies: {
//       'qbn.ptc.authid': TEST_AUTH_ID
//     },
//     body: AcquireRequest
//   }
// }
//
// const getOptionsForPolling = function( correlationId ) {
//   return {
//     method: 'GET',
//     params: {
//       correlationId: correlationId
//     }
//   }
// }
//
// const getOptionsForCallback = function( correlationId, callbackData ) {
//   return {
//     method: 'POST',
//     headers: {
//       omscorrelationid: correlationId
//     },
//     body: callbackData
//   }
// }
//
// let testCorrelationId = 100
// const getNextCorrelationId = function() {
//   return testCorrelationId++
// }
//
// describe( 'Accounts Controller', function() {
//
//   describe( 'Submitting initial accounts request', function() {
//     let testCorrelationId = getNextCorrelationId()
//
//     createMockForCachePut( testCorrelationId, 200 )
//     createMockForAcquire( 200, testCorrelationId )
//
//     let options = getOptionsForInitialAccounts( testCorrelationId, false )
//     let mockResponse = new Response()
//     let mockRequest = new Request( options )
//
//     acquireAccountsCtrl( mockRequest, mockResponse )
//
//     common200ResponseVerification( mockResponse )
//
//     it( 'should have an assigned correlationId and initial status', function( done ) {
//       expect( mockResponse.response.correlationId )
//         .to.equal( testCorrelationId )
//       expect( mockResponse.response.status )
//         .to.equal( InitialAccountsResponse.status )
//       done()
//     } )
//   } )
//
//   describe( 'Submitting initial accounts async request', function() {
//     let testCorrelationId = getNextCorrelationId()
//
//     createMockForCachePut( testCorrelationId, 200 )
//     createMockForAcquire( 200, testCorrelationId )
//
//     let options = getOptionsForInitialAccounts( testCorrelationId, false )
//     let mockResponse = new Response()
//     let mockRequest = new Request( options )
//
//     acquireAccountsCtrl( mockRequest, mockResponse )
//
//     common200ResponseVerification( mockResponse )
//
//     it( 'should have an assigned correlationId and initial status', function( done ) {
//       expect( mockResponse.response.correlationId )
//         .to.equal( testCorrelationId )
//       expect( mockResponse.response.status )
//         .to.equal( InitialAccountsResponse.status )
//       done()
//     } )
//   } )
//
//   describe( 'Submitting initial accounts async request with FPO error response', function() {
//     let testCorrelationId = getNextCorrelationId()
//
//     createMockForCachePut( testCorrelationId, 200 )
//     createMockForAcquire( 400, testCorrelationId, true )
//
//     let options = getOptionsForInitialAccounts( testCorrelationId, false )
//     let mockResponse = new Response()
//     let mockRequest = new Request( options )
//
//     acquireAccountsCtrl( mockRequest, mockResponse )
//
//     commonErrorVerification( mockResponse, false )
//   } )
//
//   describe( 'Submitting initial accounts sync request', function() {
//     let testCorrelationId = getNextCorrelationId()
//
//     createMockForCachePut( testCorrelationId, 200 )
//     createMockForAcquire( 200 )
//
//     let options = getOptionsForInitialAccounts( testCorrelationId, true )
//     let mockResponse = new Response()
//     let mockRequest = new Request( options )
//
//     acquireAccountsCtrl( mockRequest, mockResponse )
//
//     common200ResponseVerification( mockResponse )
//
//     it( 'should have an assigned correlationId and initial status', function( done ) {
//       expect( mockResponse.response.correlationId )
//         .to.equal( testCorrelationId )
//       expect( mockResponse.response.status )
//         .to.equal( InitialAccountsResponse.status )
//       done()
//     } )
//   } )
//
//   describe( 'Submitting initial accounts sync request with MFA response', function() {
//     let testCorrelationId = getNextCorrelationId()
//
//     createMockForCachePut( testCorrelationId, 200 )
//     createMockForAcquire( 200, null, true )
//
//     let options = getOptionsForInitialAccounts( testCorrelationId, true, true )
//     let mockResponse = new Response()
//     let mockRequest = new Request( options )
//
//     acquireAccountsCtrl( mockRequest, mockResponse )
//
//     common200ResponseVerification( mockResponse )
//
//     it( 'should have an assigned correlationId and initial status', function( done ) {
//       expect( mockResponse.response.correlationId )
//         .to.equal( testCorrelationId )
//       expect( mockResponse.response.status )
//         .to.equal( InitialAccountsResponse.status )
//       done()
//     } )
//   } )
//
//   describe( 'Polling request Responds with MFA error response (187)', function() {
//     let testCorrelationId = 'errorEntry3'
//
//     createMockForCacheGet( testCorrelationId, 200, CacheEntries.ErrorEntry3 )
//
//     let options = getOptionsForPolling( testCorrelationId )
//     let mockResponse = new Response()
//     let mockRequest = new Request( options )
//
//     fpoPollingCtrl( mockRequest, mockResponse )
//
//     // commonErrorVerification( mockResponse, true )
//
//     it( 'should have a providers array in detail', function( done ) {
//       expect( mockResponse.response.detail.providers )
//         .to.be.an( 'array')
//       expect( mockResponse.response.detail.responseParams )
//         .to.be.an( 'object')
//       done()
//     } )
//   } )
//
//   describe( 'Submitting initial accounts sync request with FPO error response', function() {
//     let testCorrelationId = getNextCorrelationId()
//
//     createMockForCachePut( testCorrelationId, 200 )
//     createMockForAcquire( 400, null, true )
//
//     let options = getOptionsForInitialAccounts( testCorrelationId, true )
//     let mockResponse = new Response()
//     let mockRequest = new Request( options )
//
//     acquireAccountsCtrl( mockRequest, mockResponse )
//
//     common200ResponseVerification( mockResponse )
//
//     it( 'should have an assigned correlationId and initial status', function( done ) {
//       expect( mockResponse.response.correlationId )
//         .to.equal( testCorrelationId )
//       expect( mockResponse.response.status )
//         .to.equal( InitialAccountsResponse.status )
//       done()
//     } )
//   } )
//
//   describe( 'Submitting invalid cache entry respose', function() {
//     let testCorrelationId = getNextCorrelationId()
//
//     createMockForCachePut( testCorrelationId, 400 )
//     createMockForAcquire( 200, testCorrelationId )
//
//     let options = getOptionsForInitialAccounts( testCorrelationId, false )
//     let mockResponse = new Response()
//     let mockRequest = new Request( options )
//
//     acquireAccountsCtrl( mockRequest, mockResponse )
//
//     commonErrorVerification( mockResponse, true )
//   } )
//
//   describe( 'Submitting polling request for valid correlationId', function() {
//     let testCorrelationId = CacheEntries.InitialCacheEntry1.correlationId
//
//     createMockForCacheGet( testCorrelationId, 200, CacheEntries.InitialCacheEntry1 )
//
//     let options = getOptionsForPolling( testCorrelationId )
//     let mockResponse = new Response()
//     let mockRequest = new Request( options )
//
//     fpoPollingCtrl( mockRequest, mockResponse )
//
//     common200ResponseVerification( mockResponse )
//
//     it( 'should have an assigned correlationId and waiting status', function( done ) {
//       expect( mockResponse.response.correlationId )
//         .to.equal( testCorrelationId )
//       expect( mockResponse.response.status )
//         .to.equal( PollingAccountsResponse.status )
//       done()
//     } )
//   } )
//
//   describe( 'Submitting polling request for invalid correlationId', function() {
//     let testCorrelationId = getNextCorrelationId()
//     createMockForCacheGet( testCorrelationId, 400, "" )
//
//     let options = getOptionsForPolling( testCorrelationId )
//     let mockResponse = new Response()
//     let mockRequest = new Request( options )
//
//     fpoPollingCtrl( mockRequest, mockResponse )
//
//     commonErrorVerification( mockResponse, true )
//   } )
//
//   describe( 'Submitting polling request and get cache response for the incorrect correlationId', function() {
//     let testCorrelationId = getNextCorrelationId()
//
//     createMockForCacheGet( testCorrelationId, 200, CacheEntries.InitialCacheEntry2 )
//
//     let options = getOptionsForPolling( testCorrelationId )
//     let mockResponse = new Response()
//     let mockRequest = new Request( options )
//
//     fpoPollingCtrl( mockRequest, mockResponse )
//
//     commonErrorVerification( mockResponse, true )
//   } )
//
//   describe( 'Submitting polling request and get cache response with error', function() {
//     let testCorrelationId = CacheEntries.ErrorEntry1.correlationId
//
//     createMockForCacheGet( testCorrelationId, 200, CacheEntries.ErrorEntry1 )
//
//     let options = getOptionsForPolling( testCorrelationId )
//     let mockResponse = new Response()
//     let mockRequest = new Request( options )
//
//     fpoPollingCtrl( mockRequest, mockResponse )
//
//     commonErrorVerification( mockResponse, false )
//   } )
//
//   describe( 'Submitting polling request and get cache response with error and fpo error details', function() {
//     let testCorrelationId = CacheEntries.ErrorEntry2.correlationId
//
//     createMockForCacheGet( testCorrelationId, 200, CacheEntries.ErrorEntry2 )
//
//     let options = getOptionsForPolling( testCorrelationId )
//     let mockResponse = new Response()
//     let mockRequest = new Request( options )
//
//     fpoPollingCtrl( mockRequest, mockResponse )
//
//     commonErrorVerification( mockResponse, false )
//
//     it( 'should have a response and detail', function( done ) {
//       expect( mockResponse.response.detail )
//         .to.not.be.equal( null )
//       done()
//     } )
//   } )
//
//   describe( 'Submit async callback', function() {
//     let testCorrelationId = CacheEntries.InitialCacheEntry3.correlationId
//
//     createMockForCacheGet( testCorrelationId, 200, CacheEntries.InitialCacheEntry3 )
//     createMockForCachePut( testCorrelationId, 200 )
//
//     let options = getOptionsForCallback( testCorrelationId, FDIFinalResponse )
//     let mockResponse = new Response()
//     let mockRequest = new Request( options )
//
//     fpoCallbackCtrl( mockRequest, mockResponse )
//
//     common200ResponseVerification( mockResponse )
//
//     it( 'should have an assigned correlationId and updated status', function( done ) {
//       // console.log(mockResponse)
//       expect( mockResponse.response.correlationId )
//         .to.equal( testCorrelationId )
//       expect( mockResponse.response.status )
//         .to.equal( UpdatedAccountsResponse.status )
//       done()
//     } )
//
//   } )
//
//   describe( 'Submit async callback without initial cache entry', function() {
//     let testCorrelationId = getNextCorrelationId()
//
//     createMockForCacheGet( testCorrelationId, 404, "" )
//     createMockForCachePut( testCorrelationId, 200 )
//
//     let options = getOptionsForCallback( testCorrelationId, FDIFinalResponse )
//     let mockResponse = new Response()
//     let mockRequest = new Request( options )
//
//     fpoCallbackCtrl( mockRequest, mockResponse )
//
//     commonErrorVerification( mockResponse, true )
//   } )
//
//   describe( 'Submit async callback after cache was already updated', function() {
//     let testCorrelationId = CacheEntries.UpdatedCacheEntry1.correlationId
//
//     CacheEntries.UpdatedCacheEntry1.response = FDIFinalResponse
//
//     createMockForCacheGet( testCorrelationId, 200, CacheEntries.UpdatedCacheEntry1 )
//     createMockForCachePut( testCorrelationId, 200 )
//
//     let options = getOptionsForCallback( testCorrelationId, FDIFinalResponse )
//     let mockResponse = new Response()
//     let mockRequest = new Request( options )
//
//     fpoCallbackCtrl( mockRequest, mockResponse )
//
//     commonErrorVerification( mockResponse, true )
//   } )
//
//   describe( 'Submit async callback and get cache response for the incorrect correlationId', function() {
//     let testCorrelationId = 'badCorrelationId'
//
//     createMockForCacheGet( testCorrelationId, 200, CacheEntries.UpdatedCacheEntry2 )
//       //createMockForCachePut( testCorrelationId, 200 )
//
//     let options = getOptionsForCallback( testCorrelationId, FDIFinalResponse )
//     let mockResponse = new Response()
//     let mockRequest = new Request( options )
//
//     fpoCallbackCtrl( mockRequest, mockResponse )
//
//     commonErrorVerification( mockResponse, true )
//   } )
//
//   describe( 'Submitting polling request after FPO callback with final response', function() {
//     let testCorrelationId = CacheEntries.UpdatedCacheEntry3.correlationId
//
//     CacheEntries.UpdatedCacheEntry3.response = FDIFinalResponse
//     FinalAccountsResponse.response = FDIFinalResponse
//
//     createMockForCacheGet( testCorrelationId, 200, CacheEntries.UpdatedCacheEntry3 )
//
//     let options = getOptionsForPolling( testCorrelationId )
//     let mockResponse = new Response()
//     let mockRequest = new Request( options )
//
//     fpoPollingCtrl( mockRequest, mockResponse )
//
//     common200ResponseVerification( mockResponse )
//
//     it( 'should have an assigned correlationId and ready status and a valid response', function( done ) {
//
//       //console.log('MOCK RESPONSE', mockResponse)
//       expect( mockResponse.response.correlationId )
//         .to.equal( testCorrelationId )
//       expect( mockResponse.response.status )
//         .to.equal( FinalAccountsResponse.status )
//       expect( mockResponse.response.response )
//         .to.not.be.equal( null )
//       expect( mockResponse.response.response.response_params )
//         .to.not.be.equal( null )
//       expect( mockResponse.response.response.providers[ 0 ].providerId )
//         .to.not.be.equal( null )
//       expect( mockResponse.response.response.providers[ 0 ].credentialSets[ 0 ].credentialSetId )
//         .to.not.be.equal( null )
//
//       done()
//     } )
//   } )
//
//   describe( 'Submitting polling request after FPO callback with MFA response', function() {
//     let testCorrelationId = CacheEntries.UpdatedCacheEntry4.correlationId
//
//     CacheEntries.UpdatedCacheEntry4.response = SyncMFAResponse
//     FinalAccountsResponse.response = FDIMFAResponse
//
//     createMockForCacheGet( testCorrelationId, 200, CacheEntries.UpdatedCacheEntry4 )
//
//     let options = getOptionsForPolling( testCorrelationId )
//     let mockResponse = new Response()
//     let mockRequest = new Request( options )
//
//     fpoPollingCtrl( mockRequest, mockResponse )
//
//     common200ResponseVerification( mockResponse )
//
//     it( 'should have an assigned correlationId and ready status and a valid mfaRequired', function( done ) {
//       expect( mockResponse.response.correlationId )
//         .to.equal( testCorrelationId )
//       expect( mockResponse.response.status )
//         .to.equal( FinalAccountsResponse.status )
//       expect( mockResponse.response.mfaRequired )
//         .to.not.be.equal( null )
//       expect( mockResponse.response.response.providerId )
//         .to.not.be.equal( null )
//       expect( mockResponse.response.response.credentialSetId )
//         .to.not.be.equal( null )
//       expect( mockResponse.response.response.authFieldnMapping )
//         .to.not.be.equal( null )
//       expect( mockResponse.response.response.mfaSession )
//         .to.not.be.equal( null )
//
//       done()
//     } )
//   } )
//
// } )
