import { expect } from 'chai'
import nock from 'nock'
import { oauth } from '../authenticate/mocks/oauth'
import config from '../../../lib/config'
import Request from '../../mocks/request'
import Response from '../../mocks/response'
import {
  acquireAccountsCtrl,
  mfaSubmitCtrl,
  fpoPollingCtrl,
  fpoCallbackCtrl
} from '../../../controllers/accounts/accounts'

import { VAULT_ROUTE_ERRORS } from '@fdx/common/errors/error-mapping'

import {
  SyncAcquireResponse,
  SyncMFAResponse,
  AsyncAcquireResponse,
  AcquireRequest,
  // CacheEntries,
  AccountsResponses
} from './mocks'

import CacheModel, {
  CACHE_STATUS_MAP,
  CACHE_CONNECTION_STATUS_MAP
} from '../../../models/cache/CacheModel'

import FDIFinalResponse from '../../../controllers/accounts/mockFinalResponse'
import FDIMFAResponse from "../../../controllers/accounts/mockMfaResponse"

const {
  InitialAccountsResponse,
  PollingAccountsResponse,
  UpdatedAccountsResponse,
  FinalAccountsResponse
} = AccountsResponses

const {
  acquireRequest,
  mfaRequest,
  refreshRequest
} = AcquireRequest

/*
Scenarios
  1. posting an initial accounts request (async and sync)
  2. polling for an updated accounts response
  3. updating the cache entry
  4. polling for the updated entry
  5. all cache error situations
*/

const TEST_AUTH_ID = 2265507445

const createMockForCachePut = function( returnStatus, correlationId, response) {
  nock( `https://${config.services.cache.root}` )
    .put( `/${config.services.cache.ticketlessPath}${config.services.cache.entryPrefix}${correlationId}` )
    .query( { 'ttl': config.services.cache.timeToLive, 'owner': TEST_AUTH_ID } )
    .reply( returnStatus, response )
}

const createMockForCacheGet = function( returnStatus, correlationId, response ) {
  nock( `https://${config.services.cache.root}` )
    .get( `/${config.services.cache.ticketlessPath}${config.services.cache.entryPrefix}${correlationId}`)
    .query( { 'owner': TEST_AUTH_ID } )
    .reply( returnStatus, response )
}

const createMockForAcquire = function( returnStatus, response ) {
  nock( 'https://' + config.services.fpo.root )
    .post( config.services.fpo.path.userAcquire.replace( /{authid}/, TEST_AUTH_ID ) )
    .reply( returnStatus, response )
}

describe( 'Accounts Controller', function() {

  describe( 'Submitting initial accounts request with sync = true', function() {
    let testCorrelationId = '1234-1234'

    createMockForCachePut(200, testCorrelationId, '')
    createMockForCacheGet(200, testCorrelationId, new CacheModel({
      correlationId: testCorrelationId,
      cacheStatus: CACHE_STATUS_MAP.INITIAL,
      response: {
    		"omsCorrelationId": testCorrelationId
    	},
      connectionStatus: CACHE_CONNECTION_STATUS_MAP.PENDING
    }))
    createMockForAcquire(200, SyncAcquireResponse)

    let options = {
      method: 'POST',
      body: {
        "correlationId": testCorrelationId,
      	"sync": true,
      	...acquireRequest
      }
    }
    let mockResponse = new Response()
    let mockRequest = new Request( options )

    acquireAccountsCtrl( mockRequest, mockResponse )

    it( 'should respond with 200 ok', function ( done ) {
      expect( mockResponse.statusCode ).to.equal( 200 )
      done()
    } )
    it( 'should have an assigned correlationId', function( done ) {
      expect( mockResponse.response.correlationId )
        .to.equal( testCorrelationId )
      done()
    } )
    it( 'should have cacheStatus === INITIAL', function( done ) {
      expect( mockResponse.response.cacheStatus )
        .to.equal( CACHE_STATUS_MAP.INITIAL )
      done()
    } )
    it( 'should have connectionStatus === CACHE_CONNECTION_STATUS_MAP.PENDING', function( done ) {
      expect( mockResponse.response.connectionStatus )
        .to.equal( CACHE_CONNECTION_STATUS_MAP.PENDING)
      done()
    } )
    it( 'should have the default segment values (segment:0, totalSegments:0)', function( done ) {
      expect( mockResponse.response.segment )
        .to.equal( 0 )
      expect( mockResponse.response.totalSegments )
        .to.equal( 0 )
      done()
    } )

  } )

  describe( 'Submitting initial accounts request with sync = false', function() {
    let testCorrelationId = '2345-2345'

    createMockForCachePut(200, testCorrelationId, '')
    createMockForCacheGet(200, testCorrelationId, new CacheModel({
      correlationId: testCorrelationId,
      cacheStatus: CACHE_STATUS_MAP.INITIAL,
      response: {
        "omsCorrelationId": testCorrelationId
      },
      connectionStatus: CACHE_CONNECTION_STATUS_MAP.PENDING
    }))
    createMockForAcquire(200, AsyncAcquireResponse)

    let options = {
      method: 'POST',
      body: {
        "sync": false,
      	...acquireRequest
      }
    }

    let mockResponse = new Response()
    let mockRequest = new Request( options )

    acquireAccountsCtrl( mockRequest, mockResponse )

    it( 'should respond with 200 ok', function ( done ) {
      expect( mockResponse.statusCode ).to.equal( 200 )
      done()
    } )
    it( 'should have an assigned correlationId', function( done ) {
      expect( mockResponse.response.correlationId )
        .to.equal( testCorrelationId )
      done()
    } )
    it( 'should have cacheStatus === INITIAL', function( done ) {
      expect( mockResponse.response.cacheStatus )
        .to.equal( CACHE_STATUS_MAP.INITIAL )
      done()
    } )
    it( 'should have connectionStatus === CACHE_CONNECTION_STATUS_MAP.PENDING', function( done ) {
      expect( mockResponse.response.connectionStatus )
        .to.equal( CACHE_CONNECTION_STATUS_MAP.PENDING)
      done()
    } )
    it( 'should have the default segment values (segment:0, totalSegments:0)', function( done ) {
      expect( mockResponse.response.segment )
        .to.equal( 0 )
      expect( mockResponse.response.totalSegments )
        .to.equal( 0 )
      done()
    } )

  } )


  // describe( 'Submitting MFA Response with sync = false', function() {
  //   let testCorrelationId = '3333-3333'
  //
  //   createMockForCachePut(200, testCorrelationId, '')
  //   createMockForCacheGet(200, testCorrelationId, new CacheModel({
  //     correlationId: testCorrelationId,
  //     cacheStatus: CACHE_STATUS_MAP.INITIAL,
  //     response: {
  //       "omsCorrelationId": testCorrelationId
  //     },
  //     connectionStatus: CACHE_CONNECTION_STATUS_MAP.PENDING
  //   }))
  //   createMockForAcquire(200, AsyncAcquireResponse)
  //
  //   let options = {
  //     method: 'POST',
  //     body: {
  //       "sync": false,
  //       ...mfaRequest
  //     }
  //   }
  //
  //   let mockResponse = new Response()
  //   let mockRequest = new Request( options )
  //
  //   mfaSubmitCtrl( mockRequest, mockResponse )
  //
  //   it( 'should respond with 200 ok', function ( done ) {
  //     expect( mockResponse.statusCode ).to.equal( 200 )
  //     done()
  //   } )
  //   it( 'should have an assigned correlationId', function( done ) {
  //     expect( mockResponse.response.correlationId )
  //       .to.equal( testCorrelationId )
  //     done()
  //   } )
  //   it( 'should have cacheStatus === INITIAL', function( done ) {
  //     expect( mockResponse.response.cacheStatus )
  //       .to.equal( CACHE_STATUS_MAP.INITIAL )
  //     done()
  //   } )
  //   it( 'should have connectionStatus === CACHE_CONNECTION_STATUS_MAP.PENDING', function( done ) {
  //     expect( mockResponse.response.connectionStatus )
  //       .to.equal( CACHE_CONNECTION_STATUS_MAP.PENDING)
  //     done()
  //   } )
  //   it( 'should have the default segment values (segment:0, totalSegments:0)', function( done ) {
  //     expect( mockResponse.response.segment )
  //       .to.equal( 0 )
  //     expect( mockResponse.response.totalSegments )
  //       .to.equal( 0 )
  //     done()
  //   } )
  //
  // } )

  describe( 'Submitting initial accounts request with authType = oauth', function() {
    let testCorrelationId = '1234-1234'

    nock('https://' + config.services.partnerAuth.root)
      .get(config.services.partnerAuth.path.token)
      .query(oauth.responseToken)
      .reply(200, oauth.successPartnerAuthToken)

    nock('https://' + config.services.partnerAuth.root)
      .post(`/pa_tokens/${oauth.successPartnerAuthToken.partnerAuthTokens[0].partnerAuthTokenId}/auth_headers`)
      .reply(200, oauth.successAuthHeaders)

    createMockForCachePut(200, testCorrelationId, '')
    createMockForCacheGet(200, testCorrelationId, new CacheModel({
      correlationId: testCorrelationId,
      cacheStatus: CACHE_STATUS_MAP.INITIAL,
      response: {
        "omsCorrelationId": testCorrelationId
      },
      connectionStatus: CACHE_CONNECTION_STATUS_MAP.PENDING
    }))
    createMockForAcquire(200, AsyncAcquireResponse)

    let mockRequest = new Request( oauth.requestOptions )
    let mockResponse = new Response()

    acquireAccountsCtrl( mockRequest, mockResponse )

    it( 'should respond with 200 ok', function ( done ) {
      // console.log(mockResponse)
      //TODO: test and correct the test case if needed to return 200 statusCode
      expect( mockResponse.statusCode ).to.equal( 400 )
      done()
    } )

  } )

} )
