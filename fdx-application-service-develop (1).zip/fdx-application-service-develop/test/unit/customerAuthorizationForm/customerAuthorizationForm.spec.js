import { expect } from 'chai'
import nock from 'nock'
import config from '../../../lib/config'
import Request from '../../mocks/request'
import Response from '../../mocks/response'
import {
  customerAuthorizationFormCtrl
} from '../../../controllers/customerAuthorizationForm/customerAuthorizationForm'

const TEST_REALMID = '50000003'
const TEST_PROVIDER_ID = 'ab34b36d-5519-4380-8614-7c215327f246'
const CAF_SERVICE_ROOT = config.services.fpo.root
const PROTOCAL = config.services.protocal

const cafServiceResponse = require('./mocks/cafServiceResponse.json')
const cafErrorResponse = require('./mocks/cafErrorResponse.json')

const options = {
  'body': {
    'providerId': 'ab34b36d-5519-4380-8614-7c215327f246',
    'channelId' : '1867da4f-13d6-4ced-aea5-e4b55deb216a',
    'formData' : [
      {
        'name':'form_branch',
        'value':'Steyning'
      },
      {
        'name':'form_accountName',
        'value':'BMM AOUNT'
      }
    ],
    'credentialSetId': 'xxxxxxxxxx',
    'accountId':'fdpAccoungtIdxxxxxxxx',
    'accountNumberMasked':'xxxxxxx',
    'accountNumberTokenized':'xxxxxxxx'
  }
}

describe(' CAF Testing Route', function () {
  describe('CAF response will return document ID successfully', function () {

    nock(`${PROTOCAL}://${CAF_SERVICE_ROOT}`)
    .post(`/realms/${TEST_REALMID}/providers/${TEST_PROVIDER_ID}/customerAuthorizationForm`)
    .reply(200, cafServiceResponse)

    let mockResponse = new Response()
    let mockRequest = new Request(options)

    customerAuthorizationFormCtrl(mockRequest, mockResponse)

    it('should response with 200 ok', function (done) {
      expect(mockResponse.statusCode).to.equal(200)
      expect(mockResponse.response.authorizationDocId).to.be.defined
      done()
    })
  })
  describe('CAF response will return error', function () {

    nock(`${PROTOCAL}://${CAF_SERVICE_ROOT}`)
    .post(`/realms/${TEST_REALMID}/providers/${TEST_PROVIDER_ID}/customerAuthorizationForm`)
    .reply(400, cafErrorResponse)

    let mockResponse = new Response()
    let mockRequest = new Request(options)

    customerAuthorizationFormCtrl(mockRequest, mockResponse)

    it('should response with 400', function (done) {
      expect(mockResponse.statusCode).to.equal(400)
      expect(mockResponse.response.detail.code).to.equal('FDP-4000')
      done()
    })
  })

})
