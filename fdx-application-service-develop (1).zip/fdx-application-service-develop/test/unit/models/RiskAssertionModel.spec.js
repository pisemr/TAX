import {
  expect
} from 'chai'
// import sinon from 'sinon'
import RiskAssertionModel from '../../../models/riskscreening/RiskAssertionModel'

describe('RiskAssertionModel Model', function() {

  describe('on captcha transaction', function() {
    const mockReqData = {
      transaction: 'captcha_success',
      providerId: 'test-provider-1234',
      authid: '1234'
    }

    const ModelToTest = new RiskAssertionModel( { ...mockReqData } )
    it('should build proper model for feedback to RSS', function(done) {
      expect(ModelToTest.userAuthId).to.equal(mockReqData.authid)
      expect(ModelToTest.transaction).to.equal(mockReqData.transaction)
      expect(ModelToTest.transactionDetail).to.not.be.null
      expect(ModelToTest.riskAttributes).to.have.length(1)
      expect(ModelToTest.riskAttributes[0].namespace).to.not.be.null
      expect(ModelToTest.riskAttributes[0].key).to.not.be.null
      expect(ModelToTest.riskAttributes[0].values).to.be.an('array')
      expect(ModelToTest.riskAttributes[0].values[0]).to.equal(mockReqData.providerId)
      done()
    })

  })

})
