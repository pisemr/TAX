import PostBody from '../../../models/post-body-model'
import { expect } from 'chai'

import { document, accounts } from './mocks/post-bodys'

let accountsPostBody = new PostBody(accounts)
accountsPostBody.formatForAccounts()

let documentsPostBody = new PostBody(document)
documentsPostBody.formatForDocuments()

let profileConfig = {
  credSetId             : 123456789,
  offeringPreferences  : [
    {
      offeringId : 'Intuit.Vault-Test',
      notificationAttributes : [
        {
          key  : 'clientid',
          value: 121212121
        }
      ]
    }
  ],
  providerId            : '12345-12345-12345',
  folderId              : '54321-54321-54321',
  batchEligible         : true
}

let profileConfigDEL = {
  credSetId           : 'DELETE-CREDSET-ID',
  offeringPreferences : undefined,
  providerId          : '12345-12345-12345',
  folderId            : '54321-54321-54321',
  batchEligible       : false
}

let profilePostBody = new PostBody()
profilePostBody.formatProfileService(profileConfig)

let profilePostBodyDEL = new PostBody()
profilePostBodyDEL.formatProfileService(profileConfigDEL)

describe('Post Body Model (normalized post body for call to FDI)', function () {

  describe('normalized post body for call to FDI', function () {
    it('should have a property postData', function (done) {
      expect(accountsPostBody).to.have.property('postData')
      done()
    })

    describe('postData property', function () {

      it('should have a property persistenceParams', function (done) {
        expect(accountsPostBody.postData).to.have.property('persistenceParams')
        done()
      })

      it('should have a property provider', function (done) {
        expect(accountsPostBody.postData).to.have.property('provider')
        done()
      })

      it('should have a property requestParams', function (done) {
        expect(accountsPostBody.postData).to.have.property('requestParams')
        done()
      })

      describe('persistenceParams property', function () {
        it('should have a property persist', function (done) {
          expect(accountsPostBody.postData.persistenceParams).to.have.property('persist')
          done()
        })
      })

      describe('provider property', function () {
        it('should have a property credentialSet', function (done) {
          expect(accountsPostBody.postData.provider).to.have.property('credentialSet')
          done()
        })
        it('should have a property providerId', function (done) {
          expect(accountsPostBody.postData.provider).to.have.property('providerId')
          done()
        })

        describe('credentialSet property', function () {
          it('should have a property credentials that is an array', function (done) {
            expect(accountsPostBody.postData.provider.credentialSet).to.have.property('credentials').to.be.an('array')
            expect(accountsPostBody.postData.provider.credentialSet.credentials).to.be.an('array')
            done()
          })
        })
      })
    })
  })

  describe('normalized post body for call to Access Service', function () {
    it('should have a property postData', function (done) {
      expect(documentsPostBody).to.have.property('postData')
      done()
    })

    describe('postData property', function () {

      it('should have a property persistenceParams', function (done) {
        expect(documentsPostBody.postData).to.have.property('persistenceParams')
        done()
      })

      it('should have a property providerId', function (done) {
        expect(documentsPostBody.postData).to.have.property('providerId')
        done()
      })


      it('should have a property credentialParams', function (done) {
        expect(documentsPostBody.postData).to.have.property('credentialParams')
        done()
      })

      it('should have a property credentialParams.certVersion', function (done) {
        expect(documentsPostBody.postData.credentialParams).to.have.property('certVersion')
        done()
      })

      it('should have a property credentialParams.nameValuePair and it be an array', function (done) {
        expect(documentsPostBody.postData.credentialParams).to.have.property('nameValuePair')
        expect(documentsPostBody.postData.credentialParams.nameValuePair).to.be.an('array')
        done()
      })
    })
  })

  describe('normalized post body for call to Profile Service', function () {
    it('should have a property postData', function (done) {
      expect(profilePostBody).to.have.property('postData')
      done()
    })

    describe('postData property', function () {

      it('should have a property providerPreferences that is an array', function (done) {
        expect(profilePostBody.postData).to.have.property('providerPreferences')
        expect(profilePostBody.postData.providerPreferences).to.be.an('array')
        done()
      })

      it('should have a property providerId', function (done) {
        expect(profilePostBody.postData.providerPreferences[0]).to.have.property('providerId')
        expect(profilePostBody.postData.providerPreferences[0].providerId).to.equal('12345-12345-12345')
        done()
      })

      it('should have a property credentialPreferences', function (done) {
        expect(profilePostBody.postData.providerPreferences[0]).to.have.property('credentialPreferences')
        expect(profilePostBody.postData.providerPreferences[0].credentialPreferences).to.be.an('array')
        done()
      })

      it('should have a property credentialSetId', function (done) {
        expect(profilePostBody.postData.providerPreferences[0].credentialPreferences[0]).to.have.property('credentialSetId')
        expect(profilePostBody.postData.providerPreferences[0].credentialPreferences[0].credentialSetId).to.equal(123456789)
        done()
      })

      it('should have a property folderId', function (done) {
        expect(profilePostBody.postData.providerPreferences[0].credentialPreferences[0]).to.have.property('folderId')
        expect(profilePostBody.postData.providerPreferences[0].credentialPreferences[0].folderId).to.equal('54321-54321-54321')
        done()
      })

      it('should have a property documentBatchEligible === true', function (done) {
        expect(profilePostBody.postData.providerPreferences[0].credentialPreferences[0]).to.have.property('documentBatchEligible')
        expect(profilePostBody.postData.providerPreferences[0].credentialPreferences[0].documentBatchEligible).to.equal(true)
        done()
      })

      it('should have a property offeringPreferences that is an array', function (done) {
        expect(profilePostBody.postData.providerPreferences[0].credentialPreferences[0]).to.have.property('offeringPreferences')
        expect(profilePostBody.postData.providerPreferences[0].credentialPreferences[0].offeringPreferences).to.be.an('array')
        done()
      })

      it('should have a property offeringPreferences to have offeringId', function (done) {
        expect(profilePostBody.postData.providerPreferences[0].credentialPreferences[0].offeringPreferences[0]).to.have.property('offeringId')
        expect(profilePostBody.postData.providerPreferences[0].credentialPreferences[0].offeringPreferences[0].offeringId).to.equal('Intuit.Vault-Test')
        done()
      })

      it('should have a property offeringPreferences to have notificationAttributes', function (done) {
        expect(profilePostBody.postData.providerPreferences[0].credentialPreferences[0].offeringPreferences[0]).to.have.property('notificationAttributes')
        expect(profilePostBody.postData.providerPreferences[0].credentialPreferences[0].offeringPreferences[0].notificationAttributes).to.deep.equal([ { key  : 'clientid', value: 121212121 } ])
        done()
      })

      it('should have a icing on the cake', function (done) {
        expect(profilePostBody.postData).to.deep.equal({
          'providerPreferences': [
            {
              'providerId'           : '12345-12345-12345',
              'credentialPreferences': [
                {
                  'credentialSetId'      : 123456789,
                  'documentBatchEligible': true,
                  'folderId'             : '54321-54321-54321',
                  'offeringPreferences'  : [
                    {
                      'offeringId'             : 'Intuit.Vault-Test',
                      'notificationAttributes' : [
                        {
                          'key'  : 'clientid',
                          'value': 121212121
                        }
                      ]
                    }
                  ]
                }
              ]
            }
          ]
        })
        done()
      })
    })
  })

  describe('normalized post body for DELETE call to Profile Service', function () {
    it('should have a property postData', function (done) {
      expect(profilePostBodyDEL).to.have.property('postData')
      done()
    })

    describe('postData property', function () {

      it('should only contain privuderId, credentialSetId, folderId and batchElegible === false', function (done) {
        expect(profilePostBodyDEL.postData).to.deep.equal({
          'providerPreferences': [
            {
              'providerId'           : '12345-12345-12345',
              'credentialPreferences': [
                {
                  'credentialSetId'      : 'DELETE-CREDSET-ID',
                  'documentBatchEligible': false,
                  'folderId'             : '54321-54321-54321',
                }
              ]
            }
          ]
        })
        done()
      })
    })
  })
})
