import { expect } from 'chai'
import { ACCESS, DOCUMENT, CREDENTIALS, INTERACTION } from './mocks/errors'
import Error from '../../../models/Error'


// this.statusCode = 400
// this.code = 'FDPVLT-1002'
// this.type = 'CLIENT'
// this.message = error

describe('Sending errors to the client via the Error model', function () {

  describe('Unhandled exception', function () {
    let headers =  {
      intuit_tid: 'TEST_INTUIT_TID'
    }
    let error
    try {
      JSON.parse('hello')
    } catch(ex) {
      error = new Error ( 'stack', ex, headers )
    }

    it( 'should inclue a standard response', function ( done ) {
      expect( error ).to.have.all.keys( 'statusCode', 'code' , 'type', 'category', 'message', 'detail', 'intuit_tid', 'moreInfo' )
      done()
    } )

    it( 'should inclue vault error code FDPVLT-1002', function ( done ) {
      expect( error.code ).to.equal( 'FDPVLT-1002' )
      done()
    } )

    it( 'should inclue an intuit_tid', function ( done ) {
      expect( error.intuit_tid ).to.equal( headers.intuit_tid )
      done()
    } )

    it( 'should inclue a standard detail shape', function ( done ) {
      //expect( error.detail ).to.equal( 'Unexpected token h' )
      done()
    } )

    it( 'should include statusCode 500', function ( done ) {
      expect( error.statusCode ).to.equal( 500 )
      done()
    } )

    it( 'should include message', function ( done ) {
      expect( error.message ).to.equal( 'unhandled exception' )
      done()
    } )

  })

  describe('Mystery error response and handeling no statusCode', function () {
    let headers =  {
      intuit_tid: 'TEST_INTUIT_TID'
    }
    let message = {
      code    : 'ENOTFOUND',
      errno   : 'ENOTFOUND',
      syscall : 'getaddrinfo',
      hostname: 'fake.host.com',
      host    : 'fake.host.com',
      port    : 443
    }

    let error = new Error ( 'credentials', message, headers, 'none' )

    it( 'should inclue a standard response', function ( done ) {
      expect( error ).to.have.all.keys( 'statusCode', 'code' , 'type', 'category', 'message', 'detail', 'intuit_tid', 'moreInfo' )
      done()
    } )

    it( 'should inclue vault error code FDPVLT-5000', function ( done ) {
      expect( error.code ).to.equal( 'FDPVLT-5000' )
      done()
    } )

    it( 'should inclue an intuit_tid', function ( done ) {
      expect( error.intuit_tid ).to.equal( headers.intuit_tid )
      done()
    } )

    it( 'should inclue a standard detail shape', function ( done ) {
      expect( error.detail ).to.have.all.keys( 'code', 'message' )
      done()
    } )

    it( 'should include statusCode 500', function ( done ) {
      expect( error.statusCode ).to.equal( 500 )
      done()
    } )

    it( 'should include message', function ( done ) {
      expect( error.message ).to.equal( 'statusCode was not available' )
      done()
    } )

  })

  describe('Mystery error response and handeling no response or statuscode', function () {
    let headers =  {
      intuit_tid: 'TEST_INTUIT_TID'
    }
    let message = undefined

    let error = new Error ( 'credentials', message, headers, 'none' )

    it( 'should inclue a standard response', function ( done ) {
      expect( error ).to.have.all.keys( 'statusCode', 'code' , 'type', 'category', 'message', 'detail', 'intuit_tid', 'moreInfo' )
      done()
    } )

    it( 'should inclue vault error code FDPVLT-5000', function ( done ) {
      expect( error.code ).to.equal( 'FDPVLT-5000' )
      done()
    } )

    it( 'should inclue an intuit_tid', function ( done ) {
      expect( error.intuit_tid ).to.equal( headers.intuit_tid )
      done()
    } )

    it( 'should inclue a standard detail shape', function ( done ) {
      expect( error.detail ).to.have.all.keys( 'code', 'message' )
      done()
    } )

    it( 'should include statusCode 500', function ( done ) {
      expect( error.statusCode ).to.equal( 500 )
      done()
    } )

    it( 'should include message', function ( done ) {
      expect( error.message ).to.equal( 'statusCode was not available' )
      done()
    } )

    it( 'should include detail code no code returned', function ( done ) {
      expect( error.detail.code ).to.equal( 'no code returned' )
      done()
    } )

  })

  describe('CLIENT error sent from Vault Service ', function () {
    let headers =  {
      intuit_tid: 'TEST_INTUIT_TID'
    }
    let message = 'Sorry, there was a problem!'

    let error = new Error ( 'VALUT_CLIENT_ERROR', message, headers )

    it( 'should inclue a standard response', function ( done ) {
      expect( error ).to.have.all.keys( 'statusCode', 'code' , 'type', 'category', 'message', 'detail', 'intuit_tid', 'moreInfo' )
      done()
    } )

    it( 'should inclue vault error code FDPVLT-1000', function ( done ) {
      expect( error.code ).to.equal( 'FDPVLT-1000' )
      done()
    } )

    it( 'should inclue an intuit_tid', function ( done ) {
      expect( error.intuit_tid ).to.equal( headers.intuit_tid )
      done()
    } )

    it( 'should inclue a standard detail shape', function ( done ) {
      expect( error.detail ).to.have.all.keys( 'code', 'message' )
      done()
    } )

    it( 'should include statusCode', function ( done ) {
      expect( error.statusCode ).to.equal( 400 )
      done()
    } )

    it( 'should include message', function ( done ) {
      expect( error.message ).to.equal( message )
      done()
    } )

  })

  describe('SERVER error sent from Vault Service ', function () {
    let headers = {
      intuit_tid: 'TEST_INTUIT_TID'
    }

    let message = 'Sorry, there was a server problem!'

    let error = new Error ( 'VALUT_SERVER_ERROR', message, headers )

    it( 'should inclue a standard response', function ( done ) {
      expect( error ).to.have.all.keys( 'statusCode', 'code' , 'type', 'category', 'message', 'detail', 'intuit_tid', 'moreInfo' )
      done()
    } )

    it( 'should inclue vault error code FDPVLT-1001', function ( done ) {
      expect( error.code ).to.equal( 'FDPVLT-1001' )
      done()
    } )

    it( 'should inclue an intuit_tid', function ( done ) {
      expect( error.intuit_tid ).to.equal( headers.intuit_tid )
      done()
    } )

    it( 'should inclue a standard detail shape', function ( done ) {
      expect( error.detail ).to.have.all.keys( 'code', 'message' )
      done()
    } )

    it( 'should include statusCode', function ( done ) {
      expect( error.statusCode ).to.equal( 500 )
      done()
    } )

    it( 'should include message', function ( done ) {
      expect( error.message ).to.equal( message )
      done()
    } )
  })

  describe('Provider Service error', function () {
    let headers = {
      intuit_tid: 'TEST_INTUIT_TID'
    }

    let message =   {
      'error': [
        {
          'code': 'PROVIDER-10001',
          'type': 'CLIENT',
          'message': 'Invalid Request',
          'detail': 'filter criteria required',
          'moreInfo': ''
        }
      ]
    }

    let error = new Error ( 'providers', message, headers )

    it( 'should inclue a standard response', function ( done ) {
      expect( error ).to.have.all.keys( 'statusCode', 'code' , 'type', 'category', 'message', 'detail', 'intuit_tid', 'moreInfo' )
      done()
    } )

    it( 'should inclue vault error code FDPVLT-8000', function ( done ) {
      expect( error.code ).to.equal( 'FDPVLT-8000' )
      done()
    } )

    it( 'should inclue an intuit_tid', function ( done ) {
      expect( error.intuit_tid ).to.equal( headers.intuit_tid )
      done()
    } )

    it( 'should inclue a standard detail shape', function ( done ) {
      expect( error.detail ).to.have.all.keys( 'code', 'message' )
      done()
    } )

    it( 'should include statusCode', function ( done ) {
      expect( error.statusCode ).to.equal( 500 )
      done()
    } )

    it( 'should include service detail message', function ( done ) {
      expect( error.detail.message ).to.equal( 'Invalid Request filter criteria required' )
      done()
    } )
  })

  describe('Errors sent from Access Service', function ()   {
    describe('general Error sent from access', function () {
      let headers = {
        intuit_tid: 'TEST_INTUIT_TID'
      }
      let res = {
        statusCode: 500
      }
      let ACCESS_COPY = Object.assign({}, ACCESS)
      ACCESS_COPY.code = '1212'

      let error = new Error ( 'access', ACCESS_COPY, headers, res.statusCode )

      it( 'should inclue a standard response', function ( done ) {
        expect( error ).to.have.all.keys( 'statusCode', 'code' , 'type', 'category', 'message', 'intuit_tid', 'moreInfo', 'detail' )
        done()
      } )

      it( 'should inclue vault error code FDPVLT-3000', function ( done ) {
        expect( error.code ).to.equal( 'FDPVLT-3000' )
        done()
      } )

      it( 'should inclue an intuit_tid', function ( done ) {
        expect( error.intuit_tid ).to.equal( headers.intuit_tid )
        done()
      } )

      it( 'should inclue a standard detail shape plus more', function ( done ) {
        expect( error.detail ).to.have.all.keys( 'code', 'message', 'canDisplay', 'providerInfo'  )
        done()
      } )

      it( 'should include statusCode', function ( done ) {
        expect( error.statusCode ).to.equal( 500 )
        done()
      } )

      it( `should include code: ${ACCESS_COPY.code} from Access Service`, function ( done ) {
        expect( error.detail.code ).to.equal( ACCESS_COPY.code )
        done()
      } )

    })

    describe('bankNotPermittingLogin Error sent from access', function () {
      let headers = {
        intuit_tid: 'TEST_INTUIT_TID'
      }
      let res = {
        statusCode: 500
      }
      let ACCESS_COPY = Object.assign({}, ACCESS)
      ACCESS_COPY.code = '1012'

      let error = new Error ( 'access', ACCESS_COPY, headers, res.statusCode )

      it( 'should inclue a standard response', function ( done ) {
        expect( error ).to.have.all.keys( 'statusCode', 'code' , 'type', 'category', 'message', 'intuit_tid', 'moreInfo', 'detail' )
        done()
      } )

      it( 'should inclue vault error code FDPVLT-3004', function ( done ) {
        expect( error.code ).to.equal( 'FDPVLT-3004' )
        done()
      } )

      it( 'should inclue an intuit_tid', function ( done ) {
        expect( error.intuit_tid ).to.equal( headers.intuit_tid )
        done()
      } )

      it( 'should inclue a standard detail shape plus more', function ( done ) {
        expect( error.detail ).to.have.all.keys( 'code', 'message', 'canDisplay', 'providerInfo'  )
        done()
      } )

      it( 'should include statusCode', function ( done ) {
        expect( error.statusCode ).to.equal( 500 )
        done()
      } )

      it( `should include code: ${ACCESS_COPY.code} from Access Service`, function ( done ) {
        expect( error.detail.code ).to.equal( ACCESS_COPY.code )
        done()
      } )

    })

    describe('benign Error sent from access', function () {
      let headers = {
        intuit_tid: 'TEST_INTUIT_TID'
      }
      let res = {
        statusCode: 500
      }
      let ACCESS_COPY = Object.assign({}, ACCESS)
      ACCESS_COPY.code = '1213'

      let error = new Error ( 'access', ACCESS_COPY, headers, res.statusCode )

      it( 'should inclue a standard response', function ( done ) {
        expect( error ).to.have.all.keys( 'statusCode', 'code' , 'type', 'category', 'message', 'intuit_tid', 'moreInfo', 'detail' )
        done()
      } )

      it( 'should inclue vault error code FDPVLT-3001', function ( done ) {
        expect( error.code ).to.equal( 'FDPVLT-3001' )
        done()
      } )

      it( 'should inclue an intuit_tid', function ( done ) {
        expect( error.intuit_tid ).to.equal( headers.intuit_tid )
        done()
      } )

      it( 'should inclue a standard detail shape plus more', function ( done ) {
        expect( error.detail ).to.have.all.keys( 'code', 'message', 'canDisplay', 'providerInfo'  )
        done()
      } )

      it( 'should include statusCode', function ( done ) {
        expect( error.statusCode ).to.equal( 500 )
        done()
      } )

      it( `should include code: ${ACCESS_COPY.code} from Access Service`, function ( done ) {
        expect( error.detail.code ).to.equal( ACCESS_COPY.code )
        done()
      } )

    })

    describe('catastrophic Error sent from access', function () {
      let headers = {
        intuit_tid: 'TEST_INTUIT_TID'
      }
      let res = {
        statusCode: 500
      }
      let ACCESS_COPY = Object.assign({}, ACCESS)
      ACCESS_COPY.code = '3005'

      let error = new Error ( 'access', ACCESS_COPY, headers, res.statusCode )

      it( 'should inclue a standard response', function ( done ) {
        expect( error ).to.have.all.keys( 'statusCode', 'code' , 'type', 'category', 'message', 'intuit_tid', 'moreInfo', 'detail' )
        done()
      } )

      it( 'should inclue vault error code FDPVLT-3003', function ( done ) {
        expect( error.code ).to.equal( 'FDPVLT-3003' )
        done()
      } )

      it( 'should inclue an intuit_tid', function ( done ) {
        expect( error.intuit_tid ).to.equal( headers.intuit_tid )
        done()
      } )

      it( 'should inclue a standard detail shape plus more', function ( done ) {
        expect( error.detail ).to.have.all.keys( 'code', 'message', 'canDisplay', 'providerInfo' )
        done()
      } )

      it( 'should include statusCode', function ( done ) {
        expect( error.statusCode ).to.equal( 500 )
        done()
      } )

      it( `should include code: ${ACCESS_COPY.code} from Access Service`, function ( done ) {
        expect( error.detail.code ).to.equal( ACCESS_COPY.code )
        done()
      } )

    })

    describe('loginCredentialsInvalid Error sent from access', function () {
      let headers = {
        intuit_tid: 'TEST_INTUIT_TID'
      }
      let res = {
        statusCode: 500
      }
      let ACCESS_COPY = Object.assign({}, ACCESS)
      ACCESS_COPY.code = '1104'

      let error = new Error ( 'access', ACCESS_COPY, headers, res.statusCode )

      it( 'should inclue a standard response', function ( done ) {
        expect( error ).to.have.all.keys( 'statusCode', 'code' , 'type', 'category', 'message', 'intuit_tid', 'moreInfo', 'detail' )
        done()
      } )

      it( 'should inclue vault error code FDPVLT-3002', function ( done ) {
        expect( error.code ).to.equal( 'FDPVLT-3002' )
        done()
      } )

      it( 'should inclue an intuit_tid', function ( done ) {
        expect( error.intuit_tid ).to.equal( headers.intuit_tid )
        done()
      } )

      it( 'should inclue a standard detail shape plus more', function ( done ) {
        expect( error.detail ).to.have.all.keys( 'code', 'message',  'canDisplay', 'providerInfo'  )
        done()
      } )

      it( 'should include statusCode', function ( done ) {
        expect( error.statusCode ).to.equal( 500 )
        done()
      } )

      it( `should include code: ${ACCESS_COPY.code} from Access Service`, function ( done ) {
        expect( error.detail.code ).to.equal( ACCESS_COPY.code )
        done()
      } )

    })

    describe('transient Error sent from access', function () {
      let headers = {
        intuit_tid: 'TEST_INTUIT_TID'
      }
      let res = {
        statusCode: 500
      }
      let ACCESS_COPY = Object.assign({}, ACCESS)
      ACCESS_COPY.code = '3003'

      let error = new Error ( 'access', ACCESS_COPY, headers, res.statusCode )

      it( 'should inclue a standard response', function ( done ) {
        expect( error ).to.have.all.keys( 'statusCode', 'code' , 'type', 'category', 'message', 'intuit_tid', 'moreInfo', 'detail' )
        done()
      } )

      it( 'should inclue vault error code FDPVLT-3005', function ( done ) {
        expect( error.code ).to.equal( 'FDPVLT-3005' )
        done()
      } )

      it( 'should inclue an intuit_tid', function ( done ) {
        expect( error.intuit_tid ).to.equal( headers.intuit_tid )
        done()
      } )

      it( 'should inclue a standard detail shape plus more', function ( done ) {
        expect( error.detail ).to.have.all.keys( 'code', 'message', 'canDisplay', 'providerInfo'  )
        done()
      } )

      it( 'should include statusCode', function ( done ) {
        expect( error.statusCode ).to.equal( 500 )
        done()
      } )

      it( `should include code: ${ACCESS_COPY.code} from Access Service`, function ( done ) {
        expect( error.detail.code ).to.equal( ACCESS_COPY.code )
        done()
      } )

    })
    describe('mfa Error sent from access', function () {
      let headers = {
        intuit_tid: 'TEST_INTUIT_TID'
      }
      let res = {
        statusCode: 500
      }
      let ACCESS_COPY = Object.assign({}, ACCESS)
      ACCESS_COPY.code = '1017'

      let error = new Error ( 'access', ACCESS_COPY, headers, res.statusCode )

      it( 'should inclue a standard response', function ( done ) {
        expect( error ).to.have.all.keys( 'statusCode', 'code' , 'type', 'category', 'message', 'intuit_tid', 'moreInfo', 'detail' )
        done()
      } )

      it( 'should inclue vault error code FDPVLT-3006', function ( done ) {
        expect( error.code ).to.equal( 'FDPVLT-3006' )
        done()
      } )

      it( 'should inclue an intuit_tid', function ( done ) {
        expect( error.intuit_tid ).to.equal( headers.intuit_tid )
        done()
      } )

      it( 'should inclue a standard detail shape plus more', function ( done ) {
        expect( error.detail ).to.have.all.keys( 'code', 'message', 'canDisplay', 'providerInfo'  )
        done()
      } )

      it( 'should include statusCode', function ( done ) {
        expect( error.statusCode ).to.equal( 500 )
        done()
      } )

      it( `should include code: ${ACCESS_COPY.code} from Access Service`, function ( done ) {
        expect( error.detail.code ).to.equal( ACCESS_COPY.code )
        done()
      } )

    })

    describe('Error with new code sent from access', function () {
      let headers = {
        intuit_tid: 'TEST_INTUIT_TID'
      }
      let res = {
        statusCode: 500
      }
      let ACCESS_COPY = Object.assign({}, ACCESS)
      ACCESS_COPY.code = '9999'

      let error = new Error ( 'access', ACCESS_COPY, headers, res.statusCode )

      it( 'should inclue a standard response', function ( done ) {
        expect( error ).to.have.all.keys( 'statusCode', 'code', 'type', 'category', 'message', 'intuit_tid', 'moreInfo', 'detail' )
        done()
      } )

      it( 'should default to vault error code FDPVLT-3000', function ( done ) {
        expect( error.code ).to.equal( 'FDPVLT-3000' )
        done()
      } )

      it( 'should inclue an intuit_tid', function ( done ) {
        expect( error.intuit_tid ).to.equal( headers.intuit_tid )
        done()
      } )

      it( 'should inclue a standard detail shape plus more', function ( done ) {
        expect( error.detail ).to.have.all.keys( 'code', 'message', 'canDisplay', 'providerInfo'  )
        done()
      } )

      it( 'should include statusCode', function ( done ) {
        expect( error.statusCode ).to.equal( 500 )
        done()
      } )

      it( `should include code: ${ACCESS_COPY.code} from Access Service`, function ( done ) {
        expect( error.detail.code ).to.equal( ACCESS_COPY.code )
        done()
      } )

    })

  })

  describe('Error sent from document', function () {
    let req = {
      headers: {
        intuit_tid: 'TEST_INTUIT_TID'
      }
    }
    let res = {
      statusCode: 500
    }

    let error = new Error ( 'document', DOCUMENT, req.headers, res.statusCode )

    it( 'should inclue a standard response', function ( done ) {
      expect( error ).to.have.all.keys( 'statusCode', 'code' , 'type', 'category', 'message', 'intuit_tid', 'moreInfo', 'detail' )
      done()
    } )

    it( 'should include statusCode', function ( done ) {
      expect( error.statusCode ).to.equal( 500 )
      done()
    } )

    it( 'should include details from Document Service', function ( done ) {
      expect( error.detail ).to.have.all.keys( 'code', 'message' )
      expect( error.detail.code ).to.equal( 'INVALID_AUTHORIZATION' )
      done()
    } )

    it( 'should parse out DES error code', function () {
      let error = new Error( 'document', {
        detail: {
          message: 'Error from DES : HttpStatusCode : 422 DESErrorCode :12007 Category : PES Message :PES error DetailedMessage :PDF Extraction Service exception: HTTP Response Error, responseCode="501" responseMsg="Not Implemented" errorCode="2007" message="Extraction Failed" detailMessage="Document does not contain any readable data"' }
      }, req.headers, res.statusCode)

      expect( error.detail.desErrorCode ).to.equal('12007')
    })

    it( 'should not include DES error code if parse error', function () {
      let error = new Error( 'document', {
        detail: {
          message: 'Error from DES : HttpStatusCode : 422 DESErrorCode :forsomereasonbad Category : PES Message :PES error DetailedMessage :PDF Extraction Service exception: HTTP Response Error, responseCode="501" responseMsg="Not Implemented" errorCode="2007" message="Extraction Failed" detailMessage="Document does not contain any readable data"' }
      }, req.headers, res.statusCode)

      expect( error.detail.desErrorCode ).to.equal(undefined)
    })

  })

  describe('Error sent from credentials', function () {
    let req = {
      headers: {
        intuit_tid: 'TEST_INTUIT_TID'
      }
    }
    let res = {
      statusCode: 500
    }

    let error = new Error ( 'credentials', CREDENTIALS, req.headers, res.statusCode )

    it( 'should inclue a standard response', function ( done ) {
      expect( error ).to.have.all.keys( 'statusCode', 'code' , 'type', 'category', 'message', 'intuit_tid', 'moreInfo', 'detail' )
      done()
    } )

    it( 'should include statusCode', function ( done ) {
      expect( error.statusCode ).to.equal( 500 )
      done()
    } )

    it( 'should include details from Credential Service', function ( done ) {
      expect( error.detail ).to.have.all.keys( 'code', 'message' )
      expect( error.detail.code ).to.equal( 'request.body.field' )
      done()
    } )

  })

  describe('Error sent from AVS', function () {

    describe('general Error sent from AVS', function () {
      let req = {
        headers: {
          intuit_tid: 'TEST_INTUIT_TID'
        }
      }
      let res = {
        statusCode: 500
      }

      let INTERACTION_COPY = Object.assign({}, INTERACTION)
      INTERACTION_COPY.errors[0].code = 'AVS-10100000'

      let error = new Error ( 'interaction', INTERACTION_COPY, req.headers, res.statusCode )

      it( 'should inclue a standard response', function ( done ) {
        expect( error ).to.have.all.keys( 'statusCode', 'code' , 'type', 'category', 'message', 'intuit_tid', 'moreInfo', 'detail' )
        done()
      } )

      it( 'should default to vault error code FDPVLT-4000', function ( done ) {
        expect( error.code ).to.equal( 'FDPVLT-4000' )
        done()
      } )

      it( 'should inclue an intuit_tid', function ( done ) {
        expect( error.intuit_tid ).to.equal( req.headers.intuit_tid )
        done()
      } )

      it( 'should inclue a standard detail shape plus more', function ( done ) {
        expect( error.detail ).to.have.all.keys( 'code', 'message', 'authType', 'errorType' )
        done()
      } )

      it( 'should include statusCode', function ( done ) {
        expect( error.statusCode ).to.equal( 500 )
        done()
      } )

      it( `should include code: ${INTERACTION_COPY.errors[0].code} from Access Service`, function ( done ) {
        expect( error.detail.code ).to.equal( 'AVS-10100000' )
        done()
      } )

    })

    describe('loginCredentialsInvalid Error sent from AVS', function () {
      let req = {
        headers: {
          intuit_tid: 'TEST_INTUIT_TID'
        }
      }
      let res = {
        statusCode: 500
      }

      let INTERACTION_COPY = Object.assign({}, INTERACTION)
      INTERACTION_COPY.errors[0].code = 'AVS-103'

      let error = new Error ( 'interaction', INTERACTION_COPY, req.headers, res.statusCode )

      it( 'should inclue a standard response', function ( done ) {
        expect( error ).to.have.all.keys( 'statusCode', 'code' , 'type', 'category', 'message', 'intuit_tid', 'moreInfo', 'detail' )
        done()
      } )

      it( 'should default to vault error code FDPVLT-4002', function ( done ) {
        expect( error.code ).to.equal( 'FDPVLT-4002' )
        done()
      } )

      it( 'should inclue an intuit_tid', function ( done ) {
        expect( error.intuit_tid ).to.equal( req.headers.intuit_tid )
        done()
      } )

      it( 'should inclue a standard detail shape plus more', function ( done ) {
        expect( error.detail ).to.have.all.keys( 'code', 'message', 'authType', 'errorType' )
        done()
      } )

      it( 'should include statusCode', function ( done ) {
        expect( error.statusCode ).to.equal( 500 )
        done()
      } )

      it( `should include code: ${INTERACTION_COPY.errors[0].code} from Access Service`, function ( done ) {
        expect( error.detail.code ).to.equal( 'AVS-103' )
        done()
      } )

    })

    describe('catastrophic Error sent from AVS', function () {
      let req = {
        headers: {
          intuit_tid: 'TEST_INTUIT_TID'
        }
      }
      let res = {
        statusCode: 500
      }

      let INTERACTION_COPY = Object.assign({}, INTERACTION)
      INTERACTION_COPY.errors[0].code = 'AVS-1021'

      let error = new Error ( 'interaction', INTERACTION_COPY, req.headers, res.statusCode )

      it( 'should inclue a standard response', function ( done ) {
        expect( error ).to.have.all.keys( 'statusCode', 'code' , 'type', 'category', 'message', 'intuit_tid', 'moreInfo', 'detail' )
        done()
      } )

      it( 'should default to vault error code FDPVLT-4003', function ( done ) {
        expect( error.code ).to.equal( 'FDPVLT-4003' )
        done()
      } )

      it( 'should inclue an intuit_tid', function ( done ) {
        expect( error.intuit_tid ).to.equal( req.headers.intuit_tid )
        done()
      } )

      it( 'should inclue a standard detail shape plus more', function ( done ) {
        expect( error.detail ).to.have.all.keys( 'code', 'message', 'authType', 'errorType' )
        done()
      } )

      it( 'should include statusCode', function ( done ) {
        expect( error.statusCode ).to.equal( 500 )
        done()
      } )

      it( `should include code: ${INTERACTION_COPY.errors[0].code} from Access Service`, function ( done ) {
        expect( error.detail.code ).to.equal( 'AVS-1021' )
        done()
      } )

    })
    describe('transient Error sent from AVS', function () {
      let req = {
        headers: {
          intuit_tid: 'TEST_INTUIT_TID'
        }
      }
      let res = {
        statusCode: 500
      }

      let INTERACTION_COPY = Object.assign({}, INTERACTION)
      INTERACTION_COPY.errors[0].code = 'AVS-2302'

      let error = new Error ( 'interaction', INTERACTION_COPY, req.headers, res.statusCode )

      it( 'should inclue a standard response', function ( done ) {
        expect( error ).to.have.all.keys( 'statusCode', 'code' , 'type', 'category', 'message', 'intuit_tid', 'moreInfo', 'detail' )
        done()
      } )

      it( 'should default to vault error code FDPVLT-4005', function ( done ) {
        expect( error.code ).to.equal( 'FDPVLT-4005' )
        done()
      } )

      it( 'should inclue an intuit_tid', function ( done ) {
        expect( error.intuit_tid ).to.equal( req.headers.intuit_tid )
        done()
      } )

      it( 'should inclue a standard detail shape plus more', function ( done ) {
        expect( error.detail ).to.have.all.keys( 'code', 'message', 'authType', 'errorType' )
        done()
      } )

      it( 'should include statusCode', function ( done ) {
        expect( error.statusCode ).to.equal( 500 )
        done()
      } )

      it( `should include code: ${INTERACTION_COPY.errors[0].code} from Access Service`, function ( done ) {
        expect( error.detail.code ).to.equal( 'AVS-2302' )
        done()
      } )

    })
    describe('mfa Error sent from AVS', function () {
      let req = {
        headers: {
          intuit_tid: 'TEST_INTUIT_TID'
        }
      }
      let res = {
        statusCode: 500
      }

      let INTERACTION_COPY = Object.assign({}, INTERACTION)
      INTERACTION_COPY.errors[0].code = 'AVS-185'

      let error = new Error ( 'interaction', INTERACTION_COPY, req.headers, res.statusCode )

      it( 'should inclue a standard response', function ( done ) {
        expect( error ).to.have.all.keys( 'statusCode', 'code' , 'type', 'category', 'message', 'intuit_tid', 'moreInfo', 'detail' )
        done()
      } )

      it( 'should default to vault error code FDPVLT-4006', function ( done ) {
        expect( error.code ).to.equal( 'FDPVLT-4006' )
        done()
      } )

      it( 'should inclue an intuit_tid', function ( done ) {
        expect( error.intuit_tid ).to.equal( req.headers.intuit_tid )
        done()
      } )

      it( 'should inclue a standard detail shape plus more', function ( done ) {
        expect( error.detail ).to.have.all.keys( 'code', 'message', 'authType', 'errorType' )
        done()
      } )

      it( 'should include statusCode', function ( done ) {
        expect( error.statusCode ).to.equal( 500 )
        done()
      } )

      it( `should include code: ${INTERACTION_COPY.errors[0].code} from Access Service`, function ( done ) {
        expect( error.detail.code ).to.equal( 'AVS-185' )
        done()
      } )

    })

  })


})
