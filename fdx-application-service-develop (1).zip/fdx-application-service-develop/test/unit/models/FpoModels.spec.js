import { expect } from 'chai'

import {
  FpoAcquireModel,
  FpoMfaModel,
  FpoRefreshModel,
  FpoEditCredentialsModel
} from '../../../models/accounts/fpo-request-model'

import {
  AcquireModelOld as AcquireModel
} from '../../../models/acquire/acquire-request-model.old'

import MfaSessionModel from '../../../models/accounts/mfa-session-model'
import MigrationModel from '../../../models/accounts/migration-model'

import { acquireAccounts, acquireTransactions, acquireDocuments, mfa, refresh, edit, acquireOauthMigration } from './mocks/fpo.js'

const IS_ASYNC = true

let acquireAccountsModel = AcquireModel( acquireAccounts(), IS_ASYNC )
let acquireTransactionsModel = AcquireModel( acquireTransactions(), IS_ASYNC )
let acquireDocumentsModel = AcquireModel( acquireDocuments(), IS_ASYNC )
let mfaModel = new FpoMfaModel( mfa(), IS_ASYNC )
let refreshModel = new FpoRefreshModel( refresh(), IS_ASYNC )
let editModel = new FpoEditCredentialsModel( edit(), IS_ASYNC )
let acquireOauthMigrationModel = new FpoAcquireModel( acquireOauthMigration(), IS_ASYNC )

import * as providers from './mocks/mfa-response.json'
const MFA_MODEL = new MfaSessionModel( providers[ 0 ], 'responseParams.mfaSession' )

import migrationModel from './mocks/fdms-migration-response'
let MIGRATION_MODEL = new MigrationModel( migrationModel() )

describe('FPO Request Models', function () {

  describe('Acquire Accounts Model', function () {
    it('should have the proper structure', function (done) {

      expect(acquireAccountsModel.providers).to.have.lengthOf(1)
      expect(acquireAccountsModel.providers[0].credentialSets).to.have.lengthOf(1)
      expect(acquireAccountsModel.providers[0].credentialSets[0].channelId).to.be.defined
      expect(acquireAccountsModel.providers[0].credentialSets[0].credentials).to.have.lengthOf(2)
      expect(acquireAccountsModel.requestParams.selectors).to.not.have.key('documentSelector')
      expect(acquireAccountsModel.requestParams.selectors).to.have.key('accountSelector')
      expect(acquireAccountsModel.requestParams.selectors).to.not.have.key('transactionSelector')
      expect(acquireAccountsModel.requestParams.bypassAccountsValidation).to.be.undefined
      done()
    })
  })

  describe('Acquire Transactions Model', function () {
    it('should have the proper structure', function (done) {
      expect(acquireTransactionsModel.providers).to.have.lengthOf(1)
      expect(acquireTransactionsModel.providers[0].credentialSets).to.have.lengthOf(1)
      expect(acquireTransactionsModel.providers[0].credentialSets[0].channelId).to.be.defined
      expect(acquireTransactionsModel.providers[0].credentialSets[0].credentials).to.have.lengthOf(2)
      expect(acquireTransactionsModel.requestParams.selectors).to.not.have.key('documentSelector')
      expect(acquireTransactionsModel.requestParams.selectors).to.have.keys('accountSelector', 'transactionSelector')
      expect(acquireTransactionsModel.requestParams.bypassAccountsValidation).to.be.undefined
      done()
    })
  })

  describe('Acquire Documents Model', function () {
    it('should have the proper structure', function (done) {
      expect(acquireDocumentsModel.providers).to.have.lengthOf(1)
      expect(acquireDocumentsModel.providers[0].credentialSets).to.have.lengthOf(1)
      expect(acquireDocumentsModel.providers[0].credentialSets[0].channelId).to.be.defined
      expect(acquireDocumentsModel.providers[0].credentialSets[0].credentials).to.have.lengthOf(2)
      expect(acquireDocumentsModel.requestParams.selectors).to.have.key('documentSelector')
      expect(acquireDocumentsModel.requestParams.selectors).to.not.have.key('accountSelector')
      expect(acquireDocumentsModel.requestParams.selectors).to.not.have.key('transactionSelector')
      expect(acquireDocumentsModel.requestParams.bypassAccountsValidation).to.be.undefined
      done()
    })
  })

  describe('MFA Model', function () {
    it('should have the proper structure', function (done) {
      expect(mfaModel.providers).to.have.lengthOf(1)
      expect(mfaModel.providers[0].credentialSets).to.have.lengthOf(1)
      expect(mfaModel.providers[0].credentialSets[0].credentialSetId).to.be.defined
      expect(mfaModel.providers[0].credentialSets[0].credentials).to.have.lengthOf(2)
      expect(mfaModel.providers[0].credentialSets[0].credentials[0].authenticationFieldType).to.equal('MFAText')
      expect(mfaModel.requestParams.mfaSession).to.be.defined
      expect(mfaModel.requestParams.bypassAccountsValidation).to.be.undefined
      expect(mfaModel.requestParams.bypassAccountsValidation).to.be.undefined
      done()
    })
  })

  describe('Refresh Model', function () {
    it('should have the proper structure', function (done) {
      expect(refreshModel.providers).to.have.lengthOf(1)
      expect(refreshModel.providers[0].credentialSets).to.have.lengthOf(2)
      expect(refreshModel.providers[0].credentialSets[0].credentialSetId).to.be.defined
      expect(refreshModel.requestParams.selectors.transactionSelector).to.be.defined
      expect(refreshModel.requestParams.selectors.transactionSelector.dateRange.startDate).to.be.defined
      expect(refreshModel.requestParams.selectors.transactionSelector.dateRange.endDate).to.be.defined
      expect(refreshModel.requestParams.selectors.accountSelector).to.be.defined
      expect(refreshModel.requestParams.bypassAccountsValidation).to.be.undefined
      done()
    })
  })

  describe('Edit Credentials Model', function () {
    it('should have the proper structure', function (done) {
      expect(editModel.providers).to.be.defined
      expect(editModel.providers[0].credentialSets[0].credentialSetId).to.be.defined
      expect(editModel.providers[0].credentialSets[0].credentials).to.have.lengthOf(2)
      expect(editModel.requestParams.selectors.transactionSelector).to.be.undefined
      expect(editModel.requestParams.selectors.accountSelector).to.be.defined
      expect(editModel.requestParams.bypassAccountsValidation).to.be.defined
      done()
    })
  })

  describe('MFA Request Model', function () {
    it('should have the proper structure', function (done) {
      expect(MFA_MODEL.mfaSession).to.be.defined
      expect(MFA_MODEL.providerId).to.be.defined
      expect(MFA_MODEL.credentialSetId).to.be.defined
      expect(MFA_MODEL.authFieldnMapping).to.be.an('array')
      expect(MFA_MODEL.authFieldnMapping[0].captchaImage).to.be.a('string')
      done()
    })
  })

  describe('Acquire Oauth Migration Model', function () {
    it('should have the proper structure', function (done) {
      expect(acquireOauthMigrationModel.providers).to.have.lengthOf(1)
      expect(acquireOauthMigrationModel.providers[0].credentialSets).to.have.lengthOf(1)
      expect(acquireOauthMigrationModel.providers[0].credentialSets[0].channelId).to.be.defined
      expect(acquireOauthMigrationModel.providers[0].credentialSets[0].type).to.equal('OAuth')
      expect(acquireOauthMigrationModel.providers[0].credentialSets[0].migration).to.be.defined
      expect(acquireOauthMigrationModel.providers[0].credentialSets[0].migration.migrationId).to.be.defined
      expect(acquireOauthMigrationModel.providers[0].credentialSets[0].migration.migrationId).to.be.a('string')
      expect(acquireOauthMigrationModel.providers[0].credentialSets[0].migration.sourceCredentialSetId).to.be.defined
      expect(acquireOauthMigrationModel.providers[0].credentialSets[0].migration.sourceCredentialSetId).to.be.a('string')
      done()
    })
  })

  describe('FDMS OAuth Migration Response Model', function () {
    it('should have the proper structure', function (done) {
      expect(MIGRATION_MODEL.providerId).to.be.defined
      expect(MIGRATION_MODEL.credentialSetId).to.be.defined
      expect(MIGRATION_MODEL.migrationDetails).to.be.an('object')
      expect(MIGRATION_MODEL.fdmsMigrationResponseDetails).to.be.an('object')
      expect(MIGRATION_MODEL.fdmsMigrationResponseDetails.code).to.equal('FDP-6601')
      done()
    })
  })
})
