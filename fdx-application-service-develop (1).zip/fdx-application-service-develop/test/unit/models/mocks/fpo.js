

function acquireAccounts () {
  return {
    "recaptcha": "03AOmkcwKnrIQTdndGnAef8WkEFB4LOC9rPuQI2MLNfO15ewuy20TsYIY0KnKTHZBr1hi39h2-5RlAF3A9pzJoErQ1H5OAXuKOcCJjdSdySQ-iclEf93ZJcz1_7DpKlQ2IuA2oeVtJEKxxLSLPiV4k6I2yhcYsGGXuOwrH3l_JKXX_uUIj2J22wlB0i_nXq3EQdJcu9echcO9dwc_XOSepUWd3s3MB0vXpgHIdCM7RVqZkO5g94MWLga8uwjBVbI1d_828pJLangZk1SAKo5hz1qaO5n0Piv5qUUuycosxvKpA3SFSN_mQJgYY0Kp2eGZmgHIrskJl7696",
    "sync": false,
    "providerId": "90aec3e4-0d85-45fa-8a1b-b2ce655d6705",
    "channelId": "fbb3afd9-ebe7-411c-a1b8-f9d2ea67a970",
    "compliance": {
      "is7216": true
    },
    "credentials": [{
      "id": "2ef8bcbd-db65-46e0-9f6f-2227aff8faae",
      "value": "fdxtest",
      "hideChars": false,
      "encrypted": false,
      "text": "user_login",
      "optional": false
    }, {
      "id": "0bbcd4c6-52e4-42a4-9e23-ceeb1dd6883b",
      "value": "472e5f0a014a8cb1fe9151b4905da1cd8c35f11060028f9de2469bcd1b69c77756488be946b4069d6723ef7f05e18e4ffa9148242de8cfde8cf429eac7013316715623551225bc904d79f2eed47afecb2b725059337cfb34566b5790e13d180f4b73ead6b4ae6a554222aa79e29fea4d3a7b36f3d2009512e24dada9fa6d58bdf34cae43319021480d3a819e90872e929815285ef422be0fc1e4e16718df913217e783c6f8f89342b75c540a031d274f0ff7a579860c36db04c390a1b7484fbac754390ab0a3cc7ce69c96dd53cf1dfdd9e996af2525218dda1b2a04ed33e7d3d170a2a5b8ab6bce53137fecd0f6259f5a10163bbbd47697df81ecf5a64979c8",
      "hideChars": true,
      "encrypted": true,
      "text": "user_password",
      "optional": false,
      "certVersion": "v02.credserv.crypt.nonprod.key.corp.intuit.net"
    }],
    "isRealmContext": false,
    "addPiiToProfile": false,
    "acquireContext": ["accounts"]
  }
}

function refreshAccounts () {
  return {
    "sync": false,
    "providerId": "90aec3e4-0d85-45fa-8a1b-b2ce655d6705",
    "credentialSetIds": ["a14ccb31-ee05-415d-8b46-311a61c3cf85"],
    "accountList": [{
      "accountId": "urn:account:fdp::accountid:6cf73d60-bb36-11e7-b1b6-061b934c2838"
    }],
    "isRealmContext": false
  }
}

function acquireTransactions () {
  return {
    "recaptcha": "03AOmkcwKnrIQTdndGnAef8WkEFB4LOC9rPuQI2MLNfO15ewuy20TsYIY0KnKTHZBr1hi39h2-5RlAF3A9pzJoErQ1H5OAXuKOcCJjdSdySQ-iclEf93ZJcz1_7DpKlQ2IuA2oeVtJEKxxLSLPiV4k6I2yhcYsGGXuOwrH3l_JKXX_uUIj2J22wlB0i_nXq3EQdJcu9echcO9dwc_XOSepUWd3s3MB0vXpgHIdCM7RVqZkO5g94MWLga8uwjBVbI1d_828pJLangZk1SAKo5hz1qaO5n0Piv5qUUuycosxvKpA3SFSN_mQJgYY0Kp2eGZmgHIrskJl7696",
    "sync": false,
    "providerId": "90aec3e4-0d85-45fa-8a1b-b2ce655d6705",
    "channelId": "fbb3afd9-ebe7-411c-a1b8-f9d2ea67a970",
    "compliance": {
      "is7216": true
    },
    "credentials": [{
      "id": "2ef8bcbd-db65-46e0-9f6f-2227aff8faae",
      "value": "fdxtest",
      "hideChars": false,
      "encrypted": false,
      "text": "user_login",
      "optional": false
    }, {
      "id": "0bbcd4c6-52e4-42a4-9e23-ceeb1dd6883b",
      "value": "472e5f0a014a8cb1fe9151b4905da1cd8c35f11060028f9de2469bcd1b69c77756488be946b4069d6723ef7f05e18e4ffa9148242de8cfde8cf429eac7013316715623551225bc904d79f2eed47afecb2b725059337cfb34566b5790e13d180f4b73ead6b4ae6a554222aa79e29fea4d3a7b36f3d2009512e24dada9fa6d58bdf34cae43319021480d3a819e90872e929815285ef422be0fc1e4e16718df913217e783c6f8f89342b75c540a031d274f0ff7a579860c36db04c390a1b7484fbac754390ab0a3cc7ce69c96dd53cf1dfdd9e996af2525218dda1b2a04ed33e7d3d170a2a5b8ab6bce53137fecd0f6259f5a10163bbbd47697df81ecf5a64979c8",
      "hideChars": true,
      "encrypted": true,
      "text": "user_password",
      "optional": false,
      "certVersion": "v02.credserv.crypt.nonprod.key.corp.intuit.net"
    }],
    "isRealmContext": false,
    "addPiiToProfile": false,
    "acquireContext": ["transactions"]
  }
}

function acquireDocuments() {
  return {
    "recaptcha": "03AOmkcwKnrIQTdndGnAef8WkEFB4LOC9rPuQI2MLNfO15ewuy20TsYIY0KnKTHZBr1hi39h2-5RlAF3A9pzJoErQ1H5OAXuKOcCJjdSdySQ-iclEf93ZJcz1_7DpKlQ2IuA2oeVtJEKxxLSLPiV4k6I2yhcYsGGXuOwrH3l_JKXX_uUIj2J22wlB0i_nXq3EQdJcu9echcO9dwc_XOSepUWd3s3MB0vXpgHIdCM7RVqZkO5g94MWLga8uwjBVbI1d_828pJLangZk1SAKo5hz1qaO5n0Piv5qUUuycosxvKpA3SFSN_mQJgYY0Kp2eGZmgHIrskJl7696",
    "sync": false,
    "providerId": "90aec3e4-0d85-45fa-8a1b-b2ce655d6705",
    "channelId": "fbb3afd9-ebe7-411c-a1b8-f9d2ea67a970",
    "compliance": {
      "is7216": true
    },
    "credentials": [{
      "id": "2ef8bcbd-db65-46e0-9f6f-2227aff8faae",
      "value": "fdxtest",
      "hideChars": false,
      "encrypted": false,
      "text": "user_login",
      "optional": false
    }, {
      "id": "0bbcd4c6-52e4-42a4-9e23-ceeb1dd6883b",
      "value": "472e5f0a014a8cb1fe9151b4905da1cd8c35f11060028f9de2469bcd1b69c77756488be946b4069d6723ef7f05e18e4ffa9148242de8cfde8cf429eac7013316715623551225bc904d79f2eed47afecb2b725059337cfb34566b5790e13d180f4b73ead6b4ae6a554222aa79e29fea4d3a7b36f3d2009512e24dada9fa6d58bdf34cae43319021480d3a819e90872e929815285ef422be0fc1e4e16718df913217e783c6f8f89342b75c540a031d274f0ff7a579860c36db04c390a1b7484fbac754390ab0a3cc7ce69c96dd53cf1dfdd9e996af2525218dda1b2a04ed33e7d3d170a2a5b8ab6bce53137fecd0f6259f5a10163bbbd47697df81ecf5a64979c8",
      "hideChars": true,
      "encrypted": true,
      "text": "user_password",
      "optional": false,
      "certVersion": "v02.credserv.crypt.nonprod.key.corp.intuit.net"
    }],
    "isRealmContext": false,
    "addPiiToProfile": false,
    "acquireContext": ["documents"]
  }
}


function mfa () {
  return {
    "sync":false,
    "providerId": "862ccdd4-5e8e-4238-be44-f1e84e12b017",
    "credentialSetId": "d6c782a9-56b5-4a30-9f8b-291d425bdacd",
    "mfaSession": "WWpJNU1UZGlaVFF0TkdKa1pDMDBNR1ExTFRreU9EQXRNR1UyTXpRMk9EWTJNVE0yT2xNdlJ6SllZMnhzV2tjclJVUnVaWHBKYTNoWmJEbGxjbVZzY2xJMlVYTXZSSGRuYWtSS1kyZEtOWE05",
    "credentials": [{
      "id": "d6c782a9-56b5-4a30-9f8b-291d425bdacd",
      "value": "5522c693c321258093af7e1216e3fa99008087a866a7de18dead522b1d8690cc172a364e50bb1ea324a68ebbf8947023020675616d39719b8980db0b0ca41523d7151b98ca2f858e3e73aa4eb9844d13dd6e332fd5761b7c84df5e3972b6b0658116b22d4b2ff609735c2dff8c7716dddb0c39b7ac8f6c7a16e4a859c022b39ec57f6c7f01d0e998b5fb3de8c6e4646577ac44d2b6e8b258e4907e418d28a3d29053ab2ea6a6a0ead4bba0e60cfcab09d7a70ca2bcf477f476a50c7727574d046f2c4f6757816da680d21d68975fdbf96a551c6f216100517c34fdd766e749b13645715c27f1cb0b2b7bcf0730ed1c253dbc4daf49b587e82e6d8597809887dd",
      "text": "Who is your favorite sportsman?",
      "type" : "MFAText",
      "encrypted": true,
      "certVersion": "v01_credential_service_cryption_nonprod_key.corp.intuit.net"
    }, {
      "id": "ea5cd09e-a170-468e-a1d9-e6b76c574f3c",
      "value": "5522c693c321258093af7e1216e3fa99008087a866a7de18dead522b1d8690cc172a364e50bb1ea324a68ebbf8947023020675616d39719b8980db0b0ca41523d7151b98ca2f858e3e73aa4eb9844d13dd6e332fd5761b7c84df5e3972b6b0658116b22d4b2ff609735c2dff8c7716dddb0c39b7ac8f6c7a16e4a859c022b39ec57f6c7f01d0e998b5fb3de8c6e4646577ac44d2b6e8b258e4907e418d28a3d29053ab2ea6a6a0ead4bba0e60cfcab09d7a70ca2bcf477f476a50c7727574d046f2c4f6757816da680d21d68975fdbf96a551c6f216100517c34fdd766e749b13645715c27f1cb0b2b7bcf0730ed1c253dbc4daf49b587e82e6d8597809887dd",
      "text": "What is your favorite movie?",
      "type" : "MFAText",
      "encrypted": true,
      "certVersion": "v01_credential_service_cryption_nonprod_key.corp.intuit.net"
    }]
  }
}

function refresh () {
  return {
    "sync":false,
    "providerId": "862ccdd4-5e8e-4238-be44-f1e84e12b017",
    "dateRange": {
      "startDate": '01/01/2016',
      "endDate": '12/01/2016'
    },
    "credentialSetIds": [
      "d6c782a9-56b5-4a30-9f8b-291d425bdacd",
      "ea5cd09e-a170-468e-a1d9-e6b76c574f3c"
    ]
  }
}

function edit () {
  return {
    "sync": true,
    "providerId": "90aec3e4-0d85-45fa-8a1b-b2ce655d6705",
    "credentialSetId": "ee964e85-afef-4f57-9838-5c5334bc2f68",
    "credentials": [{
      "id": "2ef8bcbd-db65-46e0-9f6f-2227aff8faae",
      "value": "5522c693c321258093af7e1216e3fa99008087a866a7de18dead522b1d8690cc172a364e50bb1ea324a68ebbf8947023020675616d39719b8980db0b0ca41523d7151b98ca2f858e3e73aa4eb9844d13dd6e332fd5761b7c84df5e3972b6b0658116b22d4b2ff609735c2dff8c7716dddb0c39b7ac8f6c7a16e4a859c022b39ec57f6c7f01d0e998b5fb3de8c6e4646577ac44d2b6e8b258e4907e418d28a3d29053ab2ea6a6a0ead4bba0e60cfcab09d7a70ca2bcf477f476a50c7727574d046f2c4f6757816da680d21d68975fdbf96a551c6f216100517c34fdd766e749b13645715c27f1cb0b2b7bcf0730ed1c253dbc4daf49b587e82e6d8597809887dd",
      "hideChars": true,
      "encrypted": true,
      "text": "user_login"
    }, {
      "id": "0bbcd4c6-52e4-42a4-9e23-ceeb1dd6883b",
      "value": "5522c693c321258093af7e1216e3fa99008087a866a7de18dead522b1d8690cc172a364e50bb1ea324a68ebbf8947023020675616d39719b8980db0b0ca41523d7151b98ca2f858e3e73aa4eb9844d13dd6e332fd5761b7c84df5e3972b6b0658116b22d4b2ff609735c2dff8c7716dddb0c39b7ac8f6c7a16e4a859c022b39ec57f6c7f01d0e998b5fb3de8c6e4646577ac44d2b6e8b258e4907e418d28a3d29053ab2ea6a6a0ead4bba0e60cfcab09d7a70ca2bcf477f476a50c7727574d046f2c4f6757816da680d21d68975fdbf96a551c6f216100517c34fdd766e749b13645715c27f1cb0b2b7bcf0730ed1c253dbc4daf49b587e82e6d8597809887dd",
      "hideChars": true,
      "encrypted": true,
      "text": "user_password"
    }]
  }
}

function acquireOauthMigration () {
  return {
    "sync":false,
    "providerId": "862ccdd4-5e8e-4238-be44-f1e84e12b017",
    "channelId": "9b391749-1297-461d-92d4-a176b5bf5184",
    "credentials": [{
      "id": "d6c782a9-56b5-4a30-9f8b-291d425bdacd",
      "value": "sdfsdfs",
      "hideChars": false,
      "encrypted": false,
      "text": "Email Address"
    }, {
      "id": "ea5cd09e-a170-468e-a1d9-e6b76c574f3c",
      "value": "5522c693c321258093af7e1216e3fa99008087a866a7de18dead522b1d8690cc172a364e50bb1ea324a68ebbf8947023020675616d39719b8980db0b0ca41523d7151b98ca2f858e3e73aa4eb9844d13dd6e332fd5761b7c84df5e3972b6b0658116b22d4b2ff609735c2dff8c7716dddb0c39b7ac8f6c7a16e4a859c022b39ec57f6c7f01d0e998b5fb3de8c6e4646577ac44d2b6e8b258e4907e418d28a3d29053ab2ea6a6a0ead4bba0e60cfcab09d7a70ca2bcf477f476a50c7727574d046f2c4f6757816da680d21d68975fdbf96a551c6f216100517c34fdd766e749b13645715c27f1cb0b2b7bcf0730ed1c253dbc4daf49b587e82e6d8597809887dd",
      "hideChars": true,
      "encrypted": true,
      "text": "Password",
      "certVersion": "v01_credential_service_cryption_nonprod_key.corp.intuit.net"
    }],
    "authType": "OAuth",
    "migrationId": "479",
    "sourceCredentialSetId": "e1d97121-314f-496e-9596-466b445aa4a7"
  }
}

exports.acquireAccounts = acquireAccounts
exports.refreshAccounts = refreshAccounts
exports.acquireTransactions = acquireTransactions
exports.acquireDocuments = acquireDocuments
exports.mfa = mfa
exports.refresh = refresh
exports.edit = edit
exports.acquireOauthMigration = acquireOauthMigration
