export default function migrationModel () {
  return {
    "providers": [
      {
        "credentialSets": [
          {
            "credentialSetId": "6b7e6f31-b8eb-4565-a29d-548397acc437",
            "migration": {
              "migrationId": "1855",
              "sourceCredentialSetId": "09058be0-eaf4-468e-b4ce-bb996c868020"
            },
            "type": "OAuth"
          }
        ],
        "providerId": "02ec456f-8df2-459d-9932-2afe549be5c5",
        "bankTransferRoutingInfos": []
      }
    ],
    "responseParams": {
      "dateRange": {
        "endDate": "2017-09-27T00:00:00Z",
        "startDate": "2017-09-27T00:00:00Z"
      }
    },
    "errors": [
      {
        "code": "FDP-6601",
        "message": "Migration is not in 'COMPLETED' state. status=null",
        "moreInfo": "https://wiki.intuit.com/display/FICDS/FDP+Error+Code+Catalogue",
        "type": "CLIENT"
      }
    ]
  }
}
