
import {
    expect
} from 'chai'
import sinon from 'sinon'
import ProviderDetail from '../../../models/providers/ProviderDetail'

let providerDetailMock = require('./mocks/ProviderDetail.mock.json')
let billerDetailMock = require('./mocks/BillerDetail.mock.json')
let oauthProviderDetailMock = require('./mocks/OauthProviderDetail.mock.json')

describe('ProviderDetail Model', function () {

  describe('Availability Dates', function () {

    describe('Now is after December 1st', function () {
      sinon.useFakeTimers(new Date(2016, 11, 1).getTime())
      const MODEL_ONE = new ProviderDetail(providerDetailMock, [ '1099-DIV' ])

      it('should return an availabilityDate if availabilityDate is after December 1st', function (done) {
        expect(MODEL_ONE.services[0].availabilityDate).to.be.defined
        expect(new Date(MODEL_ONE.services[0].availabilityDate).getMonth()).to.equal(2)
        expect(new Date(MODEL_ONE.services[0].availabilityDate).getDate()).to.equal(6)
        expect(new Date(MODEL_ONE.services[0].availabilityDate).getFullYear()).to.equal(2017)
        done()
      })

      it('should not return an availabilityDate if availabilityDate is before December 1st', function (done) {
        expect(MODEL_ONE.services[0].availabilityDate).to.be.defined
        expect(MODEL_ONE.services[2].availabilityDate).to.equal('')
        done()
      })
    })

    describe('Now is before December 1st', function () {
      sinon.useFakeTimers(new Date(2016, 10, 1).getTime())
      const MODEL_ONE = new ProviderDetail(providerDetailMock, [ '1099-INT' ])

      it('should not return an availabilityDate if availabilityDate is after December 1st', function (done) {
        expect(MODEL_ONE.services[0].availabilityDate).to.be.defined
        expect(MODEL_ONE.services[0].availabilityDate).to.equal('')
        done()
      })

      it('should not return an availabilityDate if availabilityDate is before December 1st', function (done) {
        expect(MODEL_ONE.services[0].availabilityDate).to.be.defined
        expect(MODEL_ONE.services[2].availabilityDate).to.equal('')
        done()
      })
    })

    describe('Now is after availabilityDate', function () {
      sinon.useFakeTimers(new Date(2018, 10, 1).getTime())
      const MODEL_ONE = new ProviderDetail(providerDetailMock)

      it('should not return an availabilityDate if availabilityDate is in the past', function (done) {
        expect(MODEL_ONE.services[0].availabilityDate).to.be.defined
        expect(MODEL_ONE.services[0].availabilityDate).to.equal('')
        done()
      })
    })

  })

  describe('Preferred Channel', function () {

    describe('Now is after December 1st', function () {
      sinon.useFakeTimers(new Date(2016, 11, 1).getTime())
      const MODEL_TWO = new ProviderDetail(providerDetailMock, [ '1099-INT' ])

      it('should return an the channel with the highest preference', function (done) {
        expect(MODEL_TWO.channelId).to.equal('correct-channel')
        done()
      })

    })

    describe('EntityType is not sent', function () {
      const MODEL_DEFAULT = new ProviderDetail(providerDetailMock)

      it('should default to highest preference and return an the channel with the highest preference', function (done) {
        expect(MODEL_DEFAULT.channelId).to.equal('highest-preference')
        done()
      })

    })

    describe('CAF supported channel', function () {

      describe('Now is after December 1st', function () {
        sinon.useFakeTimers(new Date(2016, 11, 1).getTime())
        const MODEL_CAF = new ProviderDetail(providerDetailMock)

        it('should return CAF channel with input fields', function (done) {
          expect(MODEL_CAF.caf).to.be.an('object')
          expect(MODEL_CAF.caf.inputFields).to.be.an('array')
          done()
        })
      })
    })

    describe('WebAuth supported channel', function () {

      describe('Now is after December 1st', function () {
        sinon.useFakeTimers(new Date(2016, 11, 1).getTime())
        const MODEL_WEBAUTH = new ProviderDetail(providerDetailMock)

        it('should return WebAuth channel with input fields', function (done) {
          expect(MODEL_WEBAUTH.webAuth).to.be.an('object')
          expect(MODEL_WEBAUTH.webAuth.inputFields).to.be.an('array')
          done()
        })
      })
    })
  })
})

describe('Biller ProviderDetail Model', function () {
  const MODEL_BILLER = new ProviderDetail(billerDetailMock)

  it('should not have tax year', function (done) {
    expect(MODEL_BILLER.taxYear).to.be.undefined
    done()
  })

  it('service type should be - LINKED_BILL', function (done) {
    expect(MODEL_BILLER.services[0].type).to.be.equal('LINKED_BILL')
    done()
  })
})

describe('OAuth FI Consent Level ProviderDetail Model', function () {
  const MODEL_OAUTH_CONSENT_LEVEL = new ProviderDetail(oauthProviderDetailMock)
  const { oauthConsentLevel } = MODEL_OAUTH_CONSENT_LEVEL.partnerAuth

  it('should return partnerAuth channel with oauthConsentLevel data', function (done) {
    expect(oauthConsentLevel).to.be.defined
    expect(oauthConsentLevel).to.be.an('object')
    done()
  })

  it('Consent model object should have proper structure', function (done) {
    expect(oauthConsentLevel).to.have.all.keys('FI_CONSENT_LEVEL', 'FI_ALL_ACCOUNTS_CONSENT')
    expect(oauthConsentLevel.FI_CONSENT_LEVEL).to.be.a('string')
    expect(oauthConsentLevel.FI_ALL_ACCOUNTS_CONSENT).to.be.a('boolean')
    done()
  })
})
