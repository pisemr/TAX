import { expect } from 'chai'
import { convertToKeyValue }  from '../../../lib/logger'

const nestedObject = {
  url: 'https://cool-web-app.com',
  headers: {
    accept: 'all-of-the-things',
    Authorization: 'no auth'
  },
  reqPath: '/v2/cool/route?api_key=hello&intuit_tid=there'
}

describe('convertToKeyValue method', () => {

  it('should flatten nested objects', done => {
    const flatObject = convertToKeyValue( { object: nestedObject })
    expect(flatObject).to.contain('url=https://cool-web-app.com')
    expect(flatObject).to.contain('headers.accept=all-of-the-things')
    done()
  })

  it('should flatten nested objects and exclude keys', done => {
    const flatObject = convertToKeyValue( { object: nestedObject, excludeKeys:[ 'reqPath' ] })
    expect(flatObject).to.contain('headers.accept=all-of-the-things')
    expect(flatObject).to.not.contain('reqPath')
    done()
  })

  it('should flatten nested objects and set namespace', done => {
    const flatObject = convertToKeyValue( { namespace:'remote', object: nestedObject })
    expect(flatObject).to.contain('remote.url=https://cool-web-app.com')
    expect(flatObject).to.contain('remote.headers.accept=all-of-the-things')
    done()
  })

})


