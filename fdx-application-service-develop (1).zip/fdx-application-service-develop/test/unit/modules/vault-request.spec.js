import { expect } from 'chai'
import url     from 'url'
import nock    from 'nock'
import config  from '../../../lib/config'
import request from '../../../lib/vault-request'

const HEADERS = {
  'headers': {
    'Content-Type': 'application/json',
    'Authorization': 'Intuit_IAM_Authentication intuit_appid=Intuit.platform.vaultux.vaultapplicationservice, intuit_app_secret=preprdBv92l6r1SprTQ37lrAbu1kT1Try3q06KBE ,intuit_token=V1-95-Q3xl8aebq01nv621162ol5, intuit_userid=193514366910437, intuit_realmid=50000003, intuit_token_type=IAM-Ticket',
    'intuit_tid': '586643ed-069e-40fd-8ab2-47bc376b35ba',
    'intuit_originating_assetid': '7278960489929281245',
    'intuit_offeringid': 'Intuit.tax.browserwidgets.browserwidgets',
    'intuit_originatingip': '127.0.0.1',
    'intuit_country': 'US',
    'intuit_locale': 'en_US',
    'host': 'financialdatainteraction-qal.platform.intuit.net',
    'accept': 'application/json',
    'content-length': 1021
  }
}


describe('Vault Request Module', function () {


  describe('Error', function () {

    nock('https://' + config.services.providers.root)
      .get('/' + config.services.providers.path.default)
      .query(true)
      .replyWithError({
        code    : 'ENOTFOUND',
        errno   : 'ENOTFOUND',
        syscall : 'getaddrinfo',
        hostname: 'fake.host.com',
        host    : 'fake.host.com',
        port    : 443
      })

    let _err, _response, _body

    let path    = url.format({
      protocol: 'https',
      host    : config.services.providers.root,
      pathname: config.services.providers.path.default,
      search  : config.services.providers.query.allDocTypes
    })
    let options = {
      method     : 'GET',
      url        : path,
      headers    : HEADERS,
      serviceName: 'Providers'
    }


    request(options, function (error, response, body) {
      _err      = error
      _response = response
      _body     = body
    })

    it('should tell us the type of error', function (done) {
      expect(_err.code).to.equal('FDPVLT-1002')
      expect(_err.detail.code).to.equal('ENOTFOUND')
      done()
    })

    it('should have a body object', function (done) {
      expect(_body).to.be.defined
      done()
    })

    it('should have a response with statusCode only', function (done) {
      expect(_response).to.be.an('object')
      expect(_response).to.deep.equal({ statusCode: 'none' })
      done()
    })

    it('should not have a real response', function (done) {
      expect(_response.statusCode).to.equal('none')
      done()
    })

    it('should have a message in the error object', function (done) {
      expect(_err).to.be.defined
      expect(_err.message).to.equal( 'statusCode was not available' )
      done()
    })

  })

})
