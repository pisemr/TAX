import crypt from'../../../lib/crypt'
import { expect } from 'chai'

describe('Crypt (encryption module based on pidCrypt)', function () {
  var encrypt = crypt('1099Variousv2')

  it('should not equal argument value', function (done) {
    expect(encrypt).not.to.equal('1099Variousv2')
    done()
  })

})
