import { generateUuid } from '../../../lib/uuid'
import { expect } from 'chai'

describe('Generate a specific UUID given a specific source', function () {
  let uuidSameA = generateUuid('same')
  let uuidSameB = generateUuid('same')
  let uuidDifferent = generateUuid('different')

  it('should be in UUID format', function (done) {
    expect(uuidSameA).to.match(/(\w{8})-(\w{4})-(\w{4})-(\w{4})-(\w{12})/)
    done()
  })
  
  it('should be the same UUID', function (done) {
    expect(uuidSameA).to.equal(uuidSameB)
    done()
  })

  it('should be a different UUID', function (done) {
    expect(uuidSameA).to.not.equal(uuidDifferent)
    done()
  })
})