import { expect }          from 'chai'
import conf from '../../../lib/config'
import Headers from '../../../lib/intuit-headers'
import { gateway, noGateway, gatewayBearerToken, badGuyHeaders } from '../middleware/mocks/gateway-requests'

let headers = new Headers()
let headersWithReq  = new Headers(gateway)
let headersWithBadIntent  = new Headers(badGuyHeaders)
let headersWithReqN = new Headers(noGateway)
let headersWithAuthorization = new Headers(gatewayBearerToken)

const TOKEN = 'V1-78-a3kw9g2c1s66hnxwf2jf1d'
const USER_ID = '123146009259624'
const REALM_ID = '50000003'
const AUTHORIZATION = `Intuit_IAM_Authentication intuit_appid=Intuit.platform.vaultux.vaultapplicationservice,intuit_app_secret=${conf.apiGatewayConfig.appSecret},intuit_token=${TOKEN},intuit_userid=${USER_ID},intuit_realmid=${REALM_ID},intuit_token_type=IAM-Ticket`
const AUTHORIZATION_NO_GW = `Intuit_IAM_Authentication intuit_appid=Intuit.platform.vaultux.vaultapplicationservice,intuit_app_secret=${conf.apiGatewayConfig.appSecret},intuit_token=V1-205-L3wpg5ga3axx64trbvfg6o,intuit_userid=193514366910437,intuit_realmid=1234567890,intuit_token_type=IAM-Ticket`

describe('Headers Model', function () {

  it('should exist', function (done) {
    // expect(headers).to.exist
    expect(headers.intuit_originating_assetid).to.not.be.null
    done()
  })

  it('should have default values', function (done) {
    expect(headers['Content-Type']).to.equal('application/json')
    expect(headers.Authorization).to.not.be.null
    expect(headers.intuit_originating_assetid).to.not.be.null
    expect(headers.intuit_tid).to.not.be.null
    expect(headers.intuit_offeringid).to.not.be.null
    done()
  })

  it('should default to intuit_assetid before intuit_originating_assetid', function (done) {
    expect(headersWithReq.intuit_originating_assetid).to.equal('7278960489929281245')
    done()
  })

  it('should default to intuit_originating_assetid when intuit_assetid is not available', function (done) {
    expect(headersWithReqN.intuit_originating_assetid).to.equal('12345678900987654321')
    expect(headersWithReqN.Authorization).to.equal(AUTHORIZATION_NO_GW)
    done()
  })

  it('should convert x-forwarded-for to intuit_originatingIp', function (done) {
    expect(headersWithReq.intuit_originatingip).to.equal('199.16.140.24')
    done()
  })

  it('should parse Authorization Header to get user data', function (done) {
    expect(headersWithAuthorization.Authorization).to.equal(AUTHORIZATION)
    done()
  })

  it('should strip out bad headers', function (done) {
    expect(headersWithBadIntent.intuit_test).to.be.undefined
    expect(headersWithBadIntent.bad_actor_header).to.be.undefined
    done()
  })

})
