import vaultUtils from '../../../lib/vault-utils'
import { expect } from 'chai'

const OPTIONS = {
  'normalOptions': {
    'method': 'GET',
    'url': 'https://financialprovider-e2e.platform.intuit.net/v1/providers',
    'headers': {
      'Content-Type': 'application/json',
      'Authorization': 'Intuit_IAM_Authentication intuit_appid=Intuit.platform.vaultux.vaultapplicationservice, intuit_app_secret=preprdBv92l6r1SprTQ37lrAbu1kT1Try3q06KBE ,intuit_token=V1-FAKE-TOKEN, intuit_userid=1234567890, intuit_realmid=0987654321, intuit_token_type=IAM-Ticket',
      'intuit_tid': '5c0d7d40-2b4c-4959-b8cc-73ce80965d61',
      'intuit_originating_assetid': '7278960489929281245',
      'intuit_offeringid': 'Intuit.tax.browserwidgets.browserwidgets',
      'intuit_originatingip': '127.0.0.1',
      'intuit_originalurl': 'some-website.com',
      'intuit_country': 'US',
      'intuit_locale': 'en_US'
    },
    'serviceName': 'Providers',
    'reqPath': ''
  },
  'optionsNoHeaders': {
    'method': 'GET',
    'url': 'https://financialprovider-e2e.platform.intuit.net/v1/providers',
    'serviceName': 'Providers',
    'reqPath': ''
  },
  'optionsNoAuth': {
    'method': 'GET',
    'url': 'https://financialprovider-e2e.platform.intuit.net/v1/providers',
    'headers': {
      'Content-Type': 'application/json',
      'intuit_tid': '5c0d7d40-2b4c-4959-b8cc-73ce80965d61',
      'intuit_originating_assetid': '7278960489929281245',
      'intuit_offeringid': 'Intuit.tax.browserwidgets.browserwidgets',
      'intuit_originatingip': '127.0.0.1',
      'intuit_originalurl': 'some-website.com',
      'intuit_country': 'US',
      'intuit_locale': 'en_US'
    },
    'serviceName': 'Providers',
    'reqPath': ''
  },
  'optionsNullAuth': {
    'method': 'GET',
    'url': 'https://financialprovider-e2e.platform.intuit.net/v1/providers',
    'headers': {
      'Content-Type': 'application/json',
      'Authorization': '',
      'intuit_tid': '5c0d7d40-2b4c-4959-b8cc-73ce80965d61',
      'intuit_originating_assetid': '7278960489929281245',
      'intuit_offeringid': 'Intuit.tax.browserwidgets.browserwidgets',
      'intuit_originatingip': '127.0.0.1',
      'intuit_originalurl': 'some-website.com',
      'intuit_country': 'US',
      'intuit_locale': 'en_US'
    },
    'serviceName': 'Providers',
    'reqPath': ''
  }
}

describe('Vault Utils', function () {
  it('should have properCase method', function (done) {
    expect(vaultUtils).to.respondTo('properCase')
    done()
  })

  describe('properCase method', function () {
    it('should convert "vault application service" to "Vault Application Service"', function (done) {
      let properCase = vaultUtils.properCase('vault application service')
      expect(properCase).to.equal('Vault Application Service')
      done()
    })

    it('should convert "VAULT APP SERVICE" to "Vault App Service"', function (done) {
      let properCase = vaultUtils.properCase('VAULT APP SERVICE')
      expect(properCase).to.equal('Vault App Service')
      done()
    })

    it('should convert "VauLT A..Li SER-VICE" to "Vault A..li Ser-Vice"', function (done) {
      let properCase = vaultUtils.properCase('VauLT A..Li SER-VICE')
      expect(properCase).to.equal('Vault A..li Ser-Vice')
      done()
    })

  })

  describe('stripSecretData method', function () {

    let normalOptions    = OPTIONS.normalOptions
    let optionsNoHeaders = OPTIONS.optionsNoHeaders
    let optionsNoAuth    = OPTIONS.optionsNoAuth
    let optionsNullAuth  = OPTIONS.optionsNullAuth

    it('should mask "intuit_app_secret", "intuit_token", "intuit_userid", "intuit_realmid"', function (done) {
      let optionToLog = vaultUtils.stripSecretData(normalOptions)
      expect(optionToLog.headers.Authorization).to.equal('Intuit_IAM_Authentication intuit_appid=Intuit.platform.vaultux.vaultapplicationservice,intuit_app_secret=**********,intuit_token=**********,intuit_userid=**********,intuit_realmid=**********, intuit_token_type=IAM-Ticket')
      done()
    })

    it('should not modify the original object', function (done) {      
      expect(normalOptions.headers.Authorization).to.equal('Intuit_IAM_Authentication intuit_appid=Intuit.platform.vaultux.vaultapplicationservice, intuit_app_secret=preprdBv92l6r1SprTQ37lrAbu1kT1Try3q06KBE ,intuit_token=V1-FAKE-TOKEN, intuit_userid=1234567890, intuit_realmid=0987654321, intuit_token_type=IAM-Ticket')
      done()
    })

    it('should return the same if headers are not present', function (done) {
      let optionToLog = vaultUtils.stripSecretData(optionsNoHeaders)
      expect(optionToLog).to.equal(optionsNoHeaders)
      done()
    })

    it('should return the same if headers.Authorization are not present', function (done) {
      let optionToLog = vaultUtils.stripSecretData(optionsNoAuth)
      expect(optionToLog).to.equal(optionsNoAuth)
      done()
    })

    it('should return the same if headers.Authorization is undefined', function (done) {
      let optionToLog = vaultUtils.stripSecretData(optionsNullAuth)
      expect(optionToLog).to.equal(optionsNullAuth)
      done()
    })

  })

  describe('maskQueryStringParam method', () => {
    const reqPath = '/v2/providers/recommended?country_code=US&flowId=38321940-6b0b-4b2c-bc52-77395421b49b&flow_name=AddConnection&includeSuggestions=false&intuit_apikey=preprdakyresj2seWxR9pqWKZIAx7AaW5x2Mkpbu&intuit_tid=26102293-1c75-4803-8b09-5cd59e60b0b3&limit=8&locale=en_US&recipe=qbo_topnbank&v=%222.6.0-beta-0%22'
    const justQuery = 'country_code=US&flowId=38321940-6b0b-4b2c-bc52-77395421b49b&flow_name=AddConnection&includeSuggestions=false&intuit_apikey=preprdakyresj2seWxR9pqWKZIAx7AaW5x2Mkpbu&intuit_tid=26102293-1c75-4803-8b09-5cd59e60b0b3&limit=8&locale=en_US&recipe=qbo_topnbank&v=%222.6.0-beta-0%22'
    const apiKey = 'preprdakyresj2seWxR9pqWKZIAx7AaW5x2Mkpbu'
    const flowName = 'AddConnection'
    it('should mask the param', done => {
      const maskedUrl = vaultUtils.maskQueryStringParam(reqPath)('intuit_apikey')
      expect(maskedUrl).to.not.contain(apiKey)
      done()
    })
    it('should mask the param when only params are sent', done => {
      const maskedUrl = vaultUtils.maskQueryStringParam(justQuery)('intuit_apikey')
      expect(maskedUrl).to.not.contain(apiKey)
      done()
    })
    it('should mask an array of params', done => {
      const maskedUrl = vaultUtils.maskQueryStringParam(reqPath)(['intuit_apikey', 'flow_name'])
      expect(maskedUrl).to.not.contain(apiKey)
      expect(maskedUrl).to.not.contain(flowName)
      done()
    })

  })

  describe('parseReqPath method no query params', () => {
    const reqPath = 'https://www.google.com'
    it('should mask the param', done => {
      const parsed = vaultUtils.parseReqPath(reqPath)
      expect(parsed).to.equal('')
      done()
    })
  })

  describe('parseReqPath method no query params and a ?', () => {
    const reqPath = 'https://www.google.com?'
    it('should mask the param', done => {
      const parsed = vaultUtils.parseReqPath(reqPath)
      expect(parsed).to.equal('')
      done()
    })
  })

  describe('parseReqPath method no query params an unassigned param', () => {
    const reqPath = 'https://www.google.com?service'
    it('should mask the param', done => {
      const parsed = vaultUtils.parseReqPath(reqPath)
      expect(parsed.service).to.equal(undefined)
      done()
    })
  })

  describe('parseReqPath method no query params an assigned param', () => {
    const reqPath = 'https://www.google.com?service=getthings'
    it('should mask the param', done => {
      const parsed = vaultUtils.parseReqPath(reqPath)
      expect(parsed.service).to.equal('getthings')
      done()
    })
  })

  describe('parseReqPath method no query params multiple assigned params', () => {
    const reqPath = 'https://www.google.com?service=getthings&api_key=123&foo=bar'
    it('should mask the param', done => {
      const parsed = vaultUtils.parseReqPath(reqPath)
      expect(parsed.service).to.equal('getthings')
      expect(parsed.api_key).to.equal('123')
      expect(parsed.foo).to.equal('bar')
      done()
    })
  })

})


