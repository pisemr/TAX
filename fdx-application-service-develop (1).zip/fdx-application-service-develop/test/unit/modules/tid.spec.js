import Tid    from '../../../lib/generate-tid'
import { expect } from 'chai'


describe('Generate 2 new intuit_tid', function () {
  let tidOne = new Tid()
  let tidTwo = new Tid()
  it('tidOne should not be null', function (done) {
    expect(tidOne.tid).not.to.be.null
    done()
  })

  it('tidOne should not equal tidTwo', function (done) {
    expect(tidOne.tid).to.not.equal(tidTwo.tid)
    done()
  })
})
