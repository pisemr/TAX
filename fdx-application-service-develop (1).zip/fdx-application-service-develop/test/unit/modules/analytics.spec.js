import { getQueryStringObject, getFlattenedObject } from '../../../lib/analytics'
import { expect } from 'chai'
import nock from 'nock'
import config from  '../../../lib/config'

describe('Analytics: Verify analytics request and event object', function () {

  // set up a nock to catch the analytics requests that should get sent
  // with the requests that other unit tests are making and verify the event object

  let event = {}

  nock(`https://${config.services.analytics.root}`, {allowUnmocked: true})
    .persist()
    .filteringRequestBody(function(body) {
      return '*';
    })
    .post(`/${config.services.analytics.topics.topicNon7216}`)
    .reply(function(uri, requestBody) {
      event = JSON.parse(requestBody)
   });
  
  it('should be the expected event object', function (done) {
    expect(event).to.have.all.keys({
      timestamp: null,
      tId: null,
      flowId: null,
      userId: null,
      realmId: null,
      country: null,
      locale: null,
      deviceId: null,
      originatingAssetId: null,
      originatingIp: null,
      reqService: null,
      reqMethod: null,
      reqPath: null,
      resStatusCode: null,
      authMethod: null,
      channelId: null,
      correlationId: null,
      entityTypes: null,
      error: null,
      code: null,
      flowName: null,
      legacyId: null,
      offeringId: null,
      partner_uid: null,
      providerId: null,
      recipe: null,
      nodePath: null,
      accountNumberTokenized: null,
      is7216: null,
      responseTime:  null,
      widgetAppId: null})
    done()
  })
})

describe('Analytics: Get querystring object given a url string', function () {
  let testQueryString = 'http://www.test.com?test1=test1&test2=test2&test3=test3'
  let queryStringObject = getQueryStringObject(testQueryString)
  
  it('should be a proper querystring object', function (done) {
    expect(queryStringObject).to.deep.equal({
      test1: 'test1',
      test2: 'test2',
      test3: 'test3',
    });
    done()
  })
})

describe('Analytics: Get flattened object given an object', function () {
  let testObject = {
    level1: {
      level2: {
        level3: [{
          level4: 'someValue'
        }]
      }
    }
  }
  let flattenedObject = getFlattenedObject(testObject)
  
  it('should be a flattened version of object', function (done) {
    expect(flattenedObject).to.deep.equal({
      'level4': 'someValue'
    });
    done()
  })
})