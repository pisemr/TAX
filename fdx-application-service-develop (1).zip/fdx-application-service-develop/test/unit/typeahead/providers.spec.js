
import {
    expect
} from 'chai'
import nock from 'nock'
import config from '../../../lib/config'
import cache from '../../../lib/cache'
import Request from '../../mocks/request'
import Response from '../../mocks/response'

import {
  getRecommendedProvidersCtrl
} from '../../../controllers/providers/providers-v2'

let typeaheadResponse = require('./mocks/sts-success-response')
let masResponse = require('./mocks/mas-suggestions-response')



describe('Typeahead Route', function() {

    describe('Getting', function() {

      nock('https://api-e2e-fps.preprodsts.a.intuit.com/action/v1')
          .get('/access')
          .query({
            action: 'selectsearch',
            encapjson: true,
            pretty: true,
            models: 'e_ce_fps_us_fi_na_provider_1',
            template: 'topN_providers',
            'context.region.country': 'US',
            intent: 'qbo_widget',
            prefix: '',
            zip: '',
            start: 0,
            rows: 8,
            lang: 'en',
          })
          .reply(200, typeaheadResponse)

      let options = {
        query: {
          query: '',
          limit: 8,
          recipe: 'qbo_widget'
        }
      }

      let mockResponse = new Response()
      let mockRequest = new Request(options)

        getRecommendedProvidersCtrl(mockRequest, mockResponse)

        it('should respond with 200 ok', function(done) {
            expect(mockResponse.statusCode).to.equal(200)
            done()
        })

        it('should Use LARGE Retina', function(done) {
            expect(mockResponse.response.results[0].logoUrl).to.equal('LARGE_RETINA')
            done()
        })

        it('should Use Small Retina', function(done) {
            expect(mockResponse.response.results[1].logoUrl).to.equal('SMALL_RETINA')
            done()
        })

        it('should Use Large Non-Retna', function(done) {
            expect(mockResponse.response.results[2].logoUrl).to.equal('LARGE_NON_RETINA')
            done()
        })

        it('should Use Small Non-Retna', function(done) {
            expect(mockResponse.response.results[3].logoUrl).to.equal('SMALL_NON_RETINA')
            done()
        })

        it('should Use Placeholder', function(done) {
            expect(mockResponse.response.results[4].logoUrl).to.equal('DEFAULT')
            done()
        })

        it('should Use Large Retina (No Default Listed)', function(done) {
            expect(mockResponse.response.results[5].logoUrl).to.equal('LARGE_RETINA')
            done()
        })

        it('should Use Large Non-Retna (No Default Listed)', function(done) {
            expect(mockResponse.response.results[6].logoUrl).to.equal('LARGE_NON_RETINA')
            done()
        })

        it('should Use Small Non-Retna (Default same size)', function(done) {
            expect(mockResponse.response.results[7].logoUrl).to.equal('SMALL_NON_RETINA')
            done()
        })
    })

    describe('Recommended providers', function() {

      nock('https://mintappservice-e2e.api.intuit.com/v1')
          .get('/suggestions/providers')
          .reply(200, masResponse)

        nock('https://api-e2e-fps.preprodsts.a.intuit.com/action/v1')
          .get('/access')
          .query({
            action: 'selectsearch',
            encapjson: true,
            pretty: true,
            models: 'e_ce_fps_us_fi_na_provider_1',
            template: 'topN_providers',
            'context.region.country': 'US',
            intent: 'qbo_widget',
            prefix: '',
            zip: '',
            start: 0,
            rows: 8,
            lang: 'en',
          })
          .reply(200, typeaheadResponse)

      let options = {
        query: {
          query: '',
          limit: 8,
          recipe: 'qbo_widget',
          includeSuggestions: 'true'
        }
      }

      let mockResponse = new Response()
      let mockRequest = new Request(options)

        getRecommendedProvidersCtrl(mockRequest, mockResponse)

        it('should respond with 200 ok', function(done) {
            expect(mockResponse.statusCode).to.equal(200)
            done()
        })

        it('should not have duplicate providers', function(done) {
            const ids = mockResponse.response.results.map(result=>result.id).filter(id=>id==='75f8d952-be81-4e22-951e-41b291d211f2')            
            expect(ids).to.have.lengthOf(1)
            done()
        })
    })
})
