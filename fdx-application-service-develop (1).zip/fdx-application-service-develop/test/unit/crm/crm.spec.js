import { expect } from 'chai'
import nock from 'nock'
import config from '../../../lib/config'
import Request from '../../mocks/request'
import Response from '../../mocks/response'
import {
  createCRMCaseCtrl
} from '../../../controllers/crm/crm'

const CRM_SERVICE_ROOT = config.services.crm.root
const CRM_SERVICE_PATH = config.services.crm.path
const PROTOCAL = config.services.protocal

const IUS_ROOT = config.services.ius.root
const IUS_PATH = config.services.ius.path

const crmServiceRequest = require('./mocks/crmServiceRequest.json')
const crmServiceResponse = require('./mocks/crmServiceResponse.json')
const iusServiceResponse = require('./mocks/iusUserData.json')

const options = {
  body: {
    product: "QBO", 
    reason: "No Idea about reason",
    errorCode: "1113",
    financialInstitutionId: "1112",
    customerCentralId: "1111",
    financialInstituionName: "BITE Ltd",
    timeOfError: "06-03-2015 04:34:18"
  }
}

describe(' CRM Testing Route', function() {
  describe('Creating a CRM Case Sending Successfully', function() {

    nock(`${PROTOCAL}://${CRM_SERVICE_ROOT}`)
    .post(CRM_SERVICE_PATH)
    .reply(201, crmServiceResponse)

    nock(`${PROTOCAL}://${IUS_ROOT}`)
    .get(IUS_PATH)
    .reply(200, iusServiceResponse)

    let mockResponse = new Response()
    let mockRequest = new Request(options)

    createCRMCaseCtrl(mockRequest, mockResponse)

    it('should response with 201 ok', function(done) {
      expect(mockResponse.statusCode).to.equal(201)
      done()
    })
  })
})