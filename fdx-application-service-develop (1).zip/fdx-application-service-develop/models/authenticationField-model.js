import _ from 'lodash'
import lookUpMap from '../lib/lookup-map'

const overrideLookUpForHideChars = [
  'Social Security',
  'ssn',
  'SSN'
]

function setAuthText( authMapping ) {
  //ensure something reasonable is put in authenticationText
  let authenticationText = ''
  if ( !!authMapping.authenticationText || authMapping.authenticationFieldText ) {
    authenticationText = authMapping.authenticationText || authMapping.authenticationFieldText
  } else if ( authMapping.mappingSource ) {
    authenticationText = authMapping.mappingSource
  } else if ( authMapping.mappingTarget ) {
    authenticationText = authMapping.mappingTarget[ 0 ]
  }
  return authenticationText
}

function setMapping( authMapping ) {
  let mappingSource = ''
  let mappingTarget = ''

  // Refer https://wiki.intuit.com/display/FDP/Usage+of+mapping_source+and+mapping_target for more details of handling source and target
  if ( authMapping.mappingSource ) {
    mappingSource = authMapping.mappingSource
  }

  if ( authMapping.mappingTarget ) {
    mappingTarget = authMapping.mappingTarget
  } else if ( authMapping.mappingSource ) {
    mappingTarget.push( authMapping.mappingSource )
  }

  return {
    mappingSource: mappingSource,
    mappingTarget: mappingTarget
  }
}

//hydrate from a provider as defined by the V2/provider back end service
export default class AuthenticationField {
  constructor() {
    this.id = ''
    this.authenticationText = ''
    this.mappingSource = ''
    this.mappingTarget = []
    this.hideChars = false
    this.encrypted = false
    this.isSecureField = true
    this.isTransientField = false
    this.fieldType = ''
    this.charsToStrip = ''
    this.isTransientField = false
  }

  initializeFromProviderServiceV2( authMapping ) {
    let self = this
    self.id = authMapping.id
    self.authenticationText = setAuthText( authMapping )
    self.mappingSource = setMapping( authMapping )
      .mappingSource
    self.mappingTarget = setMapping( authMapping )
      .mappingTarget

    //if auth text is specified, use it to figure out if this is a 'transient' field.. something that letious according to the document being fetched, like a 'Document ID'
    if ( self.authenticationText ) {
      let normalizedAuthText = self.authenticationText.toLowerCase()
        .trim()
      _.forEach( lookUpMap.transientAuthFields, ( value, index ) => {
        if ( normalizedAuthText.indexOf( lookUpMap.transientAuthFields[ index ].toLowerCase()
            .trim() ) > -1 ) {
          self.isTransientField = true
        }
      } )
    }

    self.charsToStrip = authMapping.stripChars
      //For MVP we get encrypted, but lower level systems don't use it yet
    if ( self.containsSSN() ) {
      self.encrypted = true
      self.hideChars = true
    } else {
      self.encrypted = self.isTrue( authMapping.encrypted )
      self.hideChars = self.isTrue( authMapping.hideChars )
    }

    self.isSecureField = self.isTrue( authMapping.encrypted )
    self.fieldType = authMapping.fieldType
  }

  initializeFromAVSMFA( authMapping ) {
    let self = this
    self.id = authMapping.authenticationFieldId
    self.authenticationText = setAuthText( authMapping )

    //if auth text is specified, use it to figure out if this is a 'transient' field.. something that letious according to the document being fetched, like a 'Document ID'
    if ( self.authenticationFieldText ) {
      let normalizedAuthText = self.authenticationFieldText.toLowerCase()
        .trim()
      _.forEach( lookUpMap.transientAuthFields, ( value, index ) => {
        if ( normalizedAuthText.indexOf( lookUpMap.transientAuthFields[ index ].toLowerCase()
            .trim() ) > -1 ) {
          self.isTransientField = true
        }
      } )
    }

    self.charsToStrip = authMapping.stripChars || ''
    self.hideChars = authMapping.hideChars
    self.encrypted = true
    self.isSecureField = true
    self.fieldType = authMapping.type || ''
    self.persist = authMapping.persist || ''

  }

  isTrue( val ) {
    return ( val === true || val === 'true' )
  }

  containsSSN() {
    let self = this
    let valueArray = []
    let fieldsToCheck = [
      self.mappingTarget,
      self.authenticationText,
      self.fieldType
    ]

    _.forEach( fieldsToCheck, ( fieldValue ) => {
      _.forEach( overrideLookUpForHideChars, ( value ) => {
        let includes = _.includes( fieldValue, value )
        if ( includes ) {
          valueArray.push( includes )
        }
      } )
    } )

    return _.includes( valueArray, true )
  }
}
