export class CAfForm {
  constructor( cafFormData ) {
    this.provider = {
      'credentialSet' : {
        'type' : cafFormData.type,
        'credentialSetId': cafFormData.migrationId ? null : cafFormData.credentialSetId,
        'channelId' : cafFormData.channelId,
        'compliance' : {
          'is7216' : cafFormData.is7216
        },
        'credentials' : cafFormData.formData.map(formField => {
          return {
            'authenticationFieldId' : formField.id,
            'authenticationFieldText': formField.name ? formField.name.trim() : null,
            'authenticationFieldValue': formField.value,
            'authenticationFieldType' : formField.type ? formField.type : null,
            'encrypted' : formField.encrypted
          }
        }),
        'migration' : cafFormData.migrationId ? {
          'migrationId' : cafFormData.migrationId,
          'sourceCredentialSetId': cafFormData.credentialSetId
        }: null,
        'includes': cafFormData.migrationId ? [
          {
            'type': 'Account',
            'fdpId': cafFormData.accountId
          }
        ] : null
      }
    }
  }
}
