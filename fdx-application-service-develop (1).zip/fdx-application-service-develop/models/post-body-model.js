import _ from 'lodash'

export default class PostBodyModel {
  constructor( postBody ) {
    this.postBody = postBody
    this.postData = {}
  }

  get bodyForRequest() {
    return this.postData
  }

  formatForAccounts() {
    this.postData = {
      persistenceParams: {
        persist: false
      },
      provider: {
        credentialSet: {}
      },
      requestParams: {
        async: false
      }
    }

    if ( this.postBody.persistenceParams ) {
      this.postData.persistenceParams.persist = this.postBody.persistenceParams.persist
    }
    this.postData.provider.providerId = this.postBody.providerId
    this.postData.provider.credentialSet.credentials = []

    if (this.postBody.credentials.authFields) {
      _.forEach( this.postBody.credentials.authFields,( field )=> {
        this.postData.provider.credentialSet.credentials.push( {
          type: field.type,
          authenticationFieldId: field.id,
          authenticationFieldValue: field.value,
          certVersion: this.postBody.certVersion
        } )
      } )
    }
    else {
      //authFieldsV2 as of 4/13
      _.forEach( this.postBody.credentials.authFieldsV2,( field )=> {
        this.postData.provider.credentialSet.credentials.push( {
          type: field.type,
          authenticationFieldId: field.authenticationFieldId,
          authenticationFieldValue: field.authenticationFieldValue,
          certVersion: field.certVersion
        } )
      } )
    }

  }

  formatForDocuments() {
    this.postData.credentialParams = {}
    this.postData.persistenceParams = {
      folderId: this.postBody.persistenceParams.folderId,
      persistAsync: this.postBody.persistenceParams.persistAsync
    }
    this.postData.taxYear = this.postBody.taxYear
    this.postData.is7216 = this.postBody.is7216
    this.postData.providerId = this.postBody.providerId

    if ( this.postBody.credentials.credentialSetId ) {
      this.postData.credentialParams.credentialSetId = this.postBody.credentials.credentialSetId
    }
    else if (this.postBody.credentials.authFields) {
      this.postData.credentialParams.nameValuePair = []
      this.postData.credentialParams.certVersion = this.postBody.certVersion
      _.forEach( this.postBody.credentials.authFields, ( field ) => {
        this.postData.credentialParams.nameValuePair.push( {
          name: field.id,
          value: field.value
        })
      } )
    }
    else {
      //authFieldsV2 as of 4/13
      this.postData.credentialParams.credential = []
      _.forEach( this.postBody.credentials.authFieldsV2, ( field ) => {
        this.postData.credentialParams.credential.push( {
          type: field.type,
          encrypted: field.encrypted,
          certVersion: field.certVersion,
          authenticationFieldId: field.authenticationFieldId,
          authenticationFieldValue: field.authenticationFieldValue
        } )
      } )

      //pass along ein
      if (this.postBody.ein) {
        this.postData.reportingParams = {}
        this.postData.reportingParams.ein = this.postBody.ein
      }
    }
    this.postData.entityTypes = this.postBody.entityTypes
  }

  formatMfa() {
    this.postData = {
      persistenceParams: {
        persist: false
      },
      provider: {
        credentialSet: {}
      },
      requestParams: {
        async: false,
        mfaSession: this.postBody.mfaSession
      }
    }

    if ( this.postBody.persistenceParams ) {
      this.postData.persistenceParams.persist = this.postBody.persistenceParams.persist
    }
    this.postData.provider.providerId = this.postBody.providerId
    this.postData.provider.credentialSet.credentials = []

    _.forEach( this.postBody.credentials.authFields, ( field )=> {
      this.postData.provider.credentialSet.credentials.push( {
        type: field.type,
        authenticationFieldId: field.id,
        authenticationFieldText: field.text,
        persist: true,
        certVersion: this.postBody.certVersion,
        authenticationFieldValue: field.value
      } )
    } )
  }

  formatProfileService( profileConfig ) {
    this.postData = {
      providerPreferences: []
    }

    let providerPrefObj = {}
    let credPrefObj = {}

    providerPrefObj.providerId = profileConfig.providerId

    if ( profileConfig.credSetId ) {
      providerPrefObj.credentialPreferences = []
      credPrefObj.credentialSetId = profileConfig.credSetId
      credPrefObj.documentBatchEligible = profileConfig.batchEligible
      credPrefObj.folderId = profileConfig.folderId
      if ( profileConfig.offeringPreferences ) {
        credPrefObj.offeringPreferences = profileConfig.offeringPreferences
      }
      providerPrefObj.credentialPreferences.push( credPrefObj )
    }

    this.postData.providerPreferences.push( providerPrefObj )

  }
  
  formatCRMCase(userData) {
    let contactObj = {}
    let caseDetailObj = {}

    contactObj.firstName = userData.fullName ? userData.fullName.givenName : ''
    contactObj.lastName = userData.fullName ? userData.fullName.surName : ''
    contactObj.email = userData.email ? userData.email.address : ''
    contactObj.type = ''

    caseDetailObj.customerCentralId = ''
    caseDetailObj.financialInstitutionId = this.postBody.financialInstitutionId
    caseDetailObj.financialInstituionName = this.postBody.financialInstituionName
    caseDetailObj.errorCode = this.postBody.errorCode
    caseDetailObj.timeOfError = this.postBody.timeOfError


    this.postData = {
      caseOrigin: 'In-Product',
      subject:'Customer ticket',
      product: this.postBody.product,
      description: 'Customer Escalation',
      caseOwner: this.postBody.caseOwner,
      contact: contactObj,
      caseDetail: caseDetailObj
    }
  }

  formatAccountsSearch(providerId) {
    const filters = []

    if (providerId) {
      filters.push({
        action: 'EQUAL_TO',
        field: 'providerId',
        on: 'Account',
        value: `${providerId}`        
      })
    }

    this.postData = {
      requestParams : {
        filters
      }
    }
  }

}
