
/*
  STATUS => oneOf
    INITIAL   : vary first entry into cache
    WAITING   : Waiting on a response
    RECEIVING : We recieved a response, but we know we are getting more.
    READY     : Cache is ready to send back to the client

  RESPONSE => Object
    this is the data for the most recent response

  CONNECTION_STATUS => oneOf
    ERROR   : The data cameback with an error (103. 108, ect.)
    SUCCESS : Life is good, we have success
    MFA     : The FI needed more info
    PENDING : Waiting for success or for the final segment

*/

export const CACHE_STATUS_MAP = {
  INITIAL   : 'INITIAL',
  WAITING   : 'WAITING',
  RECEIVING : 'RECEIVING',
  READY     : 'READY'
}

export const CACHE_CONNECTION_STATUS_MAP = {
  PENDING   : 'PENDING',
  SUCCESS   : 'SUCCESS',
  MFA       : 'MFA',
  RECAPTCHA : 'RECAPTCHA',
  ERROR     : 'ERROR'
}

export default class CacheModel {
  constructor({
    correlationId=null,
    cacheStatus=null,
    response=null,
    connectionStatus=null,
    segment=0,
    totalSegments=0
  }) {
    this.correlationId = correlationId
    this.cacheStatus = cacheStatus
    this.connectionStatus = connectionStatus
    this.response = response
    this.segment = segment
    this.totalSegments = totalSegments

    //deprecate ASAP
    this.status = this.cacheStatus
    this.isMfaResponse = this.connectionStatus === 'MFA'
  }

  isConnectionError() {
    return this.connectionStatus === CACHE_CONNECTION_STATUS_MAP.ERROR
  }

}
