import objectPath from 'object-path'
const ERROR_CODES = require( '@fdx/common/errors/error-mapping' )

function getError( body ) {
  return objectPath.get( body, 'errors.0', {})
}

function getFdxError( code ) {
  return ERROR_CODES.PARTNER_AUTH_ERRORS[ code ] ? ERROR_CODES.PARTNER_AUTH_ERRORS[ code ].fdp_code : 'FDPAUTH-580'
}

function parseErrorBody( body ) {
  const { code, description } = getError( body )

  return {
    code: getFdxError( code ),
    detail: description ? description : 'downstream service not availalble'
  }
}

class BaseOauth {
  constructor(txnId) {
    this.txnId = txnId
  }
}


export class OAuthInitClass extends BaseOauth {
  constructor({ txnId, offerinRedirectUrl }) {
    super( txnId )
    this.statusCode = null
    this.responseUrl = null
    this.offerinRedirectUrl = offerinRedirectUrl
    this.isError = null
    this.fdpErrorCode = null
    this.mssage = null
    this.isJson = false
  }

  setIsJson( bool ) {
    this.isJson = bool
    return this
  }

  set response( response ) {
    const {
      code,
      detail
    } = parseErrorBody(response)

    const {
      body={},
      statusCode
    } = response
    this.isError = statusCode > 399 || !!Object.keys(getError(body)) === 0
    this.providerUrl = body.uris ? body.uris [ 0 ] : null
    this.statusCode = statusCode
    this.fdpErrorCode = code
    this.message = detail

    return this
  }

  get redirectUri() {
    if ( this.isError && this.offerinRedirectUrl ) {
      return `${this.offerinRedirectUrl}?errorCode=${this.fdpErrorCode}&errorMessage=${this.mssage }&txnId=${this.txnId}`
    }

    if ( !this.isError && this.providerUrl ) {
      return `${this.providerUrl}&txnId=${this.txnId}`
    }

    return null
  }

  get response() {

    if ( this.isError ) {
      //Just return, the catch block will send the normalized JSON error
      return
    }

    if ( !this.isError && this.providerUrl ) {
      return {
        uri: this.providerUrl
      }
    }

    return null
  }
}

export class OAuthReturnClass extends BaseOauth {
  constructor({ query={}, txnId, headers={} }) {
    super( txnId )
    this.errorCode = query.error_code
    this.message = query.error_description
    this.isError = ERROR_CODES.PARTNER_AUTH_ERRORS[ this.errorCode  ]
    this.token = query.token_query ? query.token_query.split( '=' )[ 1 ] : null
    this.offerinRedirectUrl = query.redirect_url
    this.fdpErrorCode = getFdxError( this.errorCode )
    this.isJson = false
    this.headers = headers
  }

  setIsJson( bool ) {
    this.isJson = bool
    return this
  }

  get redirectUri() {
    if ( this.isError && this.offerinRedirectUrl ) {
      return  `${this.offerinRedirectUrl}?errorCode=${this.fdpErrorCode}&errorMessage=${this.mssage }&txnId=${this.txnId}`
    }

    if ( !this.isError && this.offerinRedirectUrl ) {
      return `${this.offerinRedirectUrl}?txnId=${this.txnId}&response_token=${this.token}&token=${this.token}`
    }

    return null
  }

  get response() {

    if ( this.isError && this.offerinRedirectUrl ) {
      return {
        uri : `${this.offerinRedirectUrl}?errorCode=${this.fdpErrorCode}&errorMessage=${this.mssage }&txnId=${this.txnId}`
      }
    }

    if ( !this.isError && this.offerinRedirectUrl ) {
      return {
        uri: `${this.offerinRedirectUrl}?txnId=${this.txnId}&response_token=${this.token}&token=${this.token}`
      }
    }

    return null
  }

}
