import _ from 'lodash'
import objectPath from 'object-path'
import url from 'url'
const ERROR_CODES = require( '@fdx/common/errors/error-mapping' )

function getUrlFromQueryParam( offering_redirect_uri ) {
  if ( !offering_redirect_uri ) {
    return false
  }
  let uri = url.parse( offering_redirect_uri )
  let queryParams = uri.query.split( '&' )
  let urlQueryParam = _.find( queryParams, function ( item ) {
    return _.contains( item, 'redirect_url=' )
  } )
  urlQueryParam = urlQueryParam.split( '=' )
  return urlQueryParam[ 1 ]
}

export default class OAuthModel {
  constructor() {
    this.root = ''
  }

  get uri() {
    return this.root
  }

  set successUri( { body, txnId } ) {
    let uri = body.uris[ 0 ]
    this.root = `${uri}&txnId=${txnId}`
  }

  set errorUri( { body, txnId, offering_redirect_uri } ) {
    let uri = getUrlFromQueryParam( offering_redirect_uri )
    let partnerAuthErrorCode =   objectPath.get( body, 'errors.0.code')
    let fdpErrorCode = ERROR_CODES.PARTNER_AUTH_ERRORS[ partnerAuthErrorCode ] ? ERROR_CODES.PARTNER_AUTH_ERRORS[ partnerAuthErrorCode ].fdp_code : 'FDPAUTH-580'
    let message = objectPath.get( body, 'errors.0.description', 'downstream service not availalble' )
    this.root = `${uri}?errorCode=${fdpErrorCode}&errorMessage=${message}&txnId=${txnId}`
  }

}
