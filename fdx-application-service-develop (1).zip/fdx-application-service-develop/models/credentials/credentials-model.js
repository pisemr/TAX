

export default class CredentialsModel {
  constructor( body = {} ) {
    this.response = body
    if ( !body.status && body.statusDetail ) {
      if ( body.statusDetail.code === '0' ) {
        this.response.status = 'verified'
      } else if ( body.statusDetail.code === '999' ) {
        this.response.status = 'unverified'
      } else {
        this.response.status = 'invalid'
      }
    }
  }
  get credentials() {
    return this.response
  }
}
