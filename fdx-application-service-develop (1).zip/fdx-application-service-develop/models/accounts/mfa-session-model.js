export default class MfaSessionModelRequest {
  constructor( providerDetail, mfaSession ) {
    this.mfaSession = mfaSession
    this.providerId = providerDetail.providerId
    this.credentialSetId = providerDetail.credentialSets[0].credentialSetId
    this.statusDetail = providerDetail.statusDetail
    this.responseParams = providerDetail.responseParams
    this.authFieldnMapping = providerDetail.credentialSets[0].credentials.map( credential => {
      let mappedCredentials = {
        'authenticationFieldType': credential.authenticationFieldType,
        'authenticationText': credential.authenticationFieldText,
        'encrypted': credential.encrypted,
        'hideChars': credential.hideChars,
        'id': credential.authenticationFieldId
      }

      // Stay backward compatible 
      if ( credential.captcha ) {
        mappedCredentials.captchaImage = credential.captcha.image
      }
      
      if ( credential.captchas ) {
        const captchaImages = credential.captchas.map(captcha=>captcha.content)
        mappedCredentials.captchaImage =  captchaImages ? captchaImages[0] : ''
      }

      if ( credential.choiceText ) {
        mappedCredentials.choiceText = credential.choiceText
      }

      return mappedCredentials
    } )
  }
}
