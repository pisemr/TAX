
export default class AccountListModel {
  constructor(account) {

        // "accountId": "urn:account:fdp::accountid:193b3e5c-0028-31c8-b7a6-b1241ee47ac8",
        // "associations": [
        //   "urn:profile:ius::userid:123146259041544"
        // ],
        // "accountNumberMasked": "3717",
        // "accountType": "SAVINGS",
        // "availableBalance": 0,
        // "credentialSetId": "daa96f08-bfaf-47bc-acd4-5a59d7c8e7d5",
        // "currencyCode": "USD",
        // "currentBalance": 0,
        // "description": "SAVINGS",
        // "displayName": "3717",
        // "nickName": "Savings",
        // "providerId": "90aec3e4-0d85-45fa-8a1b-b2ce655d6705",
        // "statusCode": "0",
        // "statusMessage": "SUCCESS",
        // "timeZone": "(GMT-8:00) America/Los_Angeles",
        // "L10_provider_description": "SAVINGS"


    this.accountId = account.accountId || ''
    this.accountNumberMasked = account.accountNumberMasked || ''
    this.credentialSetId = account.credentialSetId || ''
    this.currencyCode = account.currencyCode || ''
    this.currentBalance = account.currentBalance || ''
    this.description = account.description || ''
    this.nickName = account.nickName || ''
    this.providerId = account.providerId || ''
    this.statusCode = account.statusCode || ''
    this.statusMessage = account.statusMessage || ''
    this.timeZone = account.timeZone || ''
    this.accountType = account.accountType || ''
    this.isSelected = false
  }

  setSelected(isSelected) {
    this.isSelected = isSelected
  }
}
