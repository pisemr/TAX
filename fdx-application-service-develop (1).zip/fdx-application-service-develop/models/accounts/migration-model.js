export default class MigrationModel {
  constructor( response ) {
    const providerDetail = response.providers[ 0 ]
    
    this.providerId = providerDetail.providerId
    this.credentialSetId = providerDetail.credentialSets[0].credentialSetId
    this.responseParams = response.responseParams || null
    this.migrationDetails = providerDetail.credentialSets[0].migration
    this.fdmsMigrationResponseDetails = response.errors[ 0 ]
  }
}
