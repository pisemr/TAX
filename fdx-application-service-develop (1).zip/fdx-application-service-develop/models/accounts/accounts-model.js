import objPath from 'object-path'
import config from '../../lib/config'
import logger from '../../lib/logger'
import vaultUtils from '../../lib/vault-utils'
import GUIDGenerator from '../../lib/generate-tid'
import AuthField from '../authenticationField-model'

const IS_PROD = ( config.ENV === 'prod.lvdc' || config.ENV === 'prod.qdc' )

class MfaModel {
  constructor() {
    this.providerId = ''
    this.mfaSession = ''
    this.mfaFields = []
    this.mfaRequired = true
    this.authType = 'account'
  }

  get challenge() {
    return this
  }

  set challenge( body ) {
    let channels = objPath.get( body, 'provider.channels', {} )

    this.providerId = objPath.get( body, 'provider.providerId', {} )
    this.mfaSession = objPath.get( body, 'responseParams.mfaSession', '' )

    channels.forEach(( channel ) => {
      channel.authenticationInfo.authenticationMapping.forEach(( authMapping ) => {
        let normalizedAuthMapping = new AuthField()
        normalizedAuthMapping.initializeFromAVSMFA( authMapping )

        //Per Ajay on 12.16.16.. they are going to start sending different field types, but the v1 client isn't ready for that
        //Decision was to treat it like an error here
        if (normalizedAuthMapping.fieldType !== 'MFAText') {
          throw new Error('Unsupported fieldType: ' + normalizedAuthMapping.fieldType)
        }

        this.mfaFields.push( normalizedAuthMapping )
      } )
    } )
  }
}

class AccountsModel {
  constructor() {
    this.providerId = ''
    this.accounts = []
    this.mfaRequired = false
    this.authType = 'account'
    this.accountEncrypted = {}
  }

  get list() {
    return this
  }

  set list( body ) {

    this.providerId = objPath.get( body, 'provider.providerId', {} )
    let rawAccounts = objPath.get( body, 'provider.accounts', [] )
    let accountNickNames = ''

    if ( IS_PROD ) {
      this.accountsEncrypted = {
        deprecated: true,
        message: 'Unsupported production operation',
        accounts: [],
        personalData: {},
        providerId: this.providerId
      }
    } else {
      this.accountEncrypted = body.provider
    }
    this.accountEncrypted.deprecated = true

    rawAccounts.forEach( ( account, idx ) => {

      if ( account.nickName ) {
        accountNickNames += ( account.nickName + ';' )
      } else {
        accountNickNames += ( 'VAULT_NULL;' )
      }


      let name = account.nickName ? account.nickName : vaultUtils.properCase( account.accountType )
      if ( !account.id ) {
        let guidGenerator = new GUIDGenerator()
        account.id = 'FDP-' + guidGenerator.tid
      }

      let last4 = account.accountNumberMasked ?  vaultUtils.lastFourOfAccount(account.accountNumberMasked) : vaultUtils.lastFourOfAccount(account.accountNumberTokenized)

      this.accounts.push( {
        id: account.id,
        index: idx,
        name: name + ' ' + last4,
        accountType: vaultUtils.properCase( account.accountType ),
        accountLastFour: last4,
        accountNumberMasked: account.accountNumberMasked,
        accountNickName: account.nickName,
        accountNumberTokenized: account.accountNumberTokenized,
        bankTransferRoutingInfos: account.bankTransferRoutingInfos
      } )
    } )

    if ( config.logAccountNickNames ) {
      logger.info( {
        'accountNickNames': accountNickNames
      } )
    }
  }
}

exports.AccountsModel = AccountsModel
exports.MfaModel = MfaModel
