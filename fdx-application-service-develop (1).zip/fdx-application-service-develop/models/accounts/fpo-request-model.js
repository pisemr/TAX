export class ProviderAuthField {
  constructor( field ) {
    this.authenticationFieldId = field.id
    this.authenticationFieldText = field.text
    this.authenticationFieldValue = field.value

    if (field.authenticationFieldType) {
      this.authenticationFieldType = field.authenticationFieldType
    }
    else {
      this.authenticationFieldType = field.type || 'primary'
    }

    if (field.choiceText) {
      this.choiceText = field.choiceText
    }

    this.encrypted = field.encrypted || false

    if (field.certVersion) {
      this.certVersion = field.certVersion
    }
  }
}

export class FpoAcquireModel {
  constructor( providerDetail, isAsync ) {

    this.providers = [ {
      'credentialSets': [],
      'providerId': providerDetail.providerId
    } ]

    if (providerDetail.credentialSetId) {
      this.providers[0].credentialSets.push({ 'credentialSetId': providerDetail.credentialSetId })
    } else {
      this.providers[0].credentialSets.push({
        //only need channelId in Acquire call
        'channelId': providerDetail.channelId,
        'compliance':providerDetail.compliance,
        'credentials': providerDetail.credentials ? providerDetail.credentials.map( field => new ProviderAuthField( field ) ) : []
      })
    }

    this.requestParams = {
      'async': isAsync,
      'persist': true,
      'selectors': {
        'accountSelector': {}
      }
    }

    if (providerDetail.addPiiToProfile) {
      this.requestParams.selectors.piiSelector = {}
    }

    if (providerDetail.minimumDataset) {
      this.requestParams.selectors.accountSelector.minimumDataset = providerDetail.minimumDataset
    }

    if(providerDetail.includeTransactions) {
      this.requestParams.transactions = {}
    }

    if(providerDetail.migrationId) {
      this.providers[0].credentialSets[0].type = providerDetail.authType//TODO: check if we need to pass this
      this.providers[0].credentialSets[0].migration = {
        migrationId: providerDetail.migrationId,
        sourceCredentialSetId: providerDetail.sourceCredentialSetId
      }
    }

  }
}

export class FpoMfaModel {
  constructor( providerDetail, isAsync ) {

    this.providers = [ {
      'credentialSets': [ {
        'credentialSetId': providerDetail.credentialSetId,
        'credentials': providerDetail.credentials ? providerDetail.credentials.map( field => new ProviderAuthField( field ) ) : []
      } ],
      'providerId': providerDetail.providerId
    } ]

    this.requestParams = {
      'async': isAsync,
      'persist': true,
      'selectors': {
        'accountSelector': {},
      },
      'mfaSession': providerDetail.mfaSession
    }

    if (providerDetail.accountList) {
      this.requestParams.selectors.accountSelector.accountList = providerDetail.accountList
    }

    if (providerDetail.dateRange) {
      this.requestParams.selectors.transactionSelector= {}
      this.requestParams.selectors.transactionSelector.dateRange = {
        'startDate': providerDetail.dateRange.startDate,
        'endDate': providerDetail.dateRange.endDate
      }
    }

    if (providerDetail.addPiiToProfile) {
      this.requestParams.selectors.piiSelector = {}
    }

    if (providerDetail.minimumDataset) {
      this.requestParams.selectors.accountSelector.minimumDataset = providerDetail.minimumDataset
    }
  }
}
export class FpoRefreshModel {
  constructor( providerDetail, isAsync ) {

    this.providers = [ {
      'credentialSets': providerDetail.credentialSetIds ? providerDetail.credentialSetIds.map(credentialSetId => {
        return {
          credentialSetId: credentialSetId
        }
      }) : [],
      'providerId': providerDetail.providerId
    } ]

    this.requestParams = {
      'async': isAsync,
      'persist': true,
      'selectors': {
        'accountSelector': {},
        'transactionSelector': {}
      }
    }

    if (providerDetail.accountList) {
      this.requestParams.selectors.accountSelector.accountList = providerDetail.accountList
    }

    if (providerDetail.dateRange) {
      this.requestParams.selectors.transactionSelector.dateRange = {
        'startDate': providerDetail.dateRange.startDate,
        'endDate': providerDetail.dateRange.endDate
      }
    }
  }
}

export class FpoEditCredentialsModel {
  constructor( providerDetail, isAsync ) {

    this.providers = [ {
      'providerId': providerDetail.providerId,
      'credentialSets':[ {
        'providerId': providerDetail.providerId,
        'compliance': providerDetail.compliance && providerDetail.compliance.is7216
          ? providerDetail.compliance
          : { is7216: true },
        'credentials': providerDetail.credentials ? providerDetail.credentials.map( field => new ProviderAuthField( field ) ) : []
      } ]
    } ]

    this.requestParams = {
      'async': isAsync,
      'persist': true,
      'bypassAccountsValidation': false,
      'selectors': {
        'accountSelector': {}
      }
    }

    // Only needed for url param
    this.credentialSetId = providerDetail.credentialSetId
  }
}
