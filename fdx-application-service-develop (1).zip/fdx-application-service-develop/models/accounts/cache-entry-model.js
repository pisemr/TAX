export default class CacheEntryModel {
  constructor( correlationId, fdiResponse, isError = false, status ) {
    let initialEntry = true
    this.correlationId = correlationId
    if ( (fdiResponse && status !== 'INITIAL') || isError ) {
      initialEntry = false
    }
    this.initialEntry = initialEntry
    this.response = fdiResponse
    this.isError = isError
  }
}
