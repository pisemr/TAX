export default class FpoPollingModel {
  constructor( correlationId, status, fdiResponse, hasMFA ) {
    this.correlationId = correlationId
    this.status = status
    if ( hasMFA ) {
      this.isMfaResponse = true
    }
    this.response = fdiResponse
  }
}
