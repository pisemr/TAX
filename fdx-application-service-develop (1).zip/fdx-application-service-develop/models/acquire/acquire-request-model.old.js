import {
  ProviderAuthField
} from '../accounts/fpo-request-model'


const setAcquireModel = ({ providerId }) => isAsync => ({
  providers: [ {
    'credentialSets': [ ],
    'providerId': providerId
  } ],
  requestParams: {
    'async': isAsync,
    'persist': true,//!context.includes('documents'),
    'selectors': {}
  }
})

export const AcquireModelOld = ({
  providerId,
  acquireContext,
  accountList,
  dateRange,
  reportingParams,
  folderId,
  taxYear,
  entityTypes,
  credentialSetId,
  channelId,
  compliance,
  credentials,
  minimumDataset,
  addPiiToProfile,
  authType,
  migrationId,
  sourceCredentialSetId
}, isAsync = true) => {

  //default context - get 'accounts'
  const context = acquireContext || [ 'accounts' ]

  //default acquire request params
  let acquireModel = setAcquireModel({ providerId, context })(isAsync)

  //based on acquire Context
  //add more params to acquire request object
  // We only support one context... maybe one day it will be more.
  switch(context[0]) {
    //Get Transactions
    case 'accounts':
      acquireModel.requestParams.selectors.accountSelector = {}
      break

    case 'transactions':
      acquireModel.requestParams.selectors.accountSelector = {}
      acquireModel.requestParams.selectors.transactionSelector = {}

      if (accountList) {
        acquireModel.requestParams.selectors.accountSelector.accountList = accountList
      }

      if (dateRange) {
        acquireModel.requestParams.selectors.transactionSelector.dateRange = {
          'startDate': dateRange.startDate,
          'endDate': dateRange.endDate
        }
      }
      break

    case 'documents':
      acquireModel.reportingParams = reportingParams

      acquireModel.persistenceParams = {
        persistDoc : true,
        persistCred : true,
        folderId : folderId
      }

      acquireModel.requestParams.selectors.documentSelector = {
        taxYear: taxYear,
        entityTypes: entityTypes
      }
      break
  }
  
  //optional acquire request params
  if (credentialSetId) {
    acquireModel.providers[0].credentialSets.push( { 'credentialSetId': credentialSetId } )
  } else {
    acquireModel.providers[0].credentialSets.push( {
      //only need channelId in Acquire call
      'channelId': channelId,
      'compliance': compliance,
      'credentials': credentials ? credentials.map( field => new ProviderAuthField( field ) ) : []
    } )
  }

  if (minimumDataset) {
    if (!acquireModel.requestParams.selectors.accountSelector)
      acquireModel.requestParams.selectors.accountSelector = {}

    acquireModel.requestParams.selectors.accountSelector.minimumDataset = minimumDataset
  }

  if (addPiiToProfile) {
    acquireModel.requestParams.selectors.piiSelector = {}
  }  

  if(migrationId) {
    acquireModel.providers[0].credentialSets[0].type = authType//TODO: check if we need to pass this
    acquireModel.providers[0].credentialSets[0].migration = {
      migrationId: migrationId,
      sourceCredentialSetId: sourceCredentialSetId
    }
  }

  return acquireModel
}
