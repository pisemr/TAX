import config from '../../lib/config'
import utils from '../../lib/vault-utils'

const HOST = config.host

export default class EmployerModel {
  constructor( business ) {
    this.id = business.id
    this.name = utils.properCase( business.name )
    this.url = business.url
    this.phoneNumber = business.phoneNumber
    this.thumbnail = business.thumbnail
    this.logoUrl = `https://${HOST}/content/general/icon_placeholder.png`
    this.isActive = true
    this.isTransientProvider = false

    config.inactiveProviders.forEach(( provider )=> {
      if ( provider.toLowerCase().trim() === this.name.toLowerCase().trim() ) {
        this.active = false
      }
    } )

    config.transientProviders.forEach(( provider )=> {
      if ( provider.toLowerCase().trim() === this.name.toLowerCase().trim() ) {
        this.isTransientProvider = true
      }
    } )
  }
}
