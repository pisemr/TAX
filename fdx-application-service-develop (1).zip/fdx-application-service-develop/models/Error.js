import objectPath from 'object-path'
import { VAULT_ROUTE_ERRORS } from '@fdx/common/errors/error-mapping'
import logger from '../lib/logger'
import config from '../lib/config'

const WIKI_ROOT = 'https://github.intuit.com/CTO-Dev-FDS-Vault/VaultApplicationServices/wiki/'

function flattenError( type, error={} ) {

  switch ( type ) {
    case 'abtesting':
      return objectPath.get( error, 'errors.error.0', error )

    case 'credentials':
      return objectPath.get( error, 'errors.error.0', error )
   
    case 'fpo':
      return objectPath.get( error, 'errors.0', error)

    case 'interaction':
      return objectPath.get( error, 'errors.0', error )

    case 'providers':
      return objectPath.get( error, 'error.0', error )

    case 'partnerauth':
      return objectPath.get( error, 'errors.0', error )

    default:
      return error
  }
}

class Error {
  constructor( type, error={}, headers={}, statusCode, extendedDetails = {} ) {
    const flatError = objectPath(flattenError(type, error))

    this.statusCode = statusCode === 'none' ? 500 : statusCode && statusCode !== 200 ? statusCode : 500
    this.code = VAULT_ROUTE_ERRORS[ type ] ||  VAULT_ROUTE_ERRORS.default
    this.type = flatError.get('type', 'SERVER' )
    this.message = statusCode === 'none' ? 'statusCode was not available' : `downstream service error: ${type}`
    this.detail = {}
    this.detail.code = flatError.get('code', 'no code returned')
    this.detail.message = `${flatError.get( 'message', '' )} ${flatError.get( 'detail', '' )}`
    this.moreInfo = ''
    this.category = 'catastrophic'
    this.intuit_tid = objectPath.get( headers, 'intuit_tid', '' )

    if(extendedDetails) {
      if(extendedDetails.correlationId) {
        this.correlationId = extendedDetails.correlationId
      }
    }

    switch ( type ) {
      case 'VALUT_CLIENT_ERROR':
        this.statusCode = 400
        this.type = 'CLIENT'
        this.message = flatError.get()
        break

      case 'VALUT_SERVER_ERROR':
        this.statusCode = 500
        this.type = 'SERVER'
        this.message = flatError.get()
        break

      case 'axs' :
        this.statusCode = 401
        this.type = 'CLIENT'
        this.message = 'authentication error: invalid ticket'
        this.detail.code = flatError.responseCode
        this.detail.message = flatError.responseMessage
        break
        
      case 'cache':
        if ( flatError.statusCode === 404 ) {
          this.type = 'CLIENT'
          flatError.message = 'No cache entry found'
        } else {
          this.type = 'SERVER'
        }
        this.statusCode = 400
        this.detail.code = flatError.statusCode
        this.detail.message = flatError.message
        break
        
      case 'crm':
        this.statusCode = 400
        this.detail = {}
        this.detail.message = ''
        break

      case 'fpo':
        this.code = VAULT_ROUTE_ERRORS[ type ] && VAULT_ROUTE_ERRORS[ type ][ this.detail.code ] ? VAULT_ROUTE_ERRORS[ type ][ this.detail.code ].code : VAULT_ROUTE_ERRORS[ type ].default.code
        this.category = VAULT_ROUTE_ERRORS[ type ] && VAULT_ROUTE_ERRORS[ type ][ this.detail.code ] ? VAULT_ROUTE_ERRORS[ type ][ this.detail.code ].errorType : VAULT_ROUTE_ERRORS[ type ].default.errorType
        if(error.providers)
          this.detail.providers = error.providers
        if(error.responseParams)
          this.detail.responseParams = error.responseParams
        break

      case 'document':
        let desErrorCodeRegex = /.*DESErrorCode :(\d+) .*/
        let errorMessage = objectPath.get(error, 'detail.message', '')
        let regexResult = desErrorCodeRegex.exec(errorMessage)

        if(regexResult) {
          this.detail.desErrorCode = regexResult[1]
        }

        break

      case 'abtesting':
        //default is good so break
        break

      case 'credentials':
        //default is good so break
        break

      case 'providers' :
        break

      case 'interaction':
        this.code = VAULT_ROUTE_ERRORS[ type ] && VAULT_ROUTE_ERRORS[ type ][ this.detail.code ] ? VAULT_ROUTE_ERRORS[ type ][ this.detail.code ].code : VAULT_ROUTE_ERRORS[ type ].default.code
        this.detail.errorType = VAULT_ROUTE_ERRORS[ type ] && VAULT_ROUTE_ERRORS[ type ][ this.detail.code ] ? VAULT_ROUTE_ERRORS[ type ][ this.detail.code ].errorType : VAULT_ROUTE_ERRORS[ type ].default.errorType
        this.detail.authType = 'account'
        break

      case 'accessV1':
        this.code = VAULT_ROUTE_ERRORS.access && VAULT_ROUTE_ERRORS.access[ this.detail.code ] ? VAULT_ROUTE_ERRORS.access[ this.detail.code ].code : VAULT_ROUTE_ERRORS.access.default.code
        this.detail.authType = 'document'
        this.detail.errorType = VAULT_ROUTE_ERRORS.access && VAULT_ROUTE_ERRORS.access[ this.detail.code ] ? VAULT_ROUTE_ERRORS.access[ this.detail.code ].errorType : VAULT_ROUTE_ERRORS.access.default.errorType
        this.detail.canDisplay = objectPath.get( error, 'providerErrorResponse.isDetailed', false )
        this.detail.providerInfo = {}
        this.detail.providerInfo.type = objectPath.get( error, 'providerErrorResponse.type', '' )
        this.detail.providerInfo.message = objectPath.get( error, 'providerErrorResponse.message', '' )
        this.detail.providerInfo.detail = objectPath.get( error, 'providerErrorResponse.detail', '' )

        //backward compatibility
        this.errors = {
          error:[
            {
              detail: this.detail
            }
          ]
        }

        break

      case 'access':
        this.code = VAULT_ROUTE_ERRORS[ type ] && VAULT_ROUTE_ERRORS[ type ][ this.detail.code ] ? VAULT_ROUTE_ERRORS[ type ][ this.detail.code ].code : VAULT_ROUTE_ERRORS[ type ].default.code
        this.category = VAULT_ROUTE_ERRORS[ type ] && VAULT_ROUTE_ERRORS[ type ][ this.detail.code ] ? VAULT_ROUTE_ERRORS[ type ][ this.detail.code ].errorType : VAULT_ROUTE_ERRORS[ type ].default.errorType
        this.detail.canDisplay = objectPath.get( error, 'providerErrorResponse.isDetailed', false )
        this.detail.providerInfo = {}
        this.detail.providerInfo.type = objectPath.get( error, 'providerErrorResponse.type', '' )
        this.detail.providerInfo.message = objectPath.get( error, 'providerErrorResponse.message', '' )
        this.detail.providerInfo.detail = objectPath.get( error, 'providerErrorResponse.detail', '' )
        break

      case 'partnerauth':
        this.code =  VAULT_ROUTE_ERRORS.partnerauth[flatError.get('code')].code ||  VAULT_ROUTE_ERRORS.partnerauth.default
        this.category = 'catastrophic'
        this.detail = flatError.get()
        break

      case 'google':
        this.code =  'FDX-1001'
        this.type = 'CLIENT'
        this.category = VAULT_ROUTE_ERRORS.google.errorType
        this.detail = typeof flatError.get() === 'string' ? { error: flatError.get() } : flatError.get()
        this.detail.code = '103a'
        break

      case 'rss':
        this.code =  'FDX-1001'
        this.detail = flatError.get()
        this.detail.code = '103a'
        break

      case 'stack':
        this.type = 'SERVER'
        this.category = 'catastrophic'
        this.message = 'unhandled exception'
        this.detail = error.message
        break

      default:
        this.type = 'SERVER'
        this.message = statusCode === 'none' ? 'statusCode was not available' : 'unexpected error'
        this.detail.code = error.code ? error.code : ''
        this.detail.message = error.message ? error.message : ''
    }

    this.moreInfo = `${WIKI_ROOT}${this.code}`

    let data
    if (type === 'stack') data = `LOG_ORIGIN="error-model"
    INTERNAL_ERROR="true"
    respError="${this.code}"
    respErrorType="${this.type}"
    respErrorMEssage="${this.message}"
    exceptionMessage="${error.message}"
    exceptionStack="${error.stack}"
    intuitTid="${this.intuit_tid}"
    offeringId=${headers.intuit_offeringid}
    originalUrl="${headers.intuit_originalurl}"
    appVersion="${config.APP_VERSION}"`

    else data = `LOG_ORIGIN="error-model"
    DEPENDENCY_ERROR="true"
    respError="${this.code}"
    respErrorType="${this.type}"
    respErrorMessage="${this.message}"
    remoteErrorCode="${this.detail.code}"
    remoteErrorMessage="${this.detail.message}"
    intuitTid="${this.intuit_tid}"
    appVersion="${config.APP_VERSION}"`

    if ( config.ENV !== 'local' ) data = data.replace( /\n/g, ' ' )

    logger.error( data )
  }

  set newMessage( message ) {
    this.message = message
  }
}

export default Error
