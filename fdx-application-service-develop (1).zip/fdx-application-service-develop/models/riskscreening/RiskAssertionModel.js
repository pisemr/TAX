import config from '../../lib/config'

export default class RiskAssertionModel {
  constructor({ transaction, providerId, authid }) {
    this.userAuthId = authid
    this.transaction = transaction
    this.transactionDetail = 'TBD'
    this.riskAttributes = [ {
      namespace: config.services.rss.namespace,
      key: config.services.rss.key,
      values:[
        providerId
      ]
    } ]
  }
}