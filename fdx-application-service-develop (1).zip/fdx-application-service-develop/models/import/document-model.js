
import config from '../../lib/config'

function getDocumentIdFromDocumentLocation( location ) {
  return location ? location.substring( location.indexOf('/documents/' ) + 11 ) : ''
}

function getFolderIdFromDocumentLocation( location ) {
  return location ? location.substring( location.indexOf( '/folders/' ) + 9, location.indexOf( '/documents/' ) ) : ''
}

class DocumentModel {
  constructor( document={}, documentType ) {
    this.documentType     = documentType
    this.documentLocation = document.fdpDocumentInfo ? document.fdpDocumentInfo.documentLocation : ''
    this.documentId       = getDocumentIdFromDocumentLocation(document.documentLocation)
    this.folderId         = getFolderIdFromDocumentLocation(document.documentLocation)
    this.documentName     = document.fdpDocumentInfo ? document.fdpDocumentInfo.documentName : ''
    this.documentUrl      = `https://${config.host}/v1/documents/${this.documentId}/?format=view&intuit_apikey=`
  }
}


exports.DocumentModel = DocumentModel
