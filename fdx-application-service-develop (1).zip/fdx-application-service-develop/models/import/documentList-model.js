import _ from 'lodash'
import objectPath from 'object-path'
import { DocumentModel } from './document-model'

const DOCUMENT_KEY_MAP = {
  Divs: [ 'f1099Divs', '1099-DIV' ],
  Ints: [ 'f1099Ints', '1099-INT' ],
  Rs: [ 'f1099Rs', '1099-R' ],
  Bs: [ 'f1099Bs', '1099-B' ],
  Miscs: [ 'f1099Miscs', '1099-MISC' ],
  Oids: [ 'f1099Oids', '1099-OID' ],
  w2s: [ 'w2s', 'W-2' ],
  '1098s': [ 'f1098s', '1098' ]
}


class DocumentListModel {
  constructor() {
    this.documents = {}
    this.accountType = 'document'
  }

  get list() {
    this.documents.authType = 'document'
    return this.documents
  }

  set list( { body, requestedDocType } ) {
    let grouping = ''
    _.forEach( body, ( response ) => {
      let entity = objectPath( response )
      _.forEach( DOCUMENT_KEY_MAP, ( documentType ) => {
        let childObj = documentType[ 0 ].substring( 0, documentType[ 0 ].length - 1 ) + 'Entity'
        if ( entity.get( documentType[ 0 ] ) ) {
          _.forEach( entity.get( documentType[ 0 ] + '.' + childObj ), ( document ) => {
            // If the document has errors or the Entity is empty, let's not iterate though it
            if ( Object.keys( document ).length === 0 ) {
              return false
            }
            let documentModel = new DocumentModel( document, documentType[ 1 ])

            if ( requestedDocType ) {
              if ( documentType[ 1 ] === requestedDocType ) {
                grouping = 'requestedDocuments'
                if ( !this.documents[ grouping ] ) {
                  this.documents[ grouping ] = []
                }
              } else {
                grouping = 'otherDocuments'
                if ( !this.documents[ grouping ] ) {
                  this.documents[ grouping ] = []
                }
              }
            } else {
              grouping = 'documents'
              if ( !this.documents[ grouping ] ) {
                this.documents[ grouping ] = []
              }
            }
            this.documents[ grouping ].push( documentModel )
          } )
        }
      } )
    } )
  }
}

exports.DocumentListModel = DocumentListModel
