import {
  ProviderAuthField
} from '../accounts/fpo-request-model'


const ACCOUNT_SELECTOR_ENTITIES      = [ 'ACCOUNT', 'SELF_EMPLOYED' ]
const TRANSACTION_SELECTOR_ENTITIES  = [ 'TRANSACTION_DOWNLOAD' ]
const BILL_SELECTOR_ENTITIES         = [ 'LINKED_BILL' ]
const DOCUMENT_SELECTOR_ENTITIES     = [ '1099-INT', '1099-DIV', '1099-OID', '1099-R', '1099-B', '1099-MISC', 'W2' ]


const setSelectors = (entityTypes=[]) => {

  const contains = entities => services => entities.filter(entity => services.find(service=>service===entity)).length > 0
  const entitiesContain = contains(entityTypes)
  const selectors = {}

  if ( entitiesContain(BILL_SELECTOR_ENTITIES) ) 
    selectors.billSelector = {}
  
  if ( entitiesContain(TRANSACTION_SELECTOR_ENTITIES) ) 
    selectors.transactionSelector = {}
  
  if ( entitiesContain(ACCOUNT_SELECTOR_ENTITIES) ) 
    selectors.accountSelector = {}
  
  if ( entitiesContain(DOCUMENT_SELECTOR_ENTITIES) ) 
    selectors.documentSelector = {}
  
  return selectors
}

const setFpoRequestModel = ({ providerId, entityTypes }) => isAsync => ({
  providers: [ {
    'credentialSets': [ ],
    'providerId': providerId
  } ],
  requestParams: {
    'async': isAsync,
    'persist': true,
    'selectors': setSelectors(entityTypes) || {},
  }
})


export const FpoRequestModel = ({
  providerId,
  channelId,
  compliance,
  credentials,
  credentialSetId,
  isRealmContext,
  addPiiToProfile,
  minimumDataset,
  accountList,
  dateRange,
  folderId,
  taxYear,
  entityTypes,
  sourceCredentialSetId,
  targetCredentialSetId,
  migrationId,
  partnerUserId,
  reportingParams,
  authType,
  mfaSession
}, isAsync = true) => {


  //default acquire request params
  let Model = setFpoRequestModel({ providerId, entityTypes })(isAsync)

  if ( mfaSession ) {
    Model.requestParams.mfaSession = mfaSession
  }

  // do account selector things 
  if ( Model.requestParams.selectors.accountSelector ) {
    if (accountList) {
      Model.requestParams.selectors.accountSelector.accountList = accountList
    }
  }

  // do transaction selector things 
  if ( Model.requestParams.selectors.transactionSelector ) {
    if (dateRange) {
      Model.requestParams.selectors.transactionSelector.dateRange = {
        'startDate': dateRange.startDate,
        'endDate': dateRange.endDate
      }
    }
  }
  
  // do bill selector things 
  if ( Model.requestParams.selectors.billSelector ) {
    //TODO
  }
  
  // do document selector things 
  if ( Model.requestParams.selectors.documentSelector ) {
    Model.reportingParams = reportingParams
    Model.persistenceParams = {
      persistDoc : true,
      persistCred : true,
      folderId : folderId
    }
    Model.requestParams.selectors.documentSelector = {
      taxYear: taxYear,
      entityTypes: entityTypes
    }
  }
  
  // what type of authentication is being used?
  if (Array.isArray(credentials) || credentialSetId) {
    Model.providers[0].credentialSets.push( {
      //only need channelId in Acquire call
      'credentialSetId': credentialSetId,
      'channelId': channelId,
      'compliance': compliance,
      'credentials': credentials ? credentials.map( field => new ProviderAuthField( field ) ) : undefined
    } )
  }
  

  if (minimumDataset) {
    if (!Model.requestParams.selectors.accountSelector)
      Model.requestParams.selectors.accountSelector = {}

    Model.requestParams.selectors.accountSelector.minimumDataset = minimumDataset
  }

  if (addPiiToProfile) {
    Model.requestParams.selectors.piiSelector = {}
  }  

  if(migrationId) {
    Model.providers[0].credentialSets[0].type = authType//TODO: check if we need to pass this
    Model.providers[0].credentialSets[0].migration = {
      migrationId: migrationId,
      sourceCredentialSetId: sourceCredentialSetId
    }
  }

  return Model
}
