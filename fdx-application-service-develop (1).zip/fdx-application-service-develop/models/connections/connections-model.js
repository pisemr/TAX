import objPath from 'object-path'
import _ from 'lodash'

export default class ConnectionsModel {
  constructor() {
    this.merged = []
  }

  get mergedResponse() {
    return this.merged
  }

  set mergedResponse({ credentialsResponse, profileResponse }) {
    let credentialsObj = objPath( credentialsResponse )
    let profileObj = objPath( profileResponse )
    let credsList = credentialsObj.get( 'providers' )
    let proflieList = profileObj.get( 'providerPreferences' )
    let tmpMergedResponse = {}

    _.forEach( credsList, ( provider ) => {
      tmpMergedResponse[ provider.providerId ] = []
      if ( provider.credentialSets ) {
        _.forEach( provider.credentialSets, ( value ) => {
          tmpMergedResponse[ provider.providerId ].push( value.credentialSetId )
        } )
      }
    } )

    _.forEach( proflieList, ( provider ) => {
      if ( !tmpMergedResponse[ provider.providerId ] ) {
        tmpMergedResponse[ provider.providerId ] = []
      }
      if ( provider.credentialPreferences ) {
        _.forEach( provider.credentialPreferences, ( value ) => {
          tmpMergedResponse[ provider.providerId ].push( value.credentialSetId )
        } )
      }
    } )

    _.forEach( tmpMergedResponse, ( provider, providerId ) => {

      let credentials = provider.filter( function ( v, i, a ) {
        return a.indexOf( v ) == i
      } )

      this.merged.push( {
        providerId: providerId,
        credentialSetIds: credentials
      } )

    } )

  }

}
