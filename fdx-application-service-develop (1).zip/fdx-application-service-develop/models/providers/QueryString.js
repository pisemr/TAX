import config from '../../lib/config'
export default class QueryString {
  constructor( { query='', zip='', start=0, limit=5, lang='en', recipe=null, template=null, country_code='US' } ) {
    this.action = 'selectsearch'
    this.pretty = true
    this.models = config.services.sts.collection
    this.template = template
    this.country_code = country_code
    this.intent = recipe
    this.prefix = query
    this.zip = zip
    this.start = start
    this.rows = limit
    this.lang = lang
  }

  set queryTemplate( template ) {
    this.template = template
  }

  set queryIntent( intent ) {
    this.intent = intent
  }

}
