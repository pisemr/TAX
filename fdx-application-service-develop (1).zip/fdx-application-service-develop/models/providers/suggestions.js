import objPath from 'object-path'
import { getCompliantLogo } from '../../lib/vault-utils'

export default class SuggestionsModel {
  constructor( result ) {
    let staticProviderRef = result.staticProviderRef
    let logos = objPath.get(staticProviderRef, 'logos.logo', [])

    this.id = staticProviderRef.id
    this.legacyId = objPath.get(staticProviderRef, 'legacyId', '')
    this.name = staticProviderRef.name
    this.logoUrl = getCompliantLogo(logos)
    this.loginUrl = objPath.get(staticProviderRef, 'loginUrl', '')

    //TODO:: Confirm whether we need below attributes and figure out how to fetch their values
    this.url = ''
    this.multiplechannel = result.ismultichannel || false
    this.ispartner = result.ispartner || false
    this.businessOverlayEnabled = !!result.isoverlayenabled || false
  }
}
