import _ from 'lodash'
import AuthenticationField from '../authenticationField-model'
import lookUpMap from '../../lib/lookup-map'

const SERVICE_MAPPINGS = {
  ACCOUNT_VERIFICATION : 'ACCOUNT',
  ACCOUNT : 'ACCOUNT_QBSE'
}

function getDocTypeFromProviderServiceEntity( service ) {
  //Service type is something like 'TAX1099B_V100'
  //We have to transform that into a normalized doc type. Luckily we already have a method that does that
  //TODO: Refactor the parseFromRequest method name

  return parseFromRequest( service.name )
}

let tokens = [
  [ '1099-DIV', /1099.?DIV/ ],
  [ '1099-INT', /1099.?INT/ ],
  [ '1099-OID', /1099.?OID/ ],
  [ '1099-B', /1099.?B/ ],
  [ '1099-R', /1099.?R/ ],
  [ '1099-MISC', /1099.?MISC/ ],
  [ '1099-G', /1099.?G/ ],
  [ '1098-E', /1098.?E/ ],
  [ '1098-T', /1098.?T/ ],
  [ '1040', /1040/ ],
  [ '1098', /1098/ ],
  [ '1040-A', /1040.?A/ ],
  [ '1040-EZ', /1040.?EZ/ ],
  [ '1098-G', /1098.?G/ ],
  [ '1095-A', /1095.?A/ ],
  [ 'W2', /W2/ ],
  [ 'ACCOUNT', /ACCOUNT/ ],
  [ 'ACCOUNT_VERIFICATION', /ACCOUNT_VERIFICATION/ ]
]

function parseFromRequest( parseRequest ) {
  let noMatch = null

  if ( !parseRequest ) {
    return noMatch
  }

  let toSearch = parseRequest.toUpperCase()
  for ( let i = 0; i < tokens.length; i++ ) {
    if ( tokens[ i ][ 1 ].test( toSearch ) ) {
      return tokens[ i ][ 0 ]
    }
  }

  return noMatch
}

function ProviderModel() {
  this.id = ''
  this.legacyId = ''
  this.name = ''
  this.active = ''
  this.type = ''
  this.url = ''
  this.phoneNumber = ''
  this.thumbnail = ''
  this.disclaimerParagraph1 = ''
  this.disclaimerParagraph2 = ''
  this.disclaimerUrl = ''
  this.disclaimerUrlText = ''
  this.logo = {
    uri: '',
    height: 0,
    width: 0
  }
  this.supportedDocTypes = []
  this.supportedEntities = []
  this.authenticationFieldsByChannel = {}
  this.recommedForDocTypes = []
  this.recommendDocTypesDisplayOrder = {}
  this.isTransientProvider = ''
  this.score = 0
}

ProviderModel.prototype = {
  //hydrate from a provider as defined by the V2/provider back end service
  initializeFromProviderServiceV2: function initializeFromProviderServiceV2( provider ) {
    let self = this
    self.id = provider.id
    self.legacyId = provider.legacyId

    //strip -Test from registry data (working around undesired QA behavior)
    self.name = provider.name.replace( '-Test', '' )
    //remove multiple spaces spaces
    self.name = self.name.replace( /\s\s+/g, ' ' )
    self.active = provider.active

    if ( provider.logo ) {
      self.logo = {
        uri: provider.logo.uri,
        height: provider.logo.height,
        width: provider.logo.width
      }
    }

    self.url = provider.url
    self.phoneNumber = provider.phoneNumber
    self.thumbnail = provider.thumbnail

    if ( provider.helpInfo ) {
      self.disclaimerParagraph2 = provider.helpInfo.helpText
      self.disclaimerUrl = provider.helpInfo.url
      self.disclaimerUrlText = provider.helpInfo.urlText
    }
  },

  initializeFromStaticProviderData: function initializeFromStaticProviderData( provider ) {
    let self = this
    //strip -Test from registry data (working around undesired QA behavior)
    self.name = provider.name.replace( '-Test', '' )
    //remove multiple spaces spaces
    self.name = self.name.replace( /\s\s+/g, ' ' )

    if ( !self.id ) {
      self.id = self.name
    }
    if ( provider.logo ) {
      self.logo = {
        uri: provider.logo.uri,
        height: provider.logo.height,
        width: provider.logo.width
      }
    }

    if ( lookUpMap.providers[ self.name ] ) {
      self.phoneNumber = lookUpMap.providers[ self.name ].phone
      self.url = lookUpMap.providers[ self.name ].url
      self.thumbnail = lookUpMap.providers[ self.name ].thumbnailUrl

      if ( !self.logo.uri || lookUpMap.providers[ self.name ].overrideLogo === true ) {
        self.logo.uri = lookUpMap.providers[ self.name ].logoUrl
      }
    }
  },

  buildAuthenticationFields: function buildAuthenticationFields( provider ) {
    //the widget only supports ofx, so we explicitly go into the channels object to pull out the ofx auth fields
    // (user id, password).
    let self = this
    let authenticationFieldsByChannel = self.authenticationFieldsByChannel //self.authenticationFieldsByChannel not available in $.each
    let supportedDocTypes = self.supportedDocTypes
    let supportedEntities = self.supportedEntities

    if ( provider.channels ) {

      const validChannels = provider.channels
      .filter( channel => channel.channelType === 'ofx2' || channel.channelType === 'webIntegration' )
      .filter((channel, index, self) =>  self.findIndex(c =>  c.channelType === channel.channelType ) === index)

      _.forEach( validChannels, ( channel ) => {
        if ( channel.channelType === 'ofx2' || channel.channelType === 'webIntegration' ) {
          if ( !!channel.authenticationInfo && !!channel.authenticationInfo.authenticationMapping ) {

            self.disclaimerParagraph1 = channel.authenticationInfo.instructionText

            _.forEach( channel.authenticationInfo.authenticationMapping, ( authMapping ) => {
              let normalizedAuthMapping = new AuthenticationField()
              normalizedAuthMapping.initializeFromProviderServiceV2( authMapping )

              if ( !authenticationFieldsByChannel[ channel.channelType ] ) {
                authenticationFieldsByChannel[ channel.channelType ] = []
              }
              authenticationFieldsByChannel[ channel.channelType ].push( normalizedAuthMapping )
            } )

          }

          if ( channel.services ) {
            _.forEach( channel.services, ( service ) => {
              const newService  = Object.assign({}, service )
              const documentType = getDocTypeFromProviderServiceEntity( newService )
              const name =  SERVICE_MAPPINGS[ newService.name ] || newService.name

              if ( documentType ) {
                supportedDocTypes.push( name )

                //also add doc object to supported entities array
                supportedEntities.push( {
                  name: name,
                  fullAvailabilityDate: newService.fullAvailabilityDate,
                  partialAvailabilityDate: newService.partialAvailabilityDate,
                  channel: channel.channelType
                } )
              }
            } )
          }
        }
      } )
    }
  },

  augmentStaticData: function augmentStaticData() {
    //augment with our static data, if needed & available
    let self = this
    if ( lookUpMap.providers[ self.name ] ) {
      if ( !self.phoneNumber ) {
        self.phoneNumber = lookUpMap.providers[ self.name ].phone
      }
      if ( !self.url ) {
        self.url = lookUpMap.providers[ self.name ].url
      }
      if ( !self.thumbnail ) {
        self.thumbnail = lookUpMap.providers[ self.name ].thumbnailUrl
      }

      //We use provider logo first and foremost, with Mechanical Turk Logo as a backup... unless we've
      //manually deemed it should override it (because the provider logo isn't so good)
      if ( !self.logo.uri || lookUpMap.providers[ self.name ].overrideLogo === true ) {
        self.logo.uri = lookUpMap.providers[ self.name ].logoUrl
      }
    }
  },

  isInactiveProviders: function isInactiveProviders() {
    let self = this
    _.forEach( lookUpMap.inactiveProviders, ( provider ) => {
      if ( provider.toLowerCase().trim() === self.name.toLowerCase().trim() ) {
        self.active = false
        return false
      }
    } )
  },

  isRecommendedProvider: function isRecommendedProvider() {
    let self = this

    //inactive providers can not be recommended
    if (!self.active) {
      return
    }

    _.forEach( tokens, ( docType ) => {
      if ( lookUpMap.recommendedProvidersByDocType[ docType[ 0 ] ] ) {
        //support lookup based on name or ID
        let index = lookUpMap.recommendedProvidersByDocType[ docType[ 0 ] ].indexOf( self.name )
        if ( index <= -1 ) {
          index = lookUpMap.recommendedProvidersByDocType[ docType[ 0 ] ].indexOf( self.id )
        }
        if ( index > -1 ) {
          self.recommedForDocTypes.push( docType[ 0 ] )
          self.recommendDocTypesDisplayOrder[ docType[ 0 ] ] = index + 1
        }
      }
    } )
  },

  isTransientProviderCheck: function isTransientProviderCheck() {

    let self = this
    self.isTransientProvider = false

    //check if entire provider is transient
    let normalizedName = self.name.toLowerCase().trim()
    for ( let i = 0; i < lookUpMap.transientProviders.length; i++ ) {
      if ( normalizedName.indexOf( lookUpMap.transientProviders[ i ].toLowerCase().trim() ) > -1 ) {
        self.isTransientProvider = true
      }
    }

    // check if any fields are transient.. I think we're going to have to deprecate at this level given that it could be transient for one channel but not another
    _.forEach( self.authenticationFieldsByChannel, ( channel ) => {
      _.forEach( channel, ( authField ) => {
        if ( authField.isTransientField ) {
          self.isTransientProvider = true
        }
      } )
    } )


  },

  shouldDisplayLogoInAuthPage: function shouldDisplayLogoInAuthPage() {
    let self = this
    self.displayLogoInAuthPage = false
    _.forEach( lookUpMap.displayLogoInAuthPage, ( provider ) => {
      if ( provider.toLowerCase().trim() === self.name.toLowerCase().trim() ) {
        self.displayLogoInAuthPage = true
        return false
      }
    } )
  },
  /*
   *  If the provider preference is less then 3 then we will give the score a zero.
   *  @value => is a provider object from the provider response
   */
  setProviderPreferenceLevel: function setProviderPreferenceLevel( value ) {
    let self = this
    _.forEach( value.channels, ( channel ) => {
      if ( channel.preference === 1 ) {
        self.score = channel.preference
      }
    } )
  }
}

module.exports = ProviderModel
