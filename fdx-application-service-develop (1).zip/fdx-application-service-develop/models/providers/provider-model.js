import moment from 'moment'
import normalizeP from './normalize-providers'
import config from '../../lib/config'

export default class ProviderModel {
  constructor() {
    this.results = {}
  }
  get providers() {
    return this.results
  }
  set providers({ body, handlerOptions }) {
    this.results.providers = normalizeP( body, handlerOptions.type )
    this.results.status = {
      zone: config.ENV,
      lastRunTime: moment( new Date() ).format( 'dddd, MMMM Do YYYY, h:mm:ss a' ),
      date: new Date()
    }
  }
}
