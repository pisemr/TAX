
export default class ProviderListModel {
  constructor(provider) {
    this.id = provider.id || ''
    this.name = provider.name || ''
    this.active = provider.active || false
    this.type = provider.type || ''
    this.logos = provider.logos || []
  }
}
