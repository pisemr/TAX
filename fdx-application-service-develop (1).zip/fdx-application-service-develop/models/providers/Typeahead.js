import objPath from 'object-path'
import { getCompliantLogo } from '../../lib/vault-utils'
import { getAllProviderId } from '../../services/providers'
import ProviderDetail from '../../models/providers/ProviderDetail'

const MERGER = 'MERGER_OR_ACQUISITION'
const PARTNERSHIP = 'SAME_CONNECTIVITY'
const getAssociationType = (type) => (reference) => reference.association_type === type

export default class TypeaheadModel {
  constructor( result, parentProviderDetails ) {
    let logos = objPath.get(result, 'logos.logos', [])

    this.id = result.provider_id
    this.legacyId = result.legacy_id
    this.name = result.name
    // if anything === 0 dont use it
    this.logoUrl = getCompliantLogo(logos)
    this.url = objPath.get(result, 'home_page_urls.0', '')
    this.loginUrl = objPath.get(result, 'login_urls.0', '')
    this.multiplechannel = result.ismultichannel
    this.ispartner = result.ispartner
    this.businessOverlayEnabled = !!result.isoverlayenabled
    this.parent = parentProviderDetails || null
  }

  static createInstance(result, req) {
    const providerReferenceObj = result.provider_reference
    const providerReference = providerReferenceObj ? providerReferenceObj.provider_reference : []
    let providerId = ''
    let type = ''

    if(providerReference.length) {
      let index = providerReference.findIndex(getAssociationType(MERGER))
      if(index > -1) {
        providerId = providerReference[index].id
        type = MERGER
      } else {
        index = providerReference.findIndex(getAssociationType(PARTNERSHIP))
        if(index > -1) {
          providerId = providerReference[index].id
          type = PARTNERSHIP
        }
      }
    }

    return new Promise((resolve) => {
      if(type) {
        //if its M&A - get Provider details
        getAllProviderId( req, providerId ).then(({ body }) => {
          resolve( new this( result, Object.assign({ type }, new ProviderDetail(body, req.query.service)) ) )
        })
        .catch( ( error ) => {
          console.log('error in getting parent provider data', error)
        } )
      } else {
        //if its not M&A return empty object
        resolve(new this(result))
      }
    })
  }
}
