export default class AddProviderModel {
  constructor(body={}) {
    this.name = body.name
    this.url = body.url
  }

  get logEntry() {
    return `requestProviderAdd=true providerName=${this.name} providerUrl=${this.url}`
  }
}
