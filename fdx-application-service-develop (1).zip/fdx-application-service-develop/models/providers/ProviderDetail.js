import objectPath from 'object-path'
import { getCompliantLogo } from '../../lib/vault-utils'
import providerConfig from '../../constants/provider-configuration'

// function _isOfx( channel={} ) {
//   return channel.channelType.indexOf('ofx') > -1
// }

function _getAvailabilityDate(service) {
  //wiki reference: https://wiki.intuit.com/pages/viewpage.action?spaceKey=FDP&title=Availability+Date#AvailabilityDate-AddConnection
  let now = new Date()
  // Start December 1st of current year
  let startDate = new Date(`12/1/${now.getFullYear()}`)
  // Convert the date from Provider Service to a real Date if it exists
  let providerDate = service.fullAvailabilityDate || service.partialAvailabilityDate
  let availabilityDate = providerDate ? new Date(providerDate) : null

  // is now greater then December 1st (current year) and less then the Availability Date
  if ( !!availabilityDate && now >= startDate && now <= availabilityDate ) {
    return availabilityDate
  }
  return ''
}

function _fieldShouldBeSecret(field) {
  let mappingTarget = field.mappingTarget[0]
  if(!mappingTarget)
    return false

  switch (mappingTarget.toLowerCase()) {
    case 'ssn' : return true
    case 'password' : return true
    default :
      return false
  }
}

function _getSiblingProviders(providers) {
  return providers.length ? providers.find(provider => {
    return (provider.associationType === 'RETRY_CREDENTIAL') &&
    (provider.referenceType === 'sibling')}) : null
}

function _mapService(service) {
  return {
    type: service.name,
    availabilityDate: _getAvailabilityDate( service ),
    lookBackDays: service.lookBackDays
  }
}

function _getPreferredChannelData( channels=[], serviceTypes=[]) {



  function _matchServiceType(service) {
    return serviceTypes.includes(service.name)
  }

  const sortedChannels = channels.sort((a, b)=> {
    if (a.preference > b.preference) {
      return 1
    }
    if (a.preference < b.preference) {
      return -1
    }
    return 0
  })

  const filterdChannels = sortedChannels.filter(channels=>
    channels.services && channels.services.filter(_matchServiceType).length > 0
  )

  // - filter by service types - DONE
  // - if provider supports service type in only channel return it - DONE
  // - if provider does not support service type, return isSupported:false
  // - if provider does support service type more then 1 return highest preference - DONE
  // - in all cases, if the chosen channel is 'supposed to' have authenticationFields (supposed to logic needs to be defined, could be for channelType oauth and CAF), and does not throw an error -TODO

  let preferredChannel = filterdChannels[0] || sortedChannels[0] || channels[0]

  // ignore the preferences and make SS as preferred channel if CAF or WebAuth entity is present
  let cafChannel = filterdChannels.find(channel => {
    return !!channel.caf
  })

  let webAuthChannel = filterdChannels.find(channel => {
    return !!channel.webAuth
  })

  if(cafChannel || webAuthChannel) {
    let screenScraping = filterdChannels.find(channel => {
      return (channel.channelType === 'webIntegration')
    })
    preferredChannel = screenScraping
  }


  //TODO: Throw away code... this is specifically for the Mint unsupported Biller flow.
  // const services = preferredChannel && Array.isArray(preferredChannel.services) ? preferredChannel.services.map(service=>service.name) : []
  // get rid of code above when we do the real unsupported provider work
  if ( preferredChannel ) {
    let PreferredChannel = objectPath(preferredChannel)
    let __objMap = objectPath.get(preferredChannel, 'authenticationInfo.authenticationMapping')
    let authenticationMapping = __objMap ? __objMap.map(field=>{
      let newField = Object.assign({}, field)
      if (!newField.hideChars && _fieldShouldBeSecret(newField)) {
        newField.hideChars = true
      }
      return newField
    }) : null

    let channelType = PreferredChannel.get('channelType', '')
    let channelId = PreferredChannel.get('id', '')
    let services = PreferredChannel.get('services', []).map(_mapService)
    let serviceTypeService = services ? services.filter(_matchServiceType)[0] || {} : {}
    let taxYear = PreferredChannel.get('globalConfig.parameter',[]).find(param=>param.key==='taxYear')

    return {
      channelType: channelType,
      channelId: channelId,
      authenticationMapping: authenticationMapping? authenticationMapping.map(field=>new AuthMapping(field)) : null,
      services: services,
      taxYear: taxYear,
      type: serviceTypeService.type || null,
      availabilityDate: serviceTypeService.availabilityDate || null,
      isSupported: !( services.length === 1
        && services[0].type === 'ANONYMOUS_BILL' )
    }
  } else {
    return {
      isSupported: false
    }
  }
}

export function _getPartnerAuthChannel( channels = {}, providerId ) {
  let partnerAuthChannel  = channels.find(channel => {
    return !!channel.partnerAuth
  })

  if (partnerAuthChannel) {
    return {
      partnerUID: partnerAuthChannel.partnerAuth.partnerUID,
      partnerAuthPreferred: partnerAuthChannel.preference === 1,
      channelId: partnerAuthChannel.id,
      services: partnerAuthChannel.services.map(_mapService),
      oauthConsentLevel: providerConfig[providerId] ? providerConfig[providerId].oauthConsent : null
    }
  }
}

export function _getCaf( channels = {}, id) {
  let cafChannel  = channels.find(channel => {
    return !!channel.caf
  })

  if (cafChannel) {
    return {
      inputFields: cafChannel.caf.inputFields,
      channelId: cafChannel.id,
      cafPostAddress: providerConfig[id] ? providerConfig[id].cafPostAddress : null
    }
  }
}

export function _getWebAuth( channels = {} ) {

  let webAuthChannel  = channels.find(channel => {
    return !!channel.webAuth
  })

  if (webAuthChannel) {
    return {
      inputFields: webAuthChannel.webAuth.inputFields,
      channelId: webAuthChannel.id
    }
  }
}

export class AuthMapping {
  constructor( field ) {
    this.authenticationText = field.authenticationText
    this.display = field.display
    this.displayOrder = field.displayOrder
    this.encrypted = field.encrypted
    this.hideChars = field.hideChars
    this.stripChars = field.stripChars
    this.id = field.id
    this.mappingTarget = field.mappingTarget ? field.mappingTarget[0] : null
    this.maxLength = field.maxLength
    this.optional = field.optional
    this.authenticationFieldValue = field.authenticationFieldValue
    this.regexConstraint = field.regexConstraint
    this.minLength = field.minLength
    this.regexValidationMessage = field.regexValidationMessage
  }
}

export default class ProviderDetailModel {
  constructor( providerData = {}, serviceTypes=[]) {
    const PROVIDER = objectPath(providerData)

    let {
      channelType=null,
      authenticationMapping=null,
      services=null,
      taxYear='',
      channelId=null,
      type=null,
      availabilityDate=null,
      isSupported=true
    } = _getPreferredChannelData(providerData.channels, serviceTypes)

    this.id = PROVIDER.get('id', '')
    this.legacyId = PROVIDER.get('legacyId', '')
    this.name = PROVIDER.get('name', '')
    this.logoUrl = getCompliantLogo(PROVIDER.get('logos.logo'))
    this.phoneNumber = PROVIDER.get('contacts.contact.0.phone', '')
    this.helpText = PROVIDER.get('helpInfo.helpText', '')
    this.homePageUrl = PROVIDER.get('websites.website.0.homePageUrl', '')
    this.taxYear = taxYear.value
    this.availabilityDate = availabilityDate
    this.channelId = channelId
    this.serviceType = type
    this.authType = channelType
    this.authFieldnMapping = authenticationMapping
    this.services = services
    this.partnerAuth = _getPartnerAuthChannel(providerData.channels, providerData.id)
    this.caf = _getCaf(providerData.channels, providerData.id)
    this.webAuth = _getWebAuth(providerData.channels)
    this.retryCredentials = _getSiblingProviders(PROVIDER.get('providerReferences.providerReference', {}))
    this.isSupported = isSupported
    this.primaryCurrencyCode = PROVIDER.get('primaryCurrencyCode', '')
  }
}
