import _ from 'lodash'
import objectPath from 'object-path'
import ProviderModel from './provider-response-model'
import lookUpMap from '../../lib/lookup-map'

function mergeStaticProvidersWithDynamicProviders( dynamicProviders ) {
  let allProviders = []
  let activeProvidersMap = {}
  _.forEach( dynamicProviders, ( normalizedProvider ) => {
    allProviders.push( normalizedProvider )
    activeProvidersMap[ normalizedProvider.name ] = normalizedProvider
  } )
    //add any providers we have static data for that are currently missing from the response
  _.forEach( lookUpMap.providers, ( staticProvider ) => {
    if ( !activeProvidersMap[ staticProvider.name ] ) {
      let normalizedStaticProvider = new ProviderModel()
      normalizedStaticProvider.initializeFromStaticProviderData( staticProvider )
      normalizedStaticProvider.active = false
      allProviders.push( normalizedStaticProvider )
    }
  } )
  return allProviders
}

function getNormalizedProvidersFromProviderResponse( response ) {
  let providers = []

  _.forEach( response, ( value ) => {
    let normalizedProvider = new ProviderModel()
    normalizedProvider.initializeFromProviderServiceV2( value )
    normalizedProvider.buildAuthenticationFields( value )
    normalizedProvider.augmentStaticData()
    normalizedProvider.isInactiveProviders()
    normalizedProvider.isRecommendedProvider()
    normalizedProvider.isTransientProviderCheck()
    providers.push( normalizedProvider )
  } )

  return providers
}


function getNormalizedProvidersFromEINResponse( response ) {
  let providers = []
  let normalizedProvider
  _.forEach( response, ( value ) => {

    //Filter out inactive providers
    if ( value.active ) {
      normalizedProvider = new ProviderModel()
      normalizedProvider.setProviderPreferenceLevel( value )
      normalizedProvider.initializeFromProviderServiceV2( value )
      normalizedProvider.buildAuthenticationFields( value )
      normalizedProvider.augmentStaticData()
      normalizedProvider.isInactiveProviders()
      normalizedProvider.isRecommendedProvider()
      normalizedProvider.isTransientProviderCheck()
      normalizedProvider.shouldDisplayLogoInAuthPage()
      providers.push( normalizedProvider )
    }
  } )
  return providers
}

function getTopRankedProviderForResponse( providers ) {
  let highestRankedProvider = []
  providers.forEach( ( provider ) => {
    if ( provider.score === 1 ) {
      highestRankedProvider.push( provider )
    }
  } )
  return highestRankedProvider
}


module.exports = function NormalizeProviders( data, type ) {
  let normalizedProviders

  if ( type ) {
    if ( type === 'ein' ) {
      normalizedProviders = getNormalizedProvidersFromEINResponse( data.providers )
      normalizedProviders = getTopRankedProviderForResponse( normalizedProviders )
    } else {
      normalizedProviders = getNormalizedProvidersFromProviderResponse( data.providers )
    }
  } else {
    normalizedProviders = getNormalizedProvidersFromProviderResponse( data.providers )
    normalizedProviders = mergeStaticProvidersWithDynamicProviders( normalizedProviders )
  }

  let parsedProviders = []
  normalizedProviders.forEach( ( provider ) => {
    let model = objectPath( provider )
    let active = model.get( 'active' )

    let parsedProvider = {
      id: model.get( 'id' ),
      name: model.get( 'name' ),
      url: model.get( 'url', '' ),
      phoneNumber: model.get( 'phoneNumber', '' ),
      thumbnailUrl: model.get( 'thumbnail', '' ),
      logoUrl: model.get( 'logo.uri', '' ),
      disclaimerParagraph1: model.get( 'disclaimerParagraph1', '' ),
      disclaimerParagraph2: model.get( 'disclaimerParagraph2', '' ),
      disclaimerUrl: model.get( 'disclaimerUrl', '' ),
      disclaimerUrlText: model.get( 'disclaimerUrlText', '' ),
      supportedDocTypes: model.get( 'supportedDocTypes', [] ),
      supportedEntities: model.get( 'supportedEntities', [] ),
      recommendedForDocTypes: model.get( 'recommedForDocTypes', [] ),
      recommendDocTypesDisplayOrder: model.get( 'recommendDocTypesDisplayOrder', [] ),
      authenticationFieldsByChannel: model.get( 'authenticationFieldsByChannel', {} ),
      isTransientProvider: model.get( 'isTransientProvider' ),
      isActive: active,
      displayLogoInAuthPage: model.get( 'displayLogoInAuthPage' ),
      score: model.get( 'score' )
    }

    //set ofxAuthenticationFields for backwards compatibility, until Link moves to r36+
    parsedProvider.ofxAuthenticationFields = parsedProvider.authenticationFieldsByChannel[ 'ofx2' ]
    if ( !parsedProvider.ofxAuthenticationFields || parsedProvider.ofxAuthenticationFields.length === 0 ) {
      parsedProvider.ofxAuthenticationFields = parsedProvider.authenticationFieldsByChannel[ 'webIntegration' ]
    }
    if ( !parsedProvider.ofxAuthenticationFields || parsedProvider.ofxAuthenticationFields.length === 0 ) {
      parsedProvider.ofxAuthenticationFields = []
    }
    parsedProviders.push( parsedProvider )


  } )
  return parsedProviders
}
