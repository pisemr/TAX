

export default class MigrateModel {
  constructor( body = {} ) {
    this.force = body.force ? true : false
    this.targetCredentialSetId = body.targetCredentialSetId
    this.reason = body.reason || {
      'code' : 'NA',
      'message' : ''
    }
  }
}
