
export default class ApplicationExperiment {
  constructor(experiment) {
    this.id = experiment.id
    this.label = experiment.label
    this.isPreprod = experiment.label.indexOf('-PREPROD') !== -1
  }
 }
