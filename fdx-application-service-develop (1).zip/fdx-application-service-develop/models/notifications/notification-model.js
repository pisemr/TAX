
  const MAPPED_MIGRATIONS = [ 'CREATED', 'COMPLETED', 'IN_PROGRESS' ]
  const MIGRATION = 'migration'
  const CREDENTIAL = 'credential'
  const SEVERITY = {
    INFO : 'INFO',
    WARN : 'WARN',
    ERROR : 'ERROR'
  }
  const DC_CRED_TYPES = [ 'OAuth', 'CAF', 'WebAuth' ]
  const MIGRATION_PROJECT_TARGET_MAPPING = {
    'OAUTH' : 'OAuth',
    'CAF' : 'CAF',
    'WEB_AUTH' : 'WebAuth'
  }
  
  const __getNotificationType = (migration) => {
    let __type = CREDENTIAL

    if(migration && migration.status && (MAPPED_MIGRATIONS.indexOf(migration.status) >= 0)) {
      __type = MIGRATION
    }

    return __type
  }

  const __getCredentialType = (notificationType, credential, migrationProject) => {
    if(notificationType === MIGRATION && migrationProject.target && migrationProject.target.authorizationMethod) {
      return MIGRATION_PROJECT_TARGET_MAPPING[migrationProject.target.authorizationMethod]
    }

    return credential.type
  }

  const __getStatusCode = (migration, credential, notificationType) => {
    if(notificationType === MIGRATION) {
      return migration.status
    }

    return credential.statusDetail ? credential.statusDetail.code : ''
  }

  const __getReasonCode = (migration, notificationType) => {
    if(notificationType === MIGRATION) {
      return migration.reason ? migration.reason.code : null
    }

    return null
  }

  const __getSeverity = (notificationStatusCode, notificationReasonCode, notificationType, credentialType, migration) => {
    if(notificationType === MIGRATION) {
      switch(notificationStatusCode) {
        case 'CREATED' : 

          if((credentialType === 'OAuth') && migration && !isNaN(migration.daysLeft)) {
            return (migration.daysLeft <= 0) ? SEVERITY.ERROR : (migration.daysLeft <= 15) ? SEVERITY.WARN : SEVERITY.INFO
          }

          return SEVERITY.INFO
        case 'IN_PROGRESS' : 
          return notificationReasonCode === 'NOT_ENOUGH_DATA' ? SEVERITY.WARN : SEVERITY.INFO                        
        case 'COMPLETED' :
          return notificationReasonCode === 'GRACE_PERIOD_EXPIRED' ? SEVERITY.ERROR : SEVERITY.INFO
      }
    }

    if(notificationType === CREDENTIAL) {
      if(credentialType === 'CAF') {
        switch(notificationStatusCode) {
          case '205':
          case '206':
          case '207':
            return SEVERITY.INFO
          case '208':
          case '209':
          case '210':
          case '211':
          case '212':
          case '213':
          case '214':
          case '215':
          case '216':
          case '217':
          case '218':
          case '219':
          case '220':
          case '221':
          case '222':
          case '223':
          case '224':
          case '225':
          case '227':
          case '228':
          case '229':
          case '230':
            return SEVERITY.WARN
          case '226':
            return SEVERITY.ERROR 
          default:
            return SEVERITY.INFO   
        }
      }

      if(credentialType === 'WebAuth') {
        switch(notificationStatusCode) {
          case '336':
            return SEVERITY.WARN
          case '339':
          case '338':
            return SEVERITY.ERROR 
          default:
            return SEVERITY.INFO   
        }

      }
    }

    return SEVERITY.INFO
  }

  export const createNotificationModel = (migration = {}, credential = {}, migrationProject = {}) => {
    let __model = { }
    __model.notificationType = __getNotificationType(migration)
    __model.credentialType = __getCredentialType(__model.notificationType, credential, migrationProject)

    if (__model.notificationType !== MIGRATION && (DC_CRED_TYPES.indexOf(__model.credentialType) < 0)) {
      return {}
    } 

    __model.notificationStatusCode = __getStatusCode(migration, credential, __model.notificationType)
    __model.notificationReasonCode = __getReasonCode(migration, __model.notificationType)
    __model.credentialSetId = credential.credentialSetId
    __model.severity = __getSeverity(__model.notificationStatusCode, __model.notificationReasonCode, __model.notificationType, __model.credentialType, migration)
    __model.priority = 'LOW' //Future
    __model.accountId = migration.sourceAccountId
    __model.details = __model.notificationType === MIGRATION ? migration : credential
    __model.credStatusDetails = credential ? credential.statusDetail : null
    return __model
  }
