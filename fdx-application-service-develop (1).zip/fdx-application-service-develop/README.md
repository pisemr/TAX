# FDX Application Service 

[![Build Status](https://pub-bu-cto-jenkins.prod1-ibp.a.intuit.com/jenkins/buildStatus/buildIcon?job=CTO/Vault/cto-vault-service-ci)](https://pub-bu-cto-jenkins.prod1-ibp.a.intuit.com/jenkins/job/CTO/Vault/cto-vault-service-ci)
[![Code Coverage](https://pub-bu-cto-jenkins.prod1-ibp.a.intuit.com/jenkins/buildStatus/coverageIcon?job=CTO/Vault/cto-vault-service-ci)](https://pub-bu-cto-jenkins.prod1-ibp.a.intuit.com/jenkins/job/CTO/Vault/cto-vault-service-ci)


The FDX Application Service is a REST service that handles the orchestration between FDX Widgets and backend capability services, in accordance with the CTO-DEV Widget Strategy found here: [https://wiki.intuit.com/display/iea/UI+Widgets](https://wiki.intuit.com/display/iea/UI+Widgets).

This application is built on [Express](http://expressjs.com/) and using heavy es2105 features.

## ES2015 & Babel

Our service leverages features from the es2015 spec via [Babel](https://babeljs.io/). These features are defined in the `.eslintrc` file.

```ssh
"ecmaFeatures": {
  "arrowFunctions": true,
  "blockBindings": true,
  "classes" : true,
  "destructuring": true,
  "forOf" : true,
  "generators": true,
  "modules" : true,
  "spread" : true,
  "templateStrings" : true
}
```

## Prerequisites

Install [Node](https://nodejs.org/) (currently CTODev only supports v0.10.36, but we run in v5 +)

-- A suggestion: install [n](https://github.com/tj/n), it's great for jumping around node versions

## Installation

Clone repository locally:

```sh
git clone https://github.intuit.com/CTO-Dev-FDS-FDX/fdx-application-service.git
cd fdx-application-service
npm install
```

## Tests

Test frameworks user are Mocha & Chai.

Run tests via `npm test`. Or if you want to see the Istanbul code coverage you can run `npm run coverage`, and navigate to `https://{localhost you are developing on}/content/coverage/lcov-report/index.html` to see the details

To test individual routes you can use `gulp unit --test <unit test>`.
Below are the supported unit tests: ( example `gulp unit --test connections` )

```
choices: [
  'abtesting',
  'authenticate',
  'connections',
  'credentials',
  'documents',
  'oauth',
  'profile',
  'providers',
  'errorModel',
  'postBodyModel',
  'middleware',
  'errorModel',
  'postBodyModel'
]
```

## Running

We use like to use [nodemon](https://www.npmjs.com/package/nodemon).

To install nodemon `npm install -g nodemon`. You can launch the server by typing `npm run local` ... this runs all of the local environment variables for you: `PORT=4430 NODE_ENV=local nodemon server.js`.

Access the api:

If local, make sure to tack on the port number...

***https://{ your local host name }:4430/v1/providers***

## Releasing

To release to develop, update [pom.xml](./pom.xml) version number and rev [package.json](./package.json) version.

For Release Candidate
```
// pom.xml
<version>1.77.0 -> 1.78.0-SNAPSHOT</version>

// package.json
"version": 1.77.0 -> 1.78.0
"build": 1.77.0 -> 1.78.0

```

## Application File Structure
```
/cert
All of the SSL certs - used only for local development

/config
Application configuration including environment-specific configs

/controllers
This is all of our business logic. It makes a call a service and once its back it passes it on to the models then hands back a nice packaged JSON response

/constants
constant never changing data

/lib
Common libraries to be used across the app

/middleware
This is all of the custom and app specific middleware

/models
Our models are what the services call to format the data returned by the capability services

/routes
These are the definition of our API. GET, POST, PUT, DELETE

/services
The services are the requests to the capability services (using request module). These are pretty generic, they just get data.

/static
Static content for providers (used in the UI, attached to the provider response)

/swagger
place holder for swagger implementation

/tasks
gulp tasks

/test
Functional and Unit tests

```

## Endpoints <a name="endpoints"></a>

View the design documentation on our [wiki](https://wiki.intuit.com/pages/viewpage.action?title=Vault+Application+Service+API+Design&spaceKey=FDP)...

[Sample HTTP Request](https://github.intuit.com/CTO-Dev-FDS-Vault/VaultApplicationServices/wiki/HTTP-Requests-for-Services)

Endpoint documentation can be found [here](https://github.intuit.com/CTO-Dev-FDS-Vault/VaultApplicationServices/wiki) in our wiki.


## Requests

FDX Application Service uses [Request](https://github.com/request/request) to make the base http request to the other, downstream, services.

## Status Codes

All of our downstream services respond with various error codes, in order to normalize this process this service responds with a 500 Status code, and provides the response code from the downstream service.

* 200 OK
* 201 Created
* 204 Deleted
* 302 Redirect
* 500 Server Error


## Mocks

### Errors
`/v1/{ end-point }?respondWithErrorCode=500.5200`

If you add the query string *respondWithErrorCode* to any endpoint with a valid error response code the response will automatically respond with that error and a dummy Normalized Error Response.

If an invalid response code is passed in (`/v1/{ end-point }?respondWithErrorCode=justin`), it will display 'justin', but the http status code will be 500 and the error.code will be 0000.

### Successful responses

`https://vault-prf.api.intuit.com/v1/{ end-point }?mockDependencies=true`

Basically, with this query sting param set to true we will just return mock data and not hit the downstream service. The major reason for this is for performance testing, but there could be others ...

NOTE: This feature is only available in our performance environment, so make sure you are on-boarded to it before trying it out.

## Swagger API
Coming soon...

## Logging

Some logging is being handled by the Intuit Service-Platform module [*sp-logging*](https://github.intuit.com/servicesplatform-node/sp-logging)...
In order to stay compliant with the FDS logging standards we have implemented [log4js](https://www.npmjs.com/package/log4js), the JavaScript alternative to log4j.
The FDS Logging Standard...found [here](https://wiki.intuit.com/pages/viewpage.action?title=Logging+Standard+in+FDS&spaceKey=FDP).

## Splunk

All of your Slunk information is in this [wiki](https://wiki.intuit.com/display/FICDS/Vault+UX#VaultUX-Splunk).

## Analytics

Analytic events are captured on every request sent from Node to a downstream service. To add to event object, [add property](https://github.intuit.com/CTO-Dev-FDS-FDX/fdx-application-service/blob/node-analytics/lib/analytics.js) and [update parser](https://github.intuit.com/FDSCategorization/FDPInsights/tree/master/fdp-denorm-etl/cto_fdp_widget_service).

## Modules

* "async": "^1.2.1"
* "babel-core": "^5.8.21"
* " body-parser": "^1.12.3"
* "compression": "^1.4.3"
* "cookie-parser": "^1.3.4"
* "cors": "^2.5.3"
* "cron": "^1.0.9"
* "express": "^4.3.0"
* "express-enrouten": "^1.2.1"
* "form-data": "^0.2.0"
* "http-proxy": "^1.11.1"
* "isp": "^0.1.12"
* "lodash": "^3.5.0"
* "log4js": "^0.6.26"
* "moment": "^2.9.0"
* "newrelic": "~1.24.0" - [Known NewRelic/Enrouten Issue](https://discuss.newrelic.com/t/express-route-problem-enrouten/12903/2)
* "nock": "^2.17.0"
* "node-cache": "^1.1.0"
* "object-path": "^0.9.1"
* "request": "~2.65.0"
* "request-debug": "^0.1.1"
