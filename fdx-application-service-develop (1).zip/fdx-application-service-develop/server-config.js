
import http from 'http'
import https from 'https'
import fs from 'fs'
import app from './index.js'
import logger from './lib/logger'
import {
  gracefulShutdown,
  getAllProvidersCron
} from './initializers'


http.globalAgent.maxSockets = Infinity
https.globalAgent.maxSockets = Infinity

const httpsOptions = {
  key: fs.readFileSync( __dirname + '/cert/nonprod.shoebox.ssl-key.pem' ),
  cert: fs.readFileSync( __dirname + '/cert/nonprod.shoebox.ssl-cert.pem' )
}

const server = isSecure( process.env.PORT )
  ? https.createServer( httpsOptions, app )
  : http.createServer( app )


server.listen( process.env.PORT, '127.0.0.1' )

server.on( 'listening', function () {
  logger.info( 'Server listening on port %d', process.env.PORT )
  init( server )
} )

function isSecure( port ) {
  return port === '4430'
    || port === '443'
}

function init( server ) {
  gracefulShutdown( server )
  getAllProvidersCron()
}


export default server
