#!/usr/bin/env node

/*
    This node script is used to do synthetic monitoring of our service. See https://wiki.intuit.com/display/FDP/FDX+Synthetic+Monitoring for details.

    Note this currently requires 3 secrets:

    - IAM User
    - Private auth (Intuit.platform.fdxinfrastructure.fdxmonitor) for loggin in
    - Browser auth for simulating browser calls (Intuit.platform.fdxinfrastructure.fdxmonitorbrowsersimulator)

    example usage:
    $ ./fdxmon.js -v -run ein_1 -relativePath .
 */

process.env.ISP_DISABLE_LOGGING = true;

require( 'babel-core/register' )
var program = require('commander');

var superagent = require('superagent');
var logger = require('superagent-logger');
var util = require('util');

var argv = require('yargs')
    .usage('Usage: $0 -v -run [monitorId]')
    .count('verbose')
    .option('run', {
      alias: 'r',
      describe: 'Run the particular monitor\nMonitors: ein_1, typeahead_1',
      type: 'string', /* array | boolean | string */
      nargs: 1,
      demand: true
    })
    .option('relativePath', {
        alias: 'p',
        describe: 'The relative path to directory',
        type: 'string', /* array | boolean | string */
        nargs: 1
    })
    .describe('verbose', 'Output more log messages')
    .help('help')
    .alias('help', 'h')
    .alias('verbose', 'v')
    .argv;

const RELATIVE_PATH = argv.relativePath ? argv.relativePath : '.';
var fdxLogger = require(RELATIVE_PATH + '/lib/logger');
var conf = require(RELATIVE_PATH + '/lib/config');
var tidGenerator = require(RELATIVE_PATH + '/lib/generate-tid');
const VERBOSE_LEVEL = argv.verbose;

if (VERBOSE_LEVEL === 0) {
  fdxLogger.setLevel('OFF');
}

fdxLogger.info("FDXMON: Running fdxmon");

var authentication = {
    ticket: '',
    userId: '',
    namespaceId: ''
};

var fdxServicehost = 'https://' + conf.host;

//per FDX-879, only use .net
fdxServicehost = fdxServicehost.replace(/.com/, '.net')

const IS_PROD = conf.ENV === 'prod.lvdc' || conf.ENV === 'prod.qdc';
const IS_PERF = conf.ENV === 'prf.lvdc' || conf.ENV === 'prf.qdc';
const SUCCESS = 0;
const WARNING = 1;
const ERROR = 2;


var invokeSynthenticMonitoringRequest = function(monitor) {
    fdxLogger.info("FDXMON: Running " + monitor.name + ": " + monitor.method.toUpperCase() + " " + fdxServicehost + monitor.url);
    var request = superagent[monitor.method](fdxServicehost + monitor.url)

    request.set('Content-Type', 'application/json')
        .withCredentials()
        .set('Accept', 'application/json')
        .set('Authorization', 'Intuit_APIKey intuit_apikey=' + conf.fdxMonitor.browserSimulatorApiKey)
        /*.set('Authorization', 'Intuit_IAM_Authentication intuit_token_type=IAM-Ticket,intuit_appid=' + conf.fdxMonitor.appId + ',intuit_app_secret=' + conf.fdxMonitor.appSecret)*/
        .set('intuit_offeringid', conf.apiGatewayConfig.offeringid)
        .set('intuit_tid', new tidGenerator().tid);

    if (IS_PROD) {
        request.set('Cookie', 'qbn.ticket=' + authentication.ticket + '; qbn.authid=' + authentication.userId + '; qbn.parentid=' + authentication.namespaceId);
    }
    else if (IS_PERF) {
        request.set('Cookie', 'qbn.prf.ticket=' + authentication.ticket + '; qbn.prf.authid=' + authentication.userId + '; qbn.prf.parentid=' + authentication.namespaceId);
    }
    else {
        request.set('Cookie', 'qbn.ptc.ticket=' + authentication.ticket + '; qbn.ptc.authid=' + authentication.userId + '; qbn.ptc.parentid=' + authentication.namespaceId);
    }

    if (monitor.body) {
        request.send(monitor.body);
    }

    request.end(function(requestError, res) {
        if (requestError) {
            if (VERBOSE_LEVEL !== 0) {
                fdxLogger.error("FDXMON:ERROR in " + monitor.name + " " + requestError);
            }
            else {
                console.error(monitor.name + " FAIL - " + monitor.output);
            }
            monitor.result = ERROR;
            onMonitorRequestCompleted();
        }

        //assert response to make sure it's what we expected
        var assertionFailed = false;
        try {
            assertionFailed = monitor.verifyResponse(res);
        }
        catch (ex) {
            if (VERBOSE_LEVEL !== 0) {
                fdxLogger.error("FDXMON:EXCEPTION verifying " + monitor.name);
            }
            else {
                console.error(monitor.name + " FAIL - " + monitor.output);
            }
            monitor.result = ERROR;
            onMonitorRequestCompleted();
        }

        if (assertionFailed) {
            if (VERBOSE_LEVEL === 0) {
              console.error(monitor.name + " FAIL - " + monitor.output);
            }
            monitor.result = ERROR;
            onMonitorRequestCompleted();
        }
        else {
            if (VERBOSE_LEVEL !== 0) {
                fdxLogger.info("FDXMON:SUCCESS: " + monitor.name);
            }
            else {
                console.log(monitor.name + " OK - " + monitor.output);
            }
            monitor.result = SUCCESS;
            onMonitorRequestCompleted();
        }
    });
};

//validates we can lookup an EIN
var einMonitor = function(id, ein, expectedEmployerName, expectedProviderName) {
    return {
        name: 'EIN',
        method: 'get',
        url: '/v1/providers?ein=' + ein,
        body: null,
        result: null,
        output: ein,
        id: id,
        verifyResponse: function(res) {
            var assertionFailed = false;

            if (res.body.employers.length !== 1) {
                fdxLogger.error("FDXMON:ERROR EIN lookup failed to return 1 employer");
                assertionFailed = true;
            }
            else if (res.body.employers[0].name.indexOf(expectedEmployerName) == -1) {
                fdxLogger.error("FDXMON:ERROR EIN lookup returned employerName  = " + res.body.employers[0].name + " instead of " + expectedEmployerName);
                assertionFailed = true;
            }

            if (res.body.providers.length !== 1) {
                fdxLogger.error("FDXMON:ERROR EIN lookup failed to return 1 provider");
                assertionFailed = true;
            }
            else if (res.body.providers[0].name.indexOf(expectedProviderName) == -1) {
                fdxLogger.error("FDXMON:ERROR EIN lookup returned providerName  = " + res.body.providers[0].name + " instead of " + expectedProviderName);
                assertionFailed = true;
            }
            return assertionFailed;
        }
    };
}

//validates we can search (typeahead)
var typeaheadMonitor = function(id, search) {
    return {
        name: 'Typeahead',
        method: 'get',
        url: '/v2/providers/typeahead?limit=30&start=0&query=' + search,
        body: null,
        result: null,
        output: search,
        id: id,
        verifyResponse: function(res) {
            var assertionFailed = false;
            var results = res.body.results;
            var numOfResults = results.length;
            for (var i = 0; i < numOfResults; i++) {
                if (results[i].name.toLowerCase().indexOf(search.toLowerCase()) === -1) {
                    fdxLogger.error("FDXMON:ERROR Typeahead returned invalid result - " + results[i] + "when searching" + search);
                    return true;
                }
            }
            return assertionFailed;
        }
    };
}

//Our list of Synthetic Monitor Tests
var monitors = [
 // einMonitor('ein_1', '770034661', 'Intuit Inc', IS_PROD ? 'ADP' : 'TpayPdSsUg'),
    typeaheadMonitor('typeahead_1', 'Vanguard')
];


var searchID = function(id) {
  for (var i = 0; i < monitors.length; i ++) {
    if (monitors[i].id === id){
      return monitors[i];
    }
  }
  return null;
}

var queuedMonitors = [];

if (argv.length > 5) {
  console.error("FDXMON: Too many arguments");
  process.exit(ERROR);
}
else if (argv.run === "all"){
  queuedMonitors = monitors;
}
else if (!isNaN(Number(argv.run ))) {
  queuedMonitors[0] = monitors[Number(argv.run )];
}
else if (searchID(argv.run) !== null) {
  queuedMonitors[0] = searchID(argv.run);
}
else {
  console.error("FDXMON: Invalid monitor id");
}

var accountsLoginUrl = 'https://' + conf.services.login.root + conf.services.login.path;
fdxLogger.info("FDXMON: Logging in to " + accountsLoginUrl);
//login & run tests



//curl -X POST --header 'Content-Type: application/json' --header 'Accept: application/json' --header 'intuit_originatingip: 123.45.67.89' --header 'intuit_offeringid: Intuit.platform.vaultux.vaultapplicationservice' --header 'intuit_tid: 1e2bd51d-a865-4d37-9ac9-c345dc59119b' --header 'Authorization: Intuit_IAM_Authentication intuit_appid=Intuit.platform.vaultux.vaultapplicationservice,intuit_app_secret=preprdBv92l6r1SprTQ37lrAbu1kT1Try3q06KBE,,intuit_token_type=IAM-Ticket' -d '{"username":"orlando.cardoso+4_iamtestpass@gmail.com","password":"Intuit01!"}' 'https://accounts-e2e.platform.intuit.net/v1/iamtickets/sign_in'
//curl -X POST --header 'Content-Type: application/json' --header 'Accept: application/json' --header 'intuit_originatingip: 123.45.67.89' --header 'intuit_offeringid: Intuit.platform.vaultux.vaultapplicationservice' --header 'intuit_tid: 1e2bd51d-a865-4d37-9ac9-c345dc59119b' --header 'Authorization: Intuit_IAM_Authentication intuit_appid=Intuit.platform.vaultux.vaultapplicationservice,intuit_app_secret=prdozhIyMqnzL0Eh1LsNSBJxUTEtKkmNMaN6EBgu,,intuit_token_type=IAM-Ticket' -d '{"username":"orlando.cardoso+1@gmail.com","password":"resist2FX!"}' 'https://accounts.platform.intuit.com/v1/iamtickets/sign_in'

//curl -X POST --header 'Content-Type: application/json' --header 'Accept: application/json' --header 'intuit_originatingip: 123.45.67.89' --header 'intuit_offeringid: Intuit.platform.fdxinfrastructure.fdxmonitor' --header 'intuit_tid: 1e2bd51d-a865-4d37-9ac9-c345dc59119b' --header 'Authorization: Intuit_IAM_Authentication intuit_appid=Intuit.platform.fdxinfrastructure.fdxmonitor,intuit_app_secret=prdAFXHHOkP3vHG4WsLWY2FBOVHRtQaLHHdC79WP,intuit_token_type=IAM-Ticket' -d '{"username":"fdx.monitor+1_iamtestpass@gmail.com","password":"Intuit01!"}' 'https://accounts.platform.intuit.net/v1/iamtickets/sign_in'


superagent
    .post('https://' + conf.services.login.root + conf.services.login.path)
    .send({
        'username':conf.fdxMonitor.ius_username,
        'password':conf.fdxMonitor.ius_password
    })
    .set('Content-Type', 'application/json')
    .set('Accept', 'application/json')
    .set('intuit_originatingip', '123.45.67.89')
    .set('intuit_offeringid', conf.fdxMonitor.appId)
    .set('Authorization', 'Intuit_IAM_Authentication intuit_token_type=IAM-Ticket,intuit_appid=' + conf.fdxMonitor.appId + ',intuit_app_secret=' + conf.fdxMonitor.appSecret)
    .set('intuit_tid', new tidGenerator().tid)
    .end(function(err, res) {
        // Calling the end function will send the request
        if (err) {
            fdxLogger.error("FDXMON:ERROR authenticating user:" + err);
            process.exit(ERROR);
        }
        else {//qbn.ptc.authid
            fdxLogger.info("FDXMON: GOT TICKET");
            authentication.ticket = res.body.iamTicket.ticket;
            authentication.userId = res.body.iamTicket.userId;
            authentication.namespaceId = res.body.iamTicket.namespaceId;
            for (var i = 0; i < queuedMonitors.length; i++) {
                invokeSynthenticMonitoringRequest(queuedMonitors[i]);
            }
        }
    });

//Called after each async monitor returns. When they all have returned, we'll exit with the appropriate code.
function onMonitorRequestCompleted() {

    var finished = true;
    var returnCode = 0;
    for (var i = 0; i < queuedMonitors.length; i++) {
        returnCode =  queuedMonitors[i].result > returnCode ? queuedMonitors[i].result : returnCode;
        if (queuedMonitors[i].result === null) {
            finished = false;
        }
    }

    if (finished) {
        if (returnCode >= 2) {
            fdxLogger.error("FDXMON: FINISHED WITH ERROR. Exit Code = " + returnCode);
        }
        else if (returnCode === 1) {
            fdxLogger.warn("FDXMON: FINISHED WITH WARNING. Exit Code = " + returnCode);
        }
        else {
            fdxLogger.info("FDXMON: SUCCESSFULLY FINISHED. Exit Code = " + returnCode);
        }

        process.exit(returnCode);
    }
}
