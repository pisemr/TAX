import moment from 'moment'
import { CronJob } from 'cron'
import { providersTask } from '../controllers/providers/providers-cron'
import cache from '../lib/cache'

function getAllProvidersCron() {
  const cornTime = '00 */10 * * * *'
  const getProvidersJob = new CronJob( {
    cronTime: cornTime,
    onTick: function () {
      //Randomize when we refresh, to prevent too much load on Provider Service
      //Given below, on average we'll refresh once every 100 minutes 
      if (Math.floor(Math.random() * 10) === 0) {
        providersTask()
        cache.set( 'lastCronRun', moment().format( 'dddd, MMMM Do YYYY, h:mm:ss a' ) )
      }
    },
    start: false,
    timeZone: 'America/Los_Angeles'
  } )
  getProvidersJob.start()
  providersTask()
}

export default getAllProvidersCron
