

function initProcessListeners( server ) {

  function gracefulShutdown() {
    // stop taking new requests.
    server.close()
    let killtimer = setTimeout( function () {
      console.log( 'SERVER_CRASH: Kill state waited' )
      process.exit( 1 )
    }, 1000 )
    killtimer.unref()
  }

  process.on( 'uncaughtException', function ( err ) {
    //log err
    console.log( err, 'process uncaughtException' )
    gracefulShutdown()
  } )

  process.on( 'SIGINT', function () {
    console.log( 'received SIGINT, shutting down' )
    gracefulShutdown()
  } )

  process.on( 'SIGTERM', function () {
    console.log( 'received SIGTERM, shutting down' )
    gracefulShutdown()
  } )
}

export default initProcessListeners
